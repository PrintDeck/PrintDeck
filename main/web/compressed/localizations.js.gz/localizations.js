window.PRINTDECK_TRANSLATIONS={
  en:{},
  pl:{"My Printers":"Moje drukarki","Display & Brightness":"Ekran i jasność","Device Settings":"Ustawienia urządzenia","Wi-Fi":"Wi-Fi","Screen":"Ekran","Screen Saver":"Wygaszacz ekranu","Printer List Refresh":"Lista drukarek","Sound Effects":"Efekty dźwiękowe","Time Zone":"Strefa czasowa","Firmware":"Oprogramowanie","Add printer":"Dodaj drukarkę","Screen Settings":"Ustawienia ekranu","Screen brightness":"Jasność ekranu","Screen orientation":"Orientacja ekranu","Rotate automatically":"Obracaj automatycznie","Save screen settings":"Zapisz ustawienia ekranu","Dim the display":"Przyciemnij ekran","On":"Włączone","Off":"Wyłączone","Automatic":"Automatycznie","Save screen saver":"Zapisz wygaszacz","Refresh interval":"Częstotliwość odświeżania","Save refresh interval":"Zapisz częstotliwość","Sound volume":"Głośność dźwięku","Save sound settings":"Zapisz ustawienia dźwięku","Time zone":"Strefa czasowa","Save time zone":"Zapisz strefę czasową","PrintDeck update":"Aktualizacja PrintDeck","Check for updates":"Sprawdź aktualizacje","Install update":"Zainstaluj aktualizację","Firmware Update":"Aktualizacja oprogramowania","Install release":"Zainstaluj wydanie","Install from URL":"Zainstaluj z adresu URL","Upload firmware":"Wgraj oprogramowanie","Detected networks":"Wykryte sieci","Network name (SSID)":"Nazwa sieci (SSID)","Wi-Fi password":"Hasło Wi-Fi","Save Wi-Fi & restart":"Zapisz Wi-Fi i uruchom ponownie","Choose your time zone":"Wybierz strefę czasową","Cancel":"Anuluj","Use this time zone":"Użyj tej strefy","Back":"Wstecz","Delete":"Usuń","Make active":"Ustaw jako aktywną","Save & connect":"Zapisz i połącz","GitHub repository":"Repozytorium GitHub"},
  es:{"My Printers":"Mis impresoras","Display & Brightness":"Pantalla y brillo","Device Settings":"Ajustes del dispositivo","Wi-Fi":"Wi-Fi","Screen":"Pantalla","Screen Saver":"Protector de pantalla","Printer List Refresh":"Actualización de impresoras","Sound Effects":"Efectos de sonido","Time Zone":"Zona horaria","Firmware":"Firmware","Add printer":"Añadir impresora","Screen Settings":"Ajustes de pantalla","Screen brightness":"Brillo de pantalla","Screen orientation":"Orientación de pantalla","Rotate automatically":"Girar automáticamente","Save screen settings":"Guardar ajustes de pantalla","Dim the display":"Atenuar la pantalla","On":"Activado","Off":"Desactivado","Automatic":"Automático","Save screen saver":"Guardar protector de pantalla","Refresh interval":"Intervalo de actualización","Save refresh interval":"Guardar intervalo","Sound volume":"Volumen del sonido","Save sound settings":"Guardar ajustes de sonido","Time zone":"Zona horaria","Save time zone":"Guardar zona horaria","PrintDeck update":"Actualización de PrintDeck","Check for updates":"Buscar actualizaciones","Install update":"Instalar actualización","Firmware Update":"Actualización de firmware","Install release":"Instalar versión","Install from URL":"Instalar desde URL","Upload firmware":"Subir firmware","Detected networks":"Redes detectadas","Network name (SSID)":"Nombre de red (SSID)","Wi-Fi password":"Contraseña Wi-Fi","Save Wi-Fi & restart":"Guardar Wi-Fi y reiniciar","Choose your time zone":"Elige tu zona horaria","Cancel":"Cancelar","Use this time zone":"Usar esta zona horaria","Back":"Atrás","Delete":"Eliminar","Make active":"Activar","Save & connect":"Guardar y conectar","GitHub repository":"Repositorio de GitHub"},
  fr:{"My Printers":"Mes imprimantes","Display & Brightness":"Écran et luminosité","Device Settings":"Paramètres de l’appareil","Wi-Fi":"Wi-Fi","Screen":"Écran","Screen Saver":"Économiseur d’écran","Printer List Refresh":"Actualisation des imprimantes","Sound Effects":"Effets sonores","Time Zone":"Fuseau horaire","Firmware":"Micrologiciel","Add printer":"Ajouter une imprimante","Screen Settings":"Paramètres de l’écran","Screen brightness":"Luminosité de l’écran","Screen orientation":"Orientation de l’écran","Rotate automatically":"Rotation automatique","Save screen settings":"Enregistrer les paramètres","Dim the display":"Atténuer l’écran","On":"Activé","Off":"Désactivé","Automatic":"Automatique","Save screen saver":"Enregistrer l’économiseur","Refresh interval":"Intervalle d’actualisation","Save refresh interval":"Enregistrer l’intervalle","Sound volume":"Volume sonore","Save sound settings":"Enregistrer les réglages audio","Time zone":"Fuseau horaire","Save time zone":"Enregistrer le fuseau","PrintDeck update":"Mise à jour de PrintDeck","Check for updates":"Rechercher des mises à jour","Install update":"Installer la mise à jour","Firmware Update":"Mise à jour du micrologiciel","Install release":"Installer la version","Install from URL":"Installer depuis l’URL","Upload firmware":"Téléverser le micrologiciel","Detected networks":"Réseaux détectés","Network name (SSID)":"Nom du réseau (SSID)","Wi-Fi password":"Mot de passe Wi-Fi","Save Wi-Fi & restart":"Enregistrer le Wi-Fi et redémarrer","Choose your time zone":"Choisissez votre fuseau horaire","Cancel":"Annuler","Use this time zone":"Utiliser ce fuseau","Back":"Retour","Delete":"Supprimer","Make active":"Activer","Save & connect":"Enregistrer et connecter","GitHub repository":"Dépôt GitHub"},
  de:{"My Printers":"Meine Drucker","Display & Brightness":"Display und Helligkeit","Device Settings":"Geräteeinstellungen","Wi-Fi":"WLAN","Screen":"Bildschirm","Screen Saver":"Bildschirmschoner","Printer List Refresh":"Druckerliste aktualisieren","Sound Effects":"Soundeffekte","Time Zone":"Zeitzone","Firmware":"Firmware","Add printer":"Drucker hinzufügen","Screen Settings":"Bildschirmeinstellungen","Screen brightness":"Bildschirmhelligkeit","Screen orientation":"Bildschirmausrichtung","Rotate automatically":"Automatisch drehen","Save screen settings":"Bildschirmeinstellungen speichern","Dim the display":"Bildschirm dimmen","On":"Ein","Off":"Aus","Automatic":"Automatisch","Save screen saver":"Bildschirmschoner speichern","Refresh interval":"Aktualisierungsintervall","Save refresh interval":"Intervall speichern","Sound volume":"Lautstärke","Save sound settings":"Soundeinstellungen speichern","Time zone":"Zeitzone","Save time zone":"Zeitzone speichern","PrintDeck update":"PrintDeck-Aktualisierung","Check for updates":"Nach Updates suchen","Install update":"Update installieren","Firmware Update":"Firmware-Aktualisierung","Install release":"Version installieren","Install from URL":"Von URL installieren","Upload firmware":"Firmware hochladen","Detected networks":"Gefundene Netzwerke","Network name (SSID)":"Netzwerkname (SSID)","Wi-Fi password":"WLAN-Passwort","Save Wi-Fi & restart":"WLAN speichern und neu starten","Choose your time zone":"Zeitzone auswählen","Cancel":"Abbrechen","Use this time zone":"Diese Zeitzone verwenden","Back":"Zurück","Delete":"Löschen","Make active":"Aktivieren","Save & connect":"Speichern und verbinden","GitHub repository":"GitHub-Repository"},
  "zh-CN":{"My Printers":"我的打印机","Display & Brightness":"显示与亮度","Device Settings":"设备设置","Wi-Fi":"无线网络","Screen":"屏幕","Screen Saver":"屏幕保护","Printer List Refresh":"打印机列表刷新","Sound Effects":"声音效果","Time Zone":"时区","Firmware":"固件","Add printer":"添加打印机","Screen Settings":"屏幕设置","Screen brightness":"屏幕亮度","Screen orientation":"屏幕方向","Rotate automatically":"自动旋转","Save screen settings":"保存屏幕设置","Dim the display":"调暗屏幕","On":"开启","Off":"关闭","Automatic":"自动","Save screen saver":"保存屏幕保护设置","Refresh interval":"刷新间隔","Save refresh interval":"保存刷新间隔","Sound volume":"音量","Save sound settings":"保存声音设置","Time zone":"时区","Save time zone":"保存时区","PrintDeck update":"PrintDeck 更新","Check for updates":"检查更新","Install update":"安装更新","Firmware Update":"固件更新","Install release":"安装版本","Install from URL":"从网址安装","Upload firmware":"上传固件","Detected networks":"检测到的网络","Network name (SSID)":"网络名称 (SSID)","Wi-Fi password":"Wi-Fi 密码","Save Wi-Fi & restart":"保存 Wi-Fi 并重启","Choose your time zone":"选择时区","Cancel":"取消","Use this time zone":"使用此时区","Back":"返回","Delete":"删除","Make active":"设为当前打印机","Save & connect":"保存并连接","GitHub repository":"GitHub 仓库"}
};

// Shared rows keep every added Web Config string aligned across all maintained languages.
const PRINTDECK_TRANSLATION_COLUMNS=["pl","es","fr","de","zh-CN"];
const PRINTDECK_EXTRA_TRANSLATIONS={
  "Shut down PrintDeck":["Wyłącz PrintDeck", "Apagar PrintDeck", "Arrêter PrintDeck", "PrintDeck herunterfahren", "关闭 PrintDeck"],
  "PrintDeck stays powered on.":["PrintDeck pozostaje włączony.", "PrintDeck permanece encendido.", "PrintDeck reste allumé.", "PrintDeck bleibt eingeschaltet.", "PrintDeck 保持开启。"],
  "Display turns off first. PrintDeck shuts down {time} later on battery.":["Najpierw gaśnie ekran. Na baterii PrintDeck wyłączy się {time} później.", "Primero se apaga la pantalla. Con batería, PrintDeck se apaga {time} después.", "L’écran s’éteint d’abord. Sur batterie, PrintDeck s’arrête {time} plus tard.", "Zuerst geht das Display aus. Im Akkubetrieb schaltet sich PrintDeck {time} später aus.", "先关闭屏幕。使用电池时，PrintDeck 将在 {time}后关机。"],

  "2 days":["2 dni", "2 días", "2 jours", "2 Tage", "2 天"],
  "3 days":["3 dni", "3 días", "3 jours", "3 Tage", "3 天"],
  "5 days":["5 dni", "5 días", "5 jours", "5 Tage", "5 天"],
  "7 days":["7 dni", "7 días", "7 jours", "7 Tage", "7 天"],

  "Then":["Następnie", "Después", "Ensuite", "Danach", "然后"],
  "Choose when to start and how long each step lasts.":["Wybierz, kiedy rozpocząć i jak długo ma trwać każdy etap.", "Elige cuándo empezar y cuánto dura cada paso.", "Choisissez quand commencer et la durée de chaque étape.", "Wähle den Startzeitpunkt und die Dauer jedes Schritts.", "选择开始时间和每个阶段的持续时长。"],
  "Start after inactivity":["Rozpocznij po bezczynności", "Iniciar tras inactividad", "Démarrer après une inactivité de", "Nach Inaktivität starten", "无操作后开始"],
  "The sequence starts after your last interaction with PrintDeck.":["Czas oczekiwania liczy się od ostatniej interakcji z PrintDeck.", "La espera empieza tras tu última interacción con PrintDeck.", "Le délai commence après votre dernière interaction avec PrintDeck.", "Die Wartezeit beginnt nach deiner letzten Bedienung von PrintDeck.", "等待时间从您上次操作 PrintDeck 时开始计算。"],
  "The sequence starts after your last interaction with PrintDeck. Includes paused prints.":["Czas oczekiwania liczy się od ostatniej interakcji z PrintDeck. Dotyczy również wstrzymanego druku.", "La espera empieza tras tu última interacción con PrintDeck. Incluye impresiones pausadas.", "Le délai commence après votre dernière interaction avec PrintDeck. S’applique aussi aux impressions en pause.", "Die Wartezeit beginnt nach deiner letzten Bedienung von PrintDeck. Gilt auch für pausierte Drucke.", "等待时间从您上次操作 PrintDeck 时开始计算。也适用于已暂停的打印。"],
  "Dim the display for":["Przyciemnij ekran na", "Atenuar la pantalla durante", "Assombrir l’écran pendant", "Display dimmen für", "屏幕调暗持续时间"],
  "Run screen saver for":["Wyświetlaj wygaszacz przez", "Mostrar el protector durante", "Afficher l’économiseur pendant", "Bildschirmschoner anzeigen für", "屏幕保护运行时长"],
  "Turn off the display":["Wyłącz ekran", "Apagar la pantalla", "Éteindre l’écran", "Display ausschalten", "关闭屏幕"],
  "Automatically":["Automatycznie", "Automáticamente", "Automatiquement", "Automatisch", "自动"],
  "Not used":["Nieaktywne", "No se usa", "Inactif", "Nicht aktiv", "未启用"],
  "Skip":["Pomiń", "Omitir", "Ignorer", "Überspringen", "跳过"],
  "Until wake-up":["Do wybudzenia", "Hasta despertar", "Jusqu’au réveil", "Bis zum Aufwecken", "直到唤醒"],
  "Each step starts when the previous one ends.":["Każdy etap rozpoczyna się po zakończeniu poprzedniego.", "Cada paso empieza cuando termina el anterior.", "Chaque étape commence à la fin de la précédente.", "Jeder Schritt beginnt, wenn der vorherige endet.", "每个阶段在前一阶段结束后开始。"],
  "Automatic adjusts to your normal brightness. Also applies to the screen saver.":["Tryb automatyczny dobiera poziom do zwykłej jasności ekranu. Dotyczy również wygaszacza.", "El modo automático se adapta al brillo habitual. También se aplica al protector de pantalla.", "Le mode automatique s’adapte à votre luminosité habituelle. S’applique aussi à l’économiseur d’écran.", "Automatisch passt den Wert an deine normale Helligkeit an. Gilt auch für den Bildschirmschoner.", "自动模式会根据正常亮度调整。此设置也适用于屏幕保护。"],
  "Shut down PrintDeck after the display turns off":["Wyłącz PrintDeck po zgaszeniu ekranu", "Apagar PrintDeck después de apagarse la pantalla", "Arrêter PrintDeck après l’extinction de l’écran", "PrintDeck nach dem Ausschalten des Displays herunterfahren", "屏幕关闭后关闭 PrintDeck"],
  "On battery only. PrintDeck stays on while a print is active.":["Tylko na baterii. PrintDeck pozostaje włączony podczas druku.", "Solo con batería. PrintDeck permanece encendido mientras hay una impresión activa.", "Sur batterie uniquement. PrintDeck reste allumé pendant une impression.", "Nur im Akkubetrieb. Während eines Drucks bleibt PrintDeck eingeschaltet.", "仅限电池供电。打印期间 PrintDeck 保持开启。"],
  "While dimmed or showing a screen saver":["Po przyciemnieniu lub podczas wygaszacza", "Al atenuar o mostrar el protector", "Pendant l’atténuation ou l’économiseur", "Beim Dimmen oder Anzeigen des Bildschirmschoners", "屏幕调暗或显示屏幕保护时"],
  "Touch always wakes this display.":["Dotyk zawsze wybudza ten ekran.", "El toque siempre despierta esta pantalla.", "Le toucher réveille toujours cet écran.", "Berührung weckt dieses Display immer auf.", "触摸始终可以唤醒此屏幕。"],

  "Printer state":["Stan drukarki","Estado de la impresora","État de l’imprimante","Druckerstatus","打印机状态"],
  "Screen saver animation":["Animacja wygaszacza","Animación del protector de pantalla","Animation de l’économiseur d’écran","Bildschirmschoner-Animation","屏幕保护动画"],
  "Circles":["Kręgi","Círculos","Cercles","Kreise","圆环"],
  "Going to sleep":["Pora spać","Hora de dormir","Au dodo","Schlafenszeit","准备入睡"],
  "ON":["WŁ.","SÍ","OUI","AN","开"],
  "OFF":["WYŁ.","NO","NON","AUS","关"],
  "Show options":["Pokaż opcje","Mostrar opciones","Afficher les options","Optionen anzeigen","显示选项"],
  "Hide options":["Ukryj opcje","Ocultar opciones","Masquer les options","Optionen ausblenden","隐藏选项"],
  "30 minutes":["30 minut","30 minutos","30 minutes","30 Minuten","30 分钟"],
  "Screen Saver layout":["Układ wygaszacza ekranu", "Diseño del protector de pantalla", "Disposition de l’économiseur d’écran", "Layout des Bildschirmschoners", "屏幕保护布局"],
  "Changes save automatically":["Zmiany zapisują się automatycznie", "Los cambios se guardan automáticamente", "Les modifications sont enregistrées automatiquement", "Änderungen werden automatisch gespeichert", "更改会自动保存"],
  "Choose when the display dims or turns off.":["Wybierz, kiedy ekran ma się przyciemniać lub wyłączać.", "Elige cuándo se atenúa o apaga la pantalla.", "Choisissez quand l’écran s’assombrit ou s’éteint.", "Wähle, wann das Display gedimmt oder ausgeschaltet wird.", "选择屏幕调暗或关闭的时间。"],
  "Both timers count from your last interaction with PrintDeck.":["Oba czasy są liczone od ostatniej interakcji z PrintDeck.", "Ambos tiempos se cuentan desde la última interacción con PrintDeck.", "Les deux délais sont mesurés depuis votre dernière interaction avec PrintDeck.", "Beide Zeiten werden ab deiner letzten Interaktion mit PrintDeck gemessen.", "两个计时器均从您上次操作 PrintDeck 时开始计时。"],
  "Dim the display after":["Przyciemnij ekran po", "Atenuar la pantalla tras", "Assombrir l’écran après", "Display dimmen nach", "调暗屏幕的等待时间"],
  "Turn off the display after":["Wyłącz ekran po", "Apagar la pantalla tras", "Éteindre l’écran après", "Display ausschalten nach", "关闭屏幕的等待时间"],
  "Also apply on USB power":["Stosuj również przy zasilaniu USB", "Aplicar también con alimentación USB", "Appliquer aussi sur alimentation USB", "Auch bei USB-Stromversorgung anwenden", "使用 USB 供电时也应用"],
  "Off: the display stays awake on USB.":["Wyłączone: przy zasilaniu USB ekran pozostaje włączony.", "Desactivado: la pantalla permanece encendida con USB.", "Désactivé : l’écran reste allumé sur USB.", "Aus: Das Display bleibt bei USB-Stromversorgung eingeschaltet.", "关闭时：使用 USB 供电期间屏幕保持亮起。"],
  "Automatic adjusts to your normal brightness.":["Tryb automatyczny dobiera poziom do zwykłej jasności ekranu.", "El modo automático se adapta al brillo habitual.", "Le mode automatique s’adapte à votre luminosité habituelle.", "Automatisch passt den Wert an deine normale Helligkeit an.", "自动模式会根据正常亮度调整调暗后的亮度。"],
  "Turn off PrintDeck after":["Wyłącz PrintDeck po", "Apagar PrintDeck tras", "Éteindre PrintDeck après", "PrintDeck ausschalten nach", "关闭 PrintDeck 的等待时间"],
  "On battery, after this long without a print or interaction. Press Power to turn it on again.":["Na baterii, po tym czasie bez druku i interakcji. Aby włączyć ponownie, naciśnij Power.", "Con batería, tras este tiempo sin impresión ni interacción. Pulsa Power para volver a encenderlo.", "Sur batterie, après ce délai sans impression ni interaction. Appuyez sur Power pour le rallumer.", "Im Akkubetrieb nach dieser Zeit ohne Druck oder Interaktion. Zum Einschalten Power drücken.", "使用电池时，在无打印且无操作达到此时长后关闭。按 Power 按钮可重新开机。"],
  "1 hour":["1 godzina", "1 hora", "1 heure", "1 Stunde", "1 小时"],
  "2 hours":["2 godziny", "2 horas", "2 heures", "2 Stunden", "2 小时"],
  "3 hours":["3 godziny", "3 horas", "3 heures", "3 Stunden", "3 小时"],
  "5 hours":["5 godzin", "5 horas", "5 heures", "5 Stunden", "5 小时"],
  "8 hours":["8 godzin", "8 horas", "8 heures", "8 Stunden", "8 小时"],
  "12 hours":["12 godzin", "12 horas", "12 heures", "12 Stunden", "12 小时"],
  "24 hours":["24 godziny", "24 horas", "24 heures", "24 Stunden", "24 小时"],
  "15 minutes":["15 minut", "15 minutos", "15 minutes", "15 Minuten", "15 分钟"],
  "All times count from your last interaction with PrintDeck. Includes paused prints.":["Wszystkie czasy są liczone od ostatniej interakcji z PrintDeck. Dotyczy również wstrzymanego druku.","Todos los tiempos se cuentan desde la última interacción con PrintDeck. También se aplica a las impresiones en pausa.","Tous les délais sont mesurés depuis votre dernière interaction avec PrintDeck. S’applique aussi aux impressions en pause.","Alle Zeiten werden ab deiner letzten Interaktion mit PrintDeck gemessen. Gilt auch für pausierte Drucke.","所有计时器均从您上次操作 PrintDeck 时开始计时，也适用于已暂停的打印。"],
  "Wake the display":["Wybudzanie ekranu", "Activar la pantalla", "Réveiller l’écran", "Display aufwecken", "唤醒屏幕"],
  "Turn or tilt PrintDeck. Also works when screen rotation is locked.":["Obróć lub przechyl PrintDeck. Działa również przy zablokowanym obrocie ekranu.", "Gira o inclina PrintDeck. También funciona con la rotación bloqueada.", "Tournez ou inclinez PrintDeck. Fonctionne aussi lorsque la rotation est verrouillée.", "Drehe oder neige PrintDeck. Funktioniert auch bei gesperrter Bildschirmdrehung.", "转动或倾斜 PrintDeck。锁定屏幕旋转时也可唤醒。"],
  "Wake on touch":["Wybudzaj dotykiem", "Activar al tocar", "Réveiller au toucher", "Durch Berührung aufwecken", "触摸唤醒"],
  "Tap or swipe the physical screen to wake it.":["Dotknij ekranu urządzenia lub przesuń po nim palcem, aby go wybudzić.", "Toca o desliza el dedo por la pantalla del dispositivo para activarla.", "Touchez l’écran de l’appareil ou balayez-le pour le réveiller.", "Tippe auf das Gerätedisplay oder wische darüber, um es aufzuwecken.", "轻触设备屏幕或在屏幕上滑动即可唤醒。"],
  "The Power button always wakes the display.":["Przycisk Power zawsze wybudza ekran.", "El botón Power siempre activa la pantalla.", "Le bouton Power réveille toujours l’écran.", "Die Power-Taste weckt das Display immer auf.", "Power 按钮始终可以唤醒屏幕。"],
  "Use the Power button to wake the display.":["Aby wybudzić ekran, naciśnij przycisk Power.", "Pulsa el botón Power para activar la pantalla.", "Appuyez sur le bouton Power pour réveiller l’écran.", "Drücke die Power-Taste, um das Display aufzuwecken.", "按 Power 按钮可唤醒屏幕。"],
  "Sound while the display sleeps":["Dźwięk podczas wygaszania ekranu", "Sonido con la pantalla en reposo", "Son lorsque l’écran est en veille", "Ton bei ruhendem Display", "屏幕休眠时的声音"],
  "Percentage of your normal sound level. 0% mutes sound.":["Procent zwykłej głośności. 0% wycisza dźwięk.", "Porcentaje del volumen habitual. 0% silencia el sonido.", "Pourcentage du volume habituel. 0 % coupe le son.", "Prozent deiner normalen Lautstärke. 0 % schaltet den Ton stumm.", "相对于正常音量的百分比。0% 表示静音。"],
  "While dimmed":["Po przyciemnieniu", "Con la pantalla atenuada", "Lorsque l’écran est assombri", "Bei gedimmtem Display", "屏幕调暗时"],
  "While the display is off":["Po wyłączeniu ekranu", "Con la pantalla apagada", "Lorsque l’écran est éteint", "Bei ausgeschaltetem Display", "屏幕关闭时"],
  "Setup and firmware updates always keep the screen awake.":["Konfiguracja i aktualizacje firmware zawsze utrzymują ekran włączony.", "La configuración y las actualizaciones de firmware siempre mantienen la pantalla encendida.", "La configuration et les mises à jour du micrologiciel gardent toujours l’écran allumé.", "Während der Einrichtung und bei Firmware-Updates bleibt das Display immer eingeschaltet.", "设置和固件更新期间屏幕始终保持亮起。"],
  "Choose a dim time in either section to use this setting.":["Aby użyć tego ustawienia, wybierz czas przyciemniania w jednej z sekcji.", "Elige un tiempo de atenuación en alguna sección para usar este ajuste.", "Choisissez un délai d’assombrissement dans l’une des sections pour utiliser ce réglage.", "Wähle in einem der Abschnitte eine Dimmzeit, um diese Einstellung zu verwenden.", "在任一区域选择调暗时间后，即可使用此设置。"],
  "Choose when the display dims, shows a screen saver, or turns off.":["Wybierz, kiedy ekran ma się przyciemniać, pokazywać wygaszacz lub wyłączać.", "Elige cuándo se atenúa la pantalla, muestra un protector o se apaga.", "Choisissez quand l’écran s’assombrit, affiche un économiseur ou s’éteint.", "Wähle, wann das Display gedimmt wird, den Bildschirmschoner zeigt oder sich ausschaltet.", "选择屏幕调暗、显示屏幕保护动画或关闭的时间。"],
  "All times count from your last interaction with PrintDeck.":["Wszystkie czasy są liczone od ostatniej interakcji z PrintDeck.", "Todos los tiempos se cuentan desde la última interacción con PrintDeck.", "Tous les délais sont mesurés depuis votre dernière interaction avec PrintDeck.", "Alle Zeiten werden ab deiner letzten Interaktion mit PrintDeck gemessen.", "所有计时器均从您上次操作 PrintDeck 时开始计时。"],
  "Start screen saver after":["Włącz wygaszacz po", "Iniciar el protector de pantalla tras", "Démarrer l’économiseur d’écran après", "Bildschirmschoner starten nach", "启动屏幕保护的等待时间"],

  "USB INSTALL":["INSTALACJA USB", "INSTALAR POR USB", "INSTALLATION USB", "USB-INSTALLATION", "USB 安装"],
  "Back up settings.\nFactory install via USB:\nprintdeck.xyz/firmware/\nSettings and images are erased.":["Zrób kopię ustawień.\nInstalacja fabryczna USB:\nprintdeck.xyz/firmware/\nUsuwa ustawienia i obrazy.", "Guarda los ajustes.\nInstalación de fábrica USB:\nprintdeck.xyz/firmware/\nBorra ajustes e imágenes.", "Sauvegardez les réglages.\nInstallation d’usine USB :\nprintdeck.xyz/firmware/\nRéglages et images effacés.", "Einstellungen sichern.\nUSB-Werksinstallation:\nprintdeck.xyz/firmware/\nLöscht Einstellungen und Bilder.", "请备份设置。\n通过 USB 进行出厂安装：\nprintdeck.xyz/firmware/\n设置和自定义图片将被清除。"],
  "A USB factory installation is required. Back up your configuration and follow the instructions at printdeck.xyz/firmware/. Saved settings and custom images will be erased.":["Wymagana jest instalacja fabryczna przez USB. Zrób kopię konfiguracji i postępuj według instrukcji na printdeck.xyz/firmware/. Zapisane ustawienia i własne obrazy zostaną usunięte.", "Se requiere una instalación de fábrica por USB. Guarda una copia de la configuración y sigue las instrucciones en printdeck.xyz/firmware/. Se borrarán los ajustes y las imágenes personalizadas.", "Une installation d’usine par USB est requise. Sauvegardez la configuration et suivez les instructions sur printdeck.xyz/firmware/. Les réglages et images personnalisées seront effacés.", "Eine USB-Werksinstallation ist erforderlich. Sichere die Konfiguration und folge der Anleitung auf printdeck.xyz/firmware/. Gespeicherte Einstellungen und eigene Bilder werden gelöscht.", "需要通过 USB 进行出厂安装。请备份配置并按照 printdeck.xyz/firmware/ 上的说明操作。已保存的设置和自定义图片将被清除。"],
  "Open USB installer":["Otwórz instalator USB", "Abrir instalador USB", "Ouvrir l’installateur USB", "USB-Installer öffnen", "打开 USB 安装程序"],
  "Required version: {version}.":["Wymagana wersja: {version}.", "Versión requerida: {version}.", "Version requise : {version}.", "Erforderliche Version: {version}.", "所需版本：{version}。"],
  "Available version: {version}.":["Dostępna wersja: {version}.", "Versión disponible: {version}.", "Version disponible : {version}.", "Verfügbare Version: {version}.", "可用版本：{version}。"],
  "Check for updates to find the next compatible release or the required USB installation.":["Sprawdź aktualizacje, aby znaleźć zgodne wydanie lub wymaganą instalację USB.", "Busca actualizaciones para encontrar una versión compatible o la instalación USB necesaria.", "Recherchez les mises à jour pour trouver une version compatible ou l’installation USB requise.", "Suche nach Updates, um eine kompatible Version oder die erforderliche USB-Installation zu finden.", "检查更新以查找兼容版本或所需的 USB 安装。"],
  "This firmware cannot be installed while keeping settings. Back up your configuration, then use First installation / Factory reset.":["Tego firmware nie można zainstalować z zachowaniem ustawień. Zrób kopię konfiguracji, a następnie wybierz Pierwsza instalacja / Ustawienia fabryczne.", "Este firmware no permite conservar los ajustes. Guarda la configuración y usa Primera instalación / Restablecimiento de fábrica.", "Ce micrologiciel ne peut pas conserver les réglages. Sauvegardez la configuration, puis choisissez Première installation / Réinitialisation d’usine.", "Diese Firmware kann nicht unter Beibehaltung der Einstellungen installiert werden. Sichere die Konfiguration und wähle Erstinstallation / Werkseinstellungen.", "此固件无法在保留设置的情况下安装。请备份配置，然后选择首次安装／恢复出厂设置。"],
  "The installed firmware could not be identified. No data was written. Use the USB factory installer.":["Nie udało się rozpoznać zainstalowanego firmware. Niczego nie zapisano. Użyj fabrycznej instalacji USB.", "No se pudo identificar el firmware instalado. No se ha escrito nada. Usa la instalación de fábrica por USB.", "Le micrologiciel installé n’a pas pu être identifié. Aucune donnée écrite. Utilisez l’installation d’usine par USB.", "Die installierte Firmware konnte nicht erkannt werden. Es wurden keine Daten geschrieben. Verwende die USB-Werksinstallation.", "无法识别已安装的固件。未写入任何数据。请使用 USB 出厂安装程序。"],

  "This action could not be understood. Refresh the page and try again.":["Nie udało się odczytać tej operacji. Odśwież stronę i spróbuj ponownie.","No se ha podido interpretar esta acción. Actualiza la página e inténtalo de nuevo.","Cette action n’a pas pu être comprise. Actualisez la page et réessayez.","Diese Aktion konnte nicht verstanden werden. Aktualisiere die Seite und versuche es erneut.","无法识别此操作。请刷新页面后重试。"],
  "Please check the printer name, network address and connection details.":["Sprawdź nazwę drukarki, adres sieciowy i dane połączenia.","Comprueba el nombre de la impresora, la dirección de red y los datos de conexión.","Vérifiez le nom de l’imprimante, l’adresse réseau et les détails de connexion.","Prüfe Druckernamen, Netzwerkadresse und Verbindungsdaten.","请检查打印机名称、网络地址和连接信息。"],
  "Connect PrintDeck to Wi-Fi before testing a printer.":["Połącz PrintDeck z Wi-Fi przed sprawdzeniem drukarki.","Conecta PrintDeck al Wi-Fi antes de comprobar una impresora.","Connectez PrintDeck au Wi-Fi avant de vérifier une imprimante.","Verbinde PrintDeck mit dem WLAN, bevor du einen Drucker prüfst.","检查打印机前，请先将 PrintDeck 连接到 Wi-Fi。"],
  "PrintDeck could not start the connection test. Please try again.":["PrintDeck nie mógł rozpocząć sprawdzania połączenia. Spróbuj ponownie.","PrintDeck no ha podido iniciar la comprobación de conexión. Inténtalo de nuevo.","PrintDeck n’a pas pu lancer la vérification de la connexion. Réessayez.","PrintDeck konnte die Verbindungsprüfung nicht starten. Bitte versuche es erneut.","PrintDeck 无法开始连接检查。请重试。"],
  "Experimental":["Eksperymentalne","Experimental","Expérimental","Experimentell","实验性"],
  "Add Elegoo printer":["Dodaj drukarkę Elegoo","Añadir impresora Elegoo","Ajouter une imprimante Elegoo","Elegoo-Drucker hinzufügen","添加 Elegoo 打印机"],
  "Choose your Elegoo printer family.":["Wybierz rodzinę drukarek Elegoo.","Elige la familia de tu impresora Elegoo.","Choisissez la famille de votre imprimante Elegoo.","Wähle die Familie deines Elegoo-Druckers.","选择您的 Elegoo 打印机系列。"],
  "Neptune 4 / Pro / Plus / Max":["Neptune 4 / Pro / Plus / Max","Neptune 4 / Pro / Plus / Max","Neptune 4 / Pro / Plus / Max","Neptune 4 / Pro / Plus / Max","Neptune 4 / Pro / Plus / Max"],
  "Centauri Carbon":["Centauri Carbon","Centauri Carbon","Centauri Carbon","Centauri Carbon","Centauri Carbon"],
  "Centauri Carbon 2":["Centauri Carbon 2","Centauri Carbon 2","Centauri Carbon 2","Centauri Carbon 2","Centauri Carbon 2"],
  "Printer identifier":["Identyfikator drukarki","Identificador de la impresora","Identifiant de l’imprimante","Druckerkennung","打印机标识符"],
  "Leave blank to read the identifier from the printer.":["Pozostaw puste, aby odczytać identyfikator z drukarki.","Déjalo vacío para leer el identificador de la impresora.","Laissez vide pour lire l’identifiant depuis l’imprimante.","Leer lassen, um die Kennung vom Drucker auszulesen.","留空以从打印机读取标识符。"],
  "Enable LAN mode on the printer and enter its access code.":["Włącz tryb LAN na drukarce i wpisz jej kod dostępu.","Activa el modo LAN en la impresora e introduce su código de acceso.","Activez le mode LAN sur l’imprimante et saisissez son code d’accès.","Aktiviere den LAN-Modus am Drucker und gib seinen Zugangscode ein.","在打印机上启用局域网模式并输入其访问码。"],
  "Check the Elegoo connection before saving.":["Sprawdź połączenie z Elegoo przed zapisaniem.","Comprueba la conexión con Elegoo antes de guardar.","Vérifiez la connexion Elegoo avant d’enregistrer.","Prüfe die Elegoo-Verbindung vor dem Speichern.","保存前请检查 Elegoo 连接。"],
  "Elegoo did not accept the access code.":["Elegoo nie zaakceptowało kodu dostępu.","Elegoo no ha aceptado el código de acceso.","Elegoo n’a pas accepté le code d’accès.","Elegoo hat den Zugangscode nicht akzeptiert.","Elegoo 未接受访问码。"],
  "The printer has no free connection. Close another printer app and try again.":["Drukarka nie ma wolnego połączenia. Zamknij inną aplikację drukarki i spróbuj ponownie.","La impresora no tiene conexiones libres. Cierra otra aplicación de la impresora e inténtalo de nuevo.","L’imprimante n’a plus de connexion disponible. Fermez une autre application d’imprimante et réessayez.","Der Drucker hat keine freie Verbindung. Schließe eine andere Drucker-App und versuche es erneut.","打印机没有空闲连接。请关闭其他打印机应用后重试。"],
  "Elegoo is unavailable or returned an unsupported response. Check LAN mode and the local network.":["Elegoo jest niedostępne lub zwróciło nieobsługiwaną odpowiedź. Sprawdź tryb LAN i sieć lokalną.","Elegoo no está disponible o ha devuelto una respuesta no compatible. Comprueba el modo LAN y la red local.","Elegoo est indisponible ou a renvoyé une réponse non prise en charge. Vérifiez le mode LAN et le réseau local.","Elegoo ist nicht erreichbar oder hat eine nicht unterstützte Antwort gesendet. Prüfe den LAN-Modus und das lokale Netzwerk.","Elegoo 不可用或返回了不支持的响应。请检查局域网模式和本地网络。"],
  "Neptune 4 · Centauri Carbon":["Neptune 4 · Centauri Carbon","Neptune 4 · Centauri Carbon","Neptune 4 · Centauri Carbon","Neptune 4 · Centauri Carbon","Neptune 4 · Centauri Carbon"],
  "Add Prusa printer":["Dodaj drukarkę Prusa","Añadir impresora Prusa","Ajouter une imprimante Prusa","Prusa-Drucker hinzufügen","添加 Prusa 打印机"],
  "Authentication":["Uwierzytelnianie","Autenticación","Authentification","Authentifizierung","身份验证"],
  "Username and password":["Login i hasło","Usuario y contraseña","Identifiant et mot de passe","Benutzername und Passwort","用户名和密码"],
  "Username":["Login","Usuario","Identifiant","Benutzername","用户名"],
  "PrusaLink password":["Hasło PrusaLink","Contraseña de PrusaLink","Mot de passe PrusaLink","PrusaLink-Passwort","PrusaLink 密码"],
  "API key":["Klucz API","Clave API","Clé API","API-Schlüssel","API 密钥"],
  "Leave blank to keep saved credentials at the same address.":["Pozostaw puste, aby zachować dane logowania dla tego samego adresu.","Déjalo vacío para conservar las credenciales de la misma dirección.","Laissez vide pour conserver les identifiants de la même adresse.","Leer lassen, um die Zugangsdaten für dieselbe Adresse zu behalten.","留空以保留同一地址的已保存凭据。"],
  "Check the Prusa connection before saving.":["Przed zapisaniem sprawdź połączenie z Prusą.","Comprueba la conexión con Prusa antes de guardar.","Vérifiez la connexion Prusa avant d’enregistrer.","Prusa-Verbindung vor dem Speichern prüfen.","保存前请检查 Prusa 连接。"],
  "PrusaLink did not accept these credentials.":["PrusaLink nie zaakceptował danych logowania.","PrusaLink no aceptó estas credenciales.","PrusaLink n’a pas accepté ces identifiants.","PrusaLink hat diese Zugangsdaten nicht akzeptiert.","PrusaLink 未接受这些凭据。"],
  "PrusaLink is unavailable or returned an unsupported response.":["PrusaLink jest niedostępny lub zwrócił nieobsługiwaną odpowiedź.","PrusaLink no está disponible o devolvió una respuesta no compatible.","PrusaLink est indisponible ou a renvoyé une réponse non prise en charge.","PrusaLink ist nicht erreichbar oder hat eine nicht unterstützte Antwort gesendet.","PrusaLink 不可用或返回了不支持的响应。"],
  "Unsupported printer connection":["Nieobsługiwane połączenie drukarki","Conexión de impresora no compatible","Connexion d’imprimante non prise en charge","Nicht unterstützte Druckerverbindung","不支持的打印机连接"],
  "Unsupported authentication method":["Nieobsługiwana metoda uwierzytelniania","Método de autenticación no compatible","Méthode d’authentification non prise en charge","Nicht unterstützte Authentifizierungsmethode","不支持的身份验证方式"],
  "Credentials contain unsupported characters":["Dane logowania zawierają niedozwolone znaki","Las credenciales contienen caracteres no admitidos","Les identifiants contiennent des caractères non pris en charge","Zugangsdaten enthalten nicht unterstützte Zeichen","凭据包含不支持的字符"],
  "Credentials do not match the connection method":["Dane logowania nie pasują do metody połączenia","Las credenciales no corresponden al método de conexión","Les identifiants ne correspondent pas à la méthode de connexion","Zugangsdaten passen nicht zur Verbindungsmethode","凭据与连接方式不匹配"],
  "Needs attention":["Wymaga uwagi","Requiere atención","Intervention requise","Eingriff erforderlich","需要处理"],
  "Printer error":["Błąd drukarki","Error de impresora","Erreur d’imprimante","Druckerfehler","打印机错误"],
  "Printer busy":["Drukarka zajęta","Impresora ocupada","Imprimante occupée","Drucker beschäftigt","打印机忙碌"],
  "Device:":["Urządzenie:", "Dispositivo:", "Appareil :", "Gerät:", "设备："],
  "PrintDeck devices":["Urządzenia PrintDeck", "Dispositivos PrintDeck", "Appareils PrintDeck", "PrintDeck-Geräte", "PrintDeck 设备"],
  "This device":["To urządzenie", "Este dispositivo", "Cet appareil", "Dieses Gerät", "此设备"],
  "Refresh device list":["Odśwież listę urządzeń", "Actualizar lista de dispositivos", "Actualiser la liste des appareils", "Geräteliste aktualisieren", "刷新设备列表"],
  "Finding PrintDeck devices…":["Wyszukiwanie urządzeń PrintDeck…", "Buscando dispositivos PrintDeck…", "Recherche d’appareils PrintDeck…", "PrintDeck-Geräte werden gesucht…", "正在查找 PrintDeck 设备…"],
  "Recent results are kept for up to one minute.":["Ostatnie wyniki są przechowywane przez maksymalnie minutę.", "Los resultados recientes se conservan hasta un minuto.", "Les résultats récents sont conservés pendant une minute au maximum.", "Die letzten Ergebnisse werden bis zu einer Minute gespeichert.", "最近的结果最多保留一分钟。"],
  "No other PrintDeck devices were found. Recent results are kept for up to one minute.":["Nie znaleziono innych urządzeń PrintDeck. Ostatnie wyniki są przechowywane przez maksymalnie minutę.", "No se encontraron otros dispositivos PrintDeck. Los resultados se conservan hasta un minuto.", "Aucun autre appareil PrintDeck trouvé. Les résultats sont conservés pendant une minute au maximum.", "Keine weiteren PrintDeck-Geräte gefunden. Ergebnisse werden bis zu einer Minute gespeichert.", "未找到其他 PrintDeck 设备。结果最多保留一分钟。"],
  "Device search timed out. Please try again.":["Upłynął czas wyszukiwania urządzeń. Spróbuj ponownie.", "La búsqueda de dispositivos agotó el tiempo de espera. Inténtalo de nuevo.", "Le délai de recherche des appareils est dépassé. Réessayez.", "Die Gerätesuche hat zu lange gedauert. Bitte erneut versuchen.", "设备搜索超时。请重试。"],
  "Device search is unavailable. Please try again shortly.":["Wyszukiwanie urządzeń jest niedostępne. Spróbuj ponownie za chwilę.", "La búsqueda de dispositivos no está disponible. Inténtalo de nuevo en unos instantes.", "La recherche d’appareils est indisponible. Réessayez dans un instant.", "Die Gerätesuche ist nicht verfügbar. Bitte in Kürze erneut versuchen.", "设备搜索暂不可用。请稍后重试。"],
  "The device list reached its limit. You can still open another device by its address.":["Lista urządzeń osiągnęła limit. Inne urządzenie nadal możesz otworzyć przez jego adres.", "La lista de dispositivos alcanzó su límite. Puedes abrir otro dispositivo mediante su dirección.", "La liste des appareils a atteint sa limite. Vous pouvez ouvrir un autre appareil avec son adresse.", "Die Geräteliste hat ihr Limit erreicht. Weitere Geräte lassen sich über ihre Adresse öffnen.", "设备列表已达到上限。您仍可通过地址打开其他设备。"],
  "Connect PrintDeck to Wi-Fi before finding other devices.":["Połącz PrintDeck z Wi-Fi przed wyszukiwaniem innych urządzeń.", "Conecta PrintDeck a la red Wi-Fi antes de buscar otros dispositivos.", "Connectez PrintDeck au Wi-Fi avant de rechercher d’autres appareils.", "Verbinde PrintDeck vor der Gerätesuche mit dem WLAN.", "查找其他设备前，请将 PrintDeck 连接到 Wi-Fi。"],

  "ACTIVE":["AKTYWNA","ACTIVA","ACTIVE","AKTIV","当前"],
  "Online":["Połączona","En línea","En ligne","Online","在线"],
  "Connecting…":["Łączenie…","Conectando…","Connexion…","Verbindung wird hergestellt…","正在连接…"],
  "Updating…":["Aktualizowanie…","Actualizando…","Mise à jour…","Wird aktualisiert…","正在更新…"],
  "Printer light":["Lampka drukarki","Luz de la impresora","Éclairage de l’imprimante","Druckerbeleuchtung","打印机照明"],
  "Connection settings":["Ustawienia połączenia","Ajustes de conexión","Paramètres de connexion","Verbindungseinstellungen","连接设置"],
  "See the print more clearly.":["Lepiej zobacz swój wydruk.","Ve la impresión con más claridad.","Voyez plus clairement votre impression.","Behalte deinen Druck besser im Blick.","更清楚地查看打印情况。"],
  "Waiting for the printer to connect.":["Oczekiwanie na połączenie z drukarką.","Esperando la conexión de la impresora.","En attente de la connexion de l’imprimante.","Warten auf die Verbindung zum Drucker.","正在等待打印机连接。"],
  "Light control is not available for this printer.":["Ta drukarka nie udostępnia sterowania lampką.","Esta impresora no permite controlar la luz.","Le contrôle de l’éclairage n’est pas disponible pour cette imprimante.","Für diesen Drucker ist keine Lichtsteuerung verfügbar.","此打印机不支持照明控制。"],
  "Choose a printer to view its controls.":["Wybierz drukarkę, aby zobaczyć jej panel.","Elige una impresora para ver sus controles.","Choisissez une imprimante pour afficher ses commandes.","Wähle einen Drucker, um seine Steuerung anzuzeigen.","选择打印机以查看其控制选项。"],
  "Add your first printer to get started.":["Dodaj pierwszą drukarkę, aby rozpocząć.","Añade tu primera impresora para empezar.","Ajoutez votre première imprimante pour commencer.","Füge deinen ersten Drucker hinzu, um loszulegen.","添加第一台打印机以开始使用。"],
  "The printer did not confirm the light change. Try again.":["Drukarka nie potwierdziła zmiany lampki. Spróbuj ponownie.","La impresora no confirmó el cambio de luz. Inténtalo de nuevo.","L’imprimante n’a pas confirmé le changement d’éclairage. Réessayez.","Der Drucker hat die Lichtänderung nicht bestätigt. Versuche es erneut.","打印机未确认照明状态变化。请重试。"],
  "Printer light is unavailable. Wait for the printer to connect and try again.":["Lampka jest niedostępna. Poczekaj na połączenie z drukarką i spróbuj ponownie.","La luz no está disponible. Espera a que la impresora se conecte e inténtalo de nuevo.","L’éclairage n’est pas disponible. Attendez que l’imprimante se connecte et réessayez.","Die Beleuchtung ist nicht verfügbar. Warte auf die Verbindung zum Drucker und versuche es erneut.","照明不可用。请等待打印机连接后重试。"],
  "Copyright 2026 © PrintDeck ·":["Copyright 2026 © PrintDeck ·","Copyright 2026 © PrintDeck ·","Copyright 2026 © PrintDeck ·","Copyright 2026 © PrintDeck ·","Copyright 2026 © PrintDeck ·"],
  "Contact Support":["Skontaktuj się z pomocą","Contactar con soporte","Contacter l’assistance","Support kontaktieren","联系支持"],
  "License":["Licencja","Licencia","Licence","Lizenz","许可证"],
  "Notice":["Informacje prawne","Avis","Mentions","Hinweise","法律声明"],
  "Reactions":["Reakcje","Reacciones","Réactions","Reaktionen","反应"],
  "Choose how PrintDeck reacts when the printer changes state.":["Wybierz, jak PrintDeck reaguje na zmianę stanu drukarki.","Elige cómo reacciona PrintDeck cuando cambia el estado de la impresora.","Choisissez comment PrintDeck réagit lorsque l’état de l’imprimante change.","Lege fest, wie PrintDeck auf Statusänderungen des Druckers reagiert.","选择打印机状态变化时 PrintDeck 的反应方式。"],
  "Enable reactions":["Włącz reakcje","Activar reacciones","Activer les réactions","Reaktionen aktivieren","启用反应"],
  "Show the dedicated reactions screen when the printer changes state.":["Pokazuj osobny ekran reakcji, gdy zmienia się stan drukarki.","Muestra la pantalla de reacciones cuando cambia el estado de la impresora.","Affichez l’écran de réactions lorsque l’état de l’imprimante change.","Zeige bei Statusänderungen des Druckers den Reaktionsbildschirm.","打印机状态变化时显示专用反应屏幕。"],
  "Show progress indicator":["Pokaż wskaźnik postępu","Mostrar indicador de progreso","Afficher l’indicateur de progression","Fortschrittsanzeige anzeigen","显示进度指示器"],
  "Show a ring on round displays or a bar on square displays.":["Na okrągłym ekranie pokazuje pierścień, a na kwadratowym pasek.","Muestra un anillo en pantallas redondas y una barra en pantallas cuadradas.","Affiche un anneau sur les écrans ronds et une barre sur les écrans carrés.","Zeigt auf runden Displays einen Ring und auf quadratischen einen Balken.","圆形屏幕显示进度环，方形屏幕显示进度条。"],
  "Show percentage":["Pokaż wartość procentową","Mostrar porcentaje","Afficher le pourcentage","Prozentwert anzeigen","显示百分比"],
  "Show the print percentage above the reaction.":["Pokazuje procent postępu druku nad reakcją.","Muestra el porcentaje de impresión sobre la reacción.","Affiche le pourcentage d’impression au-dessus de la réaction.","Zeigt den Druckfortschritt in Prozent über der Reaktion.","在反应画面上方显示打印百分比。"],
  "Reaction sets":["Zestawy reakcji","Conjuntos de reacciones","Jeux de réactions","Reaktionssets","反应套装"],
  "Only the active set is kept on PrintDeck. A new set is validated before it replaces the current one.":["PrintDeck przechowuje tylko aktywny zestaw. Nowy zestaw jest sprawdzany przed zastąpieniem bieżącego.","PrintDeck solo conserva el conjunto activo. El nuevo se valida antes de sustituir al actual.","PrintDeck ne conserve que le jeu actif. Le nouveau est validé avant de remplacer l’actuel.","PrintDeck behält nur das aktive Set. Ein neues Set wird vor dem Austausch geprüft.","PrintDeck 仅保留当前套装。新套装会在替换前完成验证。"],
  "Reaction events":["Zdarzenia reakcji","Eventos de reacción","Événements de réaction","Reaktionsereignisse","反应事件"],
  "Replace the image shown for any printer event, or stop PrintDeck from showing a reaction for that event. Supported formats: GIF, PNG, JPEG, WebP, AVIF and BMP; HEIC and HEIF when supported by your browser. Drag and drop a file onto a reaction slot.":["Zastąp obraz wyświetlany dla dowolnego zdarzenia drukarki albo wyłącz wyświetlanie reakcji dla tego zdarzenia. Obsługiwane formaty: GIF, PNG, JPEG, WebP, AVIF i BMP; HEIC i HEIF, jeśli obsługuje je przeglądarka. Przeciągnij i upuść plik na kafelek reakcji.","Sustituye la imagen que se muestra para cualquier evento de la impresora o impide que PrintDeck muestre una reacción para ese evento. Formatos compatibles: GIF, PNG, JPEG, WebP, AVIF y BMP; HEIC y HEIF si el navegador los admite. Arrastra y suelta un archivo sobre una reacción.","Remplacez l’image affichée pour n’importe quel événement de l’imprimante, ou empêchez PrintDeck d’afficher une réaction pour cet événement. Formats pris en charge : GIF, PNG, JPEG, WebP, AVIF et BMP ; HEIC et HEIF si votre navigateur les prend en charge. Glissez-déposez un fichier sur une réaction.","Ersetze das für ein Druckerereignis angezeigte Bild oder verhindere, dass PrintDeck für dieses Ereignis eine Reaktion anzeigt. Unterstützte Formate: GIF, PNG, JPEG, WebP, AVIF und BMP; HEIC und HEIF, wenn dein Browser sie unterstützt. Ziehe eine Datei auf einen Reaktionsplatz.","替换任意打印机事件所显示的图像，或让 PrintDeck 不再为该事件显示反应。支持 GIF、PNG、JPEG、WebP、AVIF 和 BMP；浏览器支持时也可使用 HEIC 和 HEIF。将文件拖放到反应槽位。"],
  "Active":["Aktywny","Activo","Actif","Aktiv","当前"],
  "Custom":["Własny","Personalizado","Personnalisé","Eigen","自定义"],
  "Install":["Zainstaluj","Instalar","Installer","Installieren","安装"],
  "Installed":["Zainstalowany","Instalado","Installé","Installiert","已安装"],
  "Version":["Wersja","Versión","Version","Version","版本"],
  "Animation usage:":["Wykorzystanie na animacje:","Uso de animaciones:","Espace utilisé par les animations :","Animationsspeicher:","动画占用："],
  "Animation storage":["Miejsce na animacje","Espacio para animaciones","Espace des animations","Animationsspeicher","动画存储空间"],
  "Almost full":["Prawie pełne","Casi lleno","Presque plein","Fast voll","即将用尽"],
  "Free space:":["Wolne miejsce:","Espacio libre:","Espace libre :","Freier Speicher:","可用空间："],
  "Animation storage is almost full. Reset a custom GIF to free space.":["Miejsce na animacje jest prawie pełne. Przywróć domyślną animację zamiast jednego z własnych GIF-ów, aby zwolnić miejsce.","El espacio para animaciones está casi lleno. Restablece un GIF personalizado para liberar espacio.","L’espace des animations est presque plein. Rétablissez un GIF personnalisé pour libérer de l’espace.","Der Animationsspeicher ist fast voll. Setze ein eigenes GIF zurück, um Speicher freizugeben.","动画存储空间即将用尽。请重置一个自定义 GIF 以释放空间。"],
  "Available for this reaction:":["Dostępne dla tej reakcji:","Disponible para esta reacción:","Disponible pour cette réaction :","Für diese Reaktion verfügbar:","此反应可用空间："],
  "Loading reaction sets…":["Ładowanie zestawów reakcji…","Cargando conjuntos de reacciones…","Chargement des jeux de réactions…","Reaktionssets werden geladen…","正在加载反应套装…"],
  "Loading reaction events…":["Ładowanie zdarzeń reakcji…","Cargando eventos de reacción…","Chargement des événements de réaction…","Reaktionsereignisse werden geladen…","正在加载反应事件…"],
  "Waiting for PrintDeck…":["Oczekiwanie na PrintDeck…","Esperando a PrintDeck…","En attente de PrintDeck…","Warten auf PrintDeck…","正在等待 PrintDeck…"],
  "Green":["Zielony","Verde","Vert","Grün","绿色"],
  "Blue":["Niebieski","Azul","Bleu","Blau","蓝色"],
  "Brown":["Brązowy","Marrón","Marron","Braun","棕色"],
  "Amber":["Bursztynowy","Ámbar","Ambre","Bernstein","琥珀色"],
  "Gray":["Szary","Gris","Gris","Grau","灰色"],
  "Hazel":["Piwne","Avellana","Noisette","Hasel","榛色"],
  "Red":["Czerwony","Rojo","Rouge","Rot","红色"],
  "Violet":["Fioletowy","Violeta","Violet","Violett","紫色"],
  "Cyan":["Cyjanowy","Cian","Cyan","Cyan","青色"],
  "Enabled":["Włączona","Activada","Activée","Aktiviert","已启用"],
  "Upload / Replace GIF":["Wgraj / zastąp GIF","Subir / sustituir GIF","Téléverser / remplacer le GIF","GIF hochladen / ersetzen","上传 / 替换 GIF"],
  "Upload / Replace image":["Wgraj / zastąp obraz","Subir / sustituir imagen","Téléverser / remplacer l’image","Bild hochladen / ersetzen","上传 / 替换图像"],
  "Drop to upload":["Upuść, aby wgrać","Suelta para subir","Déposez pour téléverser","Zum Hochladen ablegen","拖放以上传"],
  "Adjust GIF":["Dostosuj GIF","Ajustar GIF","Ajuster le GIF","GIF anpassen","调整 GIF"],
  "Adjust image":["Dostosuj obraz","Ajustar imagen","Ajuster l’image","Bild anpassen","调整图像"],
  "Drag the image to position it. Use the slider or mouse wheel to zoom.":["Przeciągnij obraz, aby ustawić kadr. Użyj suwaka lub kółka myszy, aby zmienić powiększenie.","Arrastra la imagen para encuadrarla. Usa el control o la rueda del ratón para ampliar.","Faites glisser l’image pour la cadrer. Utilisez le curseur ou la molette pour zoomer.","Ziehe das Bild in den gewünschten Ausschnitt. Zoome mit dem Regler oder Mausrad.","拖动图像调整位置，使用滑块或鼠标滚轮缩放。"],
  "GIF crop preview":["Podgląd kadrowania GIF-a","Vista previa del recorte del GIF","Aperçu du recadrage du GIF","Vorschau des GIF-Ausschnitts","GIF 裁剪预览"],
  "Final GIF preview":["Podgląd finalnego GIF-a","Vista previa del GIF final","Aperçu du GIF final","Vorschau des fertigen GIFs","最终 GIF 预览"],
  "Image crop preview":["Podgląd kadrowania obrazu","Vista previa del recorte de imagen","Aperçu du recadrage de l’image","Vorschau des Bildausschnitts","图像裁剪预览"],
  "Final image preview":["Podgląd finalnego obrazu","Vista previa de la imagen final","Aperçu de l’image finale","Vorschau des fertigen Bildes","最终图像预览"],
  "Zoom":["Powiększenie","Zoom","Zoom","Zoom","缩放"],
  "Select a 5-second clip":["Wybierz 5-sekundowy fragment","Selecciona un fragmento de 5 segundos","Sélectionnez un extrait de 5 secondes","5-Sekunden-Ausschnitt wählen","选择 5 秒片段"],
  "Select clip":["Wybierz fragment","Selecciona un fragmento","Sélectionnez un extrait","Ausschnitt wählen","选择片段"],
  "Clip length":["Długość fragmentu","Duración del fragmento","Durée de l’extrait","Ausschnittslänge","片段长度"],
  "Animation clip start":["Początek fragmentu animacji","Inicio del fragmento de animación","Début de l’extrait d’animation","Beginn des Animationsausschnitts","动画片段起点"],
  "Drag the 5-second window to choose which part of the animation to upload.":["Przeciągnij 5-sekundowe okno, aby wybrać fragment animacji do wgrania.","Arrastra la ventana de 5 segundos para elegir qué parte de la animación subir.","Faites glisser la fenêtre de 5 secondes pour choisir la partie de l’animation à téléverser.","Ziehe das 5-Sekunden-Fenster auf den Teil der Animation, der hochgeladen werden soll.","拖动 5 秒窗口，选择要上传的动画片段。"],
  "Choose a clip length, then drag the window to select which part to upload.":["Wybierz długość fragmentu, a następnie przeciągnij okno na część animacji, którą chcesz wgrać.","Elige la duración y arrastra la ventana hasta la parte de la animación que quieras subir.","Choisissez la durée, puis faites glisser la fenêtre sur la partie de l’animation à téléverser.","Wähle die Länge und ziehe das Fenster auf den Teil der Animation, der hochgeladen werden soll.","选择片段长度，然后拖动窗口选择要上传的动画部分。"],
  "Source file":["Plik źródłowy","Archivo de origen","Fichier source","Quelldatei","源文件"],
  "Final upload":["Plik do wgrania","Carga final","Fichier final","Finaler Upload","最终上传文件"],
  "Available for this reaction":["Dostępne dla tej reakcji","Disponible para esta reacción","Disponible pour cette réaction","Für diese Reaktion verfügbar","此反应可用空间"],
  "Duration limit":["Limit czasu","Límite de duración","Limite de durée","Zeitlimit","时长限制"],
  "Using the selected 5-second clip.":["Zostanie użyty wybrany 5-sekundowy fragment.","Se usará el fragmento seleccionado de 5 segundos.","L’extrait de 5 secondes sélectionné sera utilisé.","Der ausgewählte 5-Sekunden-Ausschnitt wird verwendet.","将使用所选的 5 秒片段。"],
  "Using the selected clip.":["Zostanie użyty wybrany fragment.","Se usará el fragmento seleccionado.","L’extrait sélectionné sera utilisé.","Der ausgewählte Ausschnitt wird verwendet.","将使用所选片段。"],
  "Still image":["Obraz statyczny","Imagen estática","Image fixe","Standbild","静态图像"],
  "Upload GIF":["Wgraj GIF","Subir GIF","Téléverser le GIF","GIF hochladen","上传 GIF"],
  "Upload image":["Wgraj obraz","Subir imagen","Téléverser l’image","Bild hochladen","上传图像"],
  "Calculating…":["Obliczanie…","Calculando…","Calcul…","Wird berechnet…","正在计算…"],
  "Preparing device preview…":["Przygotowywanie podglądu dla urządzenia…","Preparando la vista previa para el dispositivo…","Préparation de l’aperçu pour l’appareil…","Gerätevorschau wird vorbereitet…","正在准备设备预览…"],
  "Ready for PrintDeck.":["Gotowe do wgrania do PrintDeck.","Listo para PrintDeck.","Prêt pour PrintDeck.","Bereit für PrintDeck.","已为 PrintDeck 准备就绪。"],
  "Reset to set default":["Przywróć GIF zestawu","Restablecer GIF del conjunto","Rétablir le GIF du jeu","Set-Standard wiederherstellen","恢复套装默认 GIF"],
  "Preview unavailable":["Podgląd niedostępny","Vista previa no disponible","Aperçu indisponible","Vorschau nicht verfügbar","预览不可用"],
  "Custom GIF override":["Własny GIF","GIF personalizado","GIF personnalisé","Eigenes GIF","自定义 GIF"],
  "Set default":["Domyślny GIF zestawu","GIF del conjunto","GIF du jeu","Set-Standard","套装默认 GIF"],
  "Reaction storage:":["Pamięć reakcji:","Almacenamiento de reacciones:","Stockage des réactions :","Reaktionsspeicher:","反应存储："],
  "Active set limit:":["Limit aktywnego zestawu:","Límite del conjunto activo:","Limite du jeu actif :","Limit des aktiven Sets:","当前套装限制："],
  "Starting reaction set download…":["Rozpoczynanie pobierania zestawu reakcji…","Iniciando la descarga del conjunto…","Démarrage du téléchargement du jeu…","Download des Reaktionssets wird gestartet…","正在开始下载反应套装…"],
  "Install reaction set?":["Zainstalować zestaw reakcji?","¿Instalar el conjunto de reacciones?","Installer le jeu de réactions ?","Reaktionsset installieren?","安装反应套装？"],
  "After the download is validated, this set replaces the active reaction set.":["Po pobraniu i sprawdzeniu plików ten zestaw zastąpi aktywny zestaw reakcji.","Después de descargar y validar los archivos, este conjunto sustituirá al conjunto de reacciones activo.","Après téléchargement et validation des fichiers, ce jeu remplacera le jeu de réactions actif.","Nach dem Herunterladen und Prüfen der Dateien ersetzt dieses Set das aktive Reaktionsset.","文件下载并验证后，此套装将替换当前反应套装。"],
  "Install set":["Zainstaluj zestaw","Instalar conjunto","Installer le jeu","Set installieren","安装套装"],
  "Installing reaction set":["Instalowanie zestawu reakcji","Instalando el conjunto de reacciones","Installation du jeu de réactions","Reaktionsset wird installiert","正在安装反应套装"],
  "The active reaction set remains unchanged until the new set is fully validated.":["Aktywny zestaw reakcji pozostanie bez zmian, dopóki nowy zestaw nie przejdzie pełnej weryfikacji.","El conjunto de reacciones activo no cambia hasta que el nuevo se valide por completo.","Le jeu de réactions actif reste inchangé jusqu’à la validation complète du nouveau jeu.","Das aktive Reaktionsset bleibt unverändert, bis das neue Set vollständig geprüft ist.","新套装完成全部验证前，当前反应套装不会改变。"],
  "Cancel installation":["Anuluj instalację","Cancelar instalación","Annuler l’installation","Installation abbrechen","取消安装"],
  "Cancelling…":["Anulowanie…","Cancelando…","Annulation…","Wird abgebrochen…","正在取消…"],
  "Finishing installation…":["Kończenie instalacji…","Finalizando la instalación…","Finalisation de l’installation…","Installation wird abgeschlossen…","正在完成安装…"],
  "Cancelling reaction set installation…":["Anulowanie instalacji zestawu reakcji…","Cancelando la instalación del conjunto de reacciones…","Annulation de l’installation du jeu de réactions…","Installation des Reaktionssets wird abgebrochen…","正在取消反应套装安装…"],
  "Activating reaction set…":["Aktywowanie zestawu reakcji…","Activando el conjunto de reacciones…","Activation du jeu de réactions…","Reaktionsset wird aktiviert…","正在启用反应套装…"],
  "Reaction set installation cancelled.":["Anulowano instalację zestawu reakcji.","Se canceló la instalación del conjunto de reacciones.","L’installation du jeu de réactions a été annulée.","Die Installation des Reaktionssets wurde abgebrochen.","反应套装安装已取消。"],
  "The reaction set can no longer be cancelled.":["Tego zestawu reakcji nie można już anulować.","La instalación de este conjunto de reacciones ya no se puede cancelar.","L’installation de ce jeu de réactions ne peut plus être annulée.","Die Installation dieses Reaktionssets kann nicht mehr abgebrochen werden.","此反应套装安装已无法取消。"],
  "preview":["podgląd","vista previa","aperçu","Vorschau","预览"],
  "Set default restored.":["Przywrócono domyślny GIF zestawu.","Se restauró el GIF del conjunto.","Le GIF du jeu a été rétabli.","Set-Standard wurde wiederhergestellt.","已恢复套装默认 GIF。"],
  "Restoring set default…":["Przywracanie domyślnego GIF-a zestawu…","Restaurando el GIF predeterminado del conjunto…","Restauration du GIF par défaut du jeu…","Set-Standard-GIF wird wiederhergestellt…","正在恢复套装默认 GIF…"],
  "Checking and optimizing GIF…":["Sprawdzanie i optymalizacja GIF-a…","Comprobando y optimizando el GIF…","Vérification et optimisation du GIF…","GIF wird geprüft und optimiert…","正在检查并优化 GIF…"],
  "frame":["klatka","fotograma","image","Bild","帧"],
  "frames":["klatek","fotogramas","images","Bilder","帧"],
  "Use this GIF":["Użyj tego GIF-a","Usar este GIF","Utiliser ce GIF","Dieses GIF verwenden","使用此 GIF"],
  "Preview ready. Confirm to upload it to PrintDeck.":["Podgląd jest gotowy. Potwierdź, aby wgrać GIF do PrintDeck.","La vista previa está lista. Confirma para subirla a PrintDeck.","L’aperçu est prêt. Confirmez pour le téléverser sur PrintDeck.","Die Vorschau ist fertig. Bestätige den Upload auf PrintDeck.","预览已就绪。确认后上传到 PrintDeck。"],
  "Uploading GIF to PrintDeck…":["Wgrywanie GIF-a do PrintDeck…","Subiendo el GIF a PrintDeck…","Téléversement du GIF vers PrintDeck…","GIF wird auf PrintDeck hochgeladen…","正在将 GIF 上传到 PrintDeck…"],
  "Uploading…":["Wgrywanie…","Subiendo…","Téléversement…","Wird hochgeladen…","正在上传…"],
  "Custom GIF saved.":["Zapisano własny GIF.","GIF personalizado guardado.","GIF personnalisé enregistré.","Eigenes GIF gespeichert.","自定义 GIF 已保存。"],
  "Reaction storage is ready.":["Pamięć reakcji jest gotowa.","El almacenamiento de reacciones está listo.","Le stockage des réactions est prêt.","Der Reaktionsspeicher ist bereit.","反应存储已就绪。"],
  "The reaction set and custom GIFs exceed the 1.5 MB animation limit.":["Zestaw reakcji i własne GIF-y przekraczają limit animacji 1,5 MB.","El conjunto de reacciones y los GIF personalizados superan el límite de animaciones de 1,5 MB.","Le jeu de réactions et les GIF personnalisés dépassent la limite d’animation de 1,5 Mo.","Das Reaktionsset und eigene GIFs überschreiten das Animationslimit von 1,5 MB.","反应套装和自定义 GIF 超过了 1.5 MB 的动画限制。"],
  "Preparing the reaction set…":["Przygotowywanie zestawu reakcji…","Preparando el conjunto de reacciones…","Préparation du jeu de réactions…","Reaktionsset wird vorbereitet…","正在准备反应套装…"],
  "Downloading and validating reaction GIFs…":["Pobieranie i sprawdzanie GIF-ów reakcji…","Descargando y validando los GIF de reacción…","Téléchargement et validation des GIF de réaction…","Reaktions-GIFs werden geladen und geprüft…","正在下载并验证反应 GIF…"],
  "Reaction set installed.":["Zainstalowano zestaw reakcji.","Conjunto de reacciones instalado.","Jeu de réactions installé.","Reaktionsset installiert.","反应套装已安装。"],
  "Reaction set installation failed.":["Instalacja zestawu reakcji nie powiodła się.","No se pudo instalar el conjunto de reacciones.","L’installation du jeu de réactions a échoué.","Die Installation des Reaktionssets ist fehlgeschlagen.","反应套装安装失败。"],
  "The active reaction set was not changed.":["Aktywny zestaw reakcji nie został zmieniony.","El conjunto de reacciones activo no se ha cambiado.","Le jeu de réactions actif n’a pas été modifié.","Das aktive Reaktionsset wurde nicht geändert.","当前反应套装未更改。"],
  "The reaction set could not be installed.":["Nie udało się zainstalować zestawu reakcji.","No se pudo instalar el conjunto de reacciones.","Le jeu de réactions n’a pas pu être installé.","Das Reaktionsset konnte nicht installiert werden.","无法安装反应套装。"],
  "Reaction storage is unavailable.":["Pamięć reakcji jest niedostępna.","El almacenamiento de reacciones no está disponible.","Le stockage des réactions est indisponible.","Der Reaktionsspeicher ist nicht verfügbar.","反应存储不可用。"],
  "Connect PrintDeck to Wi-Fi before changing reaction sets.":["Połącz PrintDeck z Wi-Fi przed zmianą zestawu reakcji.","Conecta PrintDeck a una red Wi-Fi antes de cambiar el conjunto de reacciones.","Connectez PrintDeck au Wi-Fi avant de changer de jeu de réactions.","Verbinde PrintDeck mit dem WLAN, bevor du das Reaktionsset wechselst.","更换反应套装前，请先将 PrintDeck 连接到 Wi-Fi。"],
  "The reaction set could not be downloaded from GitHub.":["Nie udało się pobrać zestawu reakcji z GitHub.","No se pudo descargar el conjunto de reacciones desde GitHub.","Le jeu de réactions n’a pas pu être téléchargé depuis GitHub.","Das Reaktionsset konnte nicht von GitHub geladen werden.","无法从 GitHub 下载反应套装。"],
  "The reaction set manifest did not pass validation.":["Manifest zestawu reakcji nie przeszedł weryfikacji.","El manifiesto del conjunto de reacciones no superó la validación.","Le manifeste du jeu de réactions n’a pas réussi la validation.","Das Manifest des Reaktionssets konnte nicht validiert werden.","反应套装清单未通过验证。"],
  "PrintDeck could not prepare reaction storage.":["PrintDeck nie mógł przygotować pamięci reakcji.","PrintDeck no pudo preparar el almacenamiento de reacciones.","PrintDeck n’a pas pu préparer le stockage des réactions.","PrintDeck konnte den Reaktionsspeicher nicht vorbereiten.","PrintDeck 无法准备反应存储。"],
  "PrintDeck needs more free reaction storage to change sets safely.":["PrintDeck potrzebuje więcej wolnego miejsca na reakcje, aby bezpiecznie zmienić zestaw.","PrintDeck necesita más espacio libre para reacciones para cambiar de conjunto de forma segura.","PrintDeck a besoin de plus d’espace libre pour les réactions afin de changer de jeu en toute sécurité.","PrintDeck benötigt mehr freien Reaktionsspeicher, um das Set sicher zu wechseln.","PrintDeck 需要更多可用反应存储空间，才能安全更换套装。"],
  "A reaction GIF was incomplete or did not match its checksum.":["GIF reakcji był niekompletny albo nie zgadzała się jego suma kontrolna.","Un GIF de reacción estaba incompleto o no coincidía con su suma de comprobación.","Un GIF de réaction était incomplet ou sa somme de contrôle ne correspondait pas.","Ein Reaktions-GIF war unvollständig oder seine Prüfsumme stimmte nicht.","反应 GIF 不完整或校验和不匹配。"],
  "A reaction GIF did not pass device validation.":["GIF reakcji nie przeszedł weryfikacji na urządzeniu.","Un GIF de reacción no superó la validación del dispositivo.","Un GIF de réaction n’a pas réussi la validation sur l’appareil.","Ein Reaktions-GIF konnte auf dem Gerät nicht validiert werden.","反应 GIF 未通过设备验证。"],
  "The current reaction set could not be preserved.":["Nie udało się zabezpieczyć bieżącego zestawu reakcji.","No se pudo conservar el conjunto de reacciones actual.","Le jeu de réactions actuel n’a pas pu être conservé.","Das aktuelle Reaktionsset konnte nicht gesichert werden.","无法保留当前反应套装。"],
  "The new reaction set could not be activated.":["Nie udało się aktywować nowego zestawu reakcji.","No se pudo activar el nuevo conjunto de reacciones.","Le nouveau jeu de réactions n’a pas pu être activé.","Das neue Reaktionsset konnte nicht aktiviert werden.","无法启用新的反应套装。"],
  "Choose a valid reaction set.":["Wybierz prawidłowy zestaw reakcji.","Elige un conjunto de reacciones válido.","Choisissez un jeu de réactions valide.","Wähle ein gültiges Reaktionsset.","请选择有效的反应套装。"],
  "Reaction set preview not found.":["Nie znaleziono podglądu zestawu reakcji.","No se encontró la vista previa del conjunto de reacciones.","L’aperçu du jeu de réactions est introuvable.","Die Vorschau des Reaktionssets wurde nicht gefunden.","找不到反应套装预览。"],
  "Another reaction change is already in progress.":["Trwa już inna zmiana reakcji.","Ya hay otro cambio de reacciones en curso.","Une autre modification des réactions est déjà en cours.","Eine andere Reaktionsänderung läuft bereits.","另一项反应更改正在进行中。"],
  "Choose a valid reaction.":["Wybierz prawidłową reakcję.","Elige una reacción válida.","Choisissez une réaction valide.","Wähle eine gültige Reaktion.","请选择有效的反应。"],
  "The reaction change could not be saved.":["Nie udało się zapisać zmiany reakcji.","No se pudo guardar el cambio de reacción.","La modification de la réaction n’a pas pu être enregistrée.","Die Reaktionsänderung konnte nicht gespeichert werden.","无法保存反应更改。"],
  "The GIF is larger than this device allows.":["GIF jest większy niż dopuszcza to urządzenie.","El GIF supera el tamaño permitido por este dispositivo.","Le GIF dépasse la taille autorisée par cet appareil.","Das GIF ist größer als auf diesem Gerät erlaubt.","GIF 超过此设备允许的大小。"],
  "There is not enough memory to receive this GIF.":["Brakuje pamięci, aby odebrać ten GIF.","No hay memoria suficiente para recibir este GIF.","La mémoire disponible est insuffisante pour recevoir ce GIF.","Der Speicher reicht nicht aus, um dieses GIF zu empfangen.","没有足够内存接收此 GIF。"],
  "The GIF upload was incomplete.":["Wgrywanie GIF-a nie zostało ukończone.","La carga del GIF quedó incompleta.","Le téléversement du GIF est incomplet.","Der GIF-Upload war unvollständig.","GIF 上传不完整。"],
  "The GIF did not pass device validation.":["GIF nie przeszedł weryfikacji na urządzeniu.","El GIF no superó la validación del dispositivo.","Le GIF n’a pas réussi la validation sur l’appareil.","Das GIF konnte auf dem Gerät nicht validiert werden.","GIF 未通过设备验证。"],
  "This GIF does not fit in the remaining animation space. Reset another custom GIF or choose a shorter animation.":["Ten GIF nie mieści się w pozostałym miejscu na animacje. Przywróć inną własną animację do domyślnej albo wybierz krótszy GIF.","Este GIF no cabe en el espacio de animación restante. Restablece otro GIF personalizado o elige una animación más corta.","Ce GIF ne tient pas dans l’espace d’animation restant. Rétablissez un autre GIF personnalisé ou choisissez une animation plus courte.","Dieses GIF passt nicht in den verbleibenden Animationsspeicher. Setze ein anderes eigenes GIF zurück oder wähle eine kürzere Animation.","此 GIF 无法放入剩余的动画空间。请重置另一个自定义 GIF，或选择更短的动画。"],
  "The processed GIF is not compatible with this device. Try another GIF.":["Przetworzony GIF nie jest zgodny z tym urządzeniem. Spróbuj użyć innego GIF-a.","El GIF procesado no es compatible con este dispositivo. Prueba con otro GIF.","Le GIF traité n’est pas compatible avec cet appareil. Essayez un autre GIF.","Das verarbeitete GIF ist mit diesem Gerät nicht kompatibel. Versuche es mit einem anderen GIF.","处理后的 GIF 与此设备不兼容。请尝试其他 GIF。"],
  "PrintDeck could not save this GIF. Try again.":["PrintDeck nie mógł zapisać tego GIF-a. Spróbuj ponownie.","PrintDeck no pudo guardar este GIF. Inténtalo de nuevo.","PrintDeck n’a pas pu enregistrer ce GIF. Réessayez.","PrintDeck konnte dieses GIF nicht speichern. Versuche es erneut.","PrintDeck 无法保存此 GIF。请重试。"],
  "No GIF is available for this reaction.":["Dla tej reakcji nie ma dostępnego GIF-a.","No hay ningún GIF disponible para esta reacción.","Aucun GIF n’est disponible pour cette réaction.","Für diese Reaktion ist kein GIF verfügbar.","此反应没有可用的 GIF。"],
  "The GIF dimensions are invalid.":["Wymiary GIF-a są nieprawidłowe.","Las dimensiones del GIF no son válidas.","Les dimensions du GIF ne sont pas valides.","Die GIF-Abmessungen sind ungültig.","GIF 尺寸无效。"],
  "Use a GIF no larger than 100 MB.":["Użyj GIF-a o rozmiarze nie większym niż 100 MB.","Usa un GIF de 100 MB como máximo.","Utilisez un GIF de 100 Mo maximum.","Verwende ein GIF mit höchstens 100 MB.","请使用不超过 100 MB 的 GIF。"],
  "The GIF is too complex to optimize in this browser.":["GIF jest zbyt złożony, aby zoptymalizować go w tej przeglądarce.","El GIF es demasiado complejo para optimizarlo en este navegador.","Le GIF est trop complexe pour être optimisé dans ce navigateur.","Das GIF ist zu komplex, um es in diesem Browser zu optimieren.","GIF 过于复杂，无法在此浏览器中优化。"],
  "Choose a valid GIF file.":["Wybierz prawidłowy plik GIF.","Elige un archivo GIF válido.","Choisissez un fichier GIF valide.","Wähle eine gültige GIF-Datei.","请选择有效的 GIF 文件。"],
  "Only GIF files are supported.":["Obsługiwane są tylko pliki GIF.","Solo se admiten archivos GIF.","Seuls les fichiers GIF sont pris en charge.","Es werden nur GIF-Dateien unterstützt.","仅支持 GIF 文件。"],
  "The GIF could not be decoded.":["Nie udało się odczytać GIF-a.","No se pudo decodificar el GIF.","Le GIF n’a pas pu être décodé.","Das GIF konnte nicht decodiert werden.","无法解码 GIF。"],
  "Choose a supported image file.":["Wybierz obsługiwany plik obrazu.","Elige un archivo de imagen compatible.","Choisissez un fichier image pris en charge.","Wähle eine unterstützte Bilddatei.","请选择受支持的图像文件。"],
  "Use an image no larger than 100 MB.":["Użyj obrazu o rozmiarze nie większym niż 100 MB.","Usa una imagen de 100 MB como máximo.","Utilisez une image de 100 Mo maximum.","Verwende ein Bild mit höchstens 100 MB.","请使用不超过 100 MB 的图像。"],
  "Use a GIF, PNG, JPEG, WebP, AVIF, BMP, HEIC or HEIF image.":["Użyj obrazu GIF, PNG, JPEG, WebP, AVIF, BMP, HEIC lub HEIF.","Usa una imagen GIF, PNG, JPEG, WebP, AVIF, BMP, HEIC o HEIF.","Utilisez une image GIF, PNG, JPEG, WebP, AVIF, BMP, HEIC ou HEIF.","Verwende ein GIF-, PNG-, JPEG-, WebP-, AVIF-, BMP-, HEIC- oder HEIF-Bild.","请使用 GIF、PNG、JPEG、WebP、AVIF、BMP、HEIC 或 HEIF 图像。"],
  "The animation is too complex to optimize in this browser.":["Animacja jest zbyt złożona, aby zoptymalizować ją w tej przeglądarce.","La animación es demasiado compleja para optimizarla en este navegador.","L’animation est trop complexe pour être optimisée dans ce navigateur.","Die Animation ist zu komplex, um sie in diesem Browser zu optimieren.","动画过于复杂，无法在此浏览器中优化。"],
  "The image dimensions are invalid.":["Wymiary obrazu są nieprawidłowe.","Las dimensiones de la imagen no son válidas.","Les dimensions de l’image ne sont pas valides.","Die Bildabmessungen sind ungültig.","图像尺寸无效。"],
  "The image could not be decoded.":["Nie udało się odczytać obrazu.","No se pudo decodificar la imagen.","L’image n’a pas pu être décodée.","Das Bild konnte nicht decodiert werden.","无法解码图像。"],
  "This browser cannot read HEIC or HEIF images. Convert the photo to JPEG or PNG and try again.":["Ta przeglądarka nie potrafi odczytać obrazu HEIC ani HEIF. Przekonwertuj zdjęcie do JPEG lub PNG i spróbuj ponownie.","Este navegador no puede leer imágenes HEIC ni HEIF. Convierte la foto a JPEG o PNG y vuelve a intentarlo.","Ce navigateur ne peut pas lire les images HEIC ou HEIF. Convertissez la photo en JPEG ou PNG, puis réessayez.","Dieser Browser kann HEIC- oder HEIF-Bilder nicht lesen. Konvertiere das Foto in JPEG oder PNG und versuche es erneut.","此浏览器无法读取 HEIC 或 HEIF 图像。请将照片转换为 JPEG 或 PNG 后重试。"],
  "The optimized GIF is still too large for this device.":["Zoptymalizowany GIF nadal jest za duży dla tego urządzenia.","El GIF optimizado sigue siendo demasiado grande para este dispositivo.","Le GIF optimisé est encore trop volumineux pour cet appareil.","Das optimierte GIF ist für dieses Gerät noch zu groß.","优化后的 GIF 对此设备仍然过大。"],
  "Standby":["Gotowość","En espera","Veille","Bereit","待机"],
  "Preparing":["Przygotowanie","Preparando","Préparation","Vorbereitung","准备中"],
  "Heating nozzle":["Nagrzewanie dyszy","Calentando boquilla","Chauffe de la buse","Düse wird geheizt","喷嘴加热"],
  "Heating bed":["Nagrzewanie stołu","Calentando cama","Chauffe du plateau","Druckbett wird geheizt","热床加热"],
  "Homing toolhead":["Bazowanie głowicy","Referenciando cabezal","Origine de la tête","Druckkopf referenzieren","工具头归位"],
  "Leveling the bed":["Poziomowanie stołu","Nivelando la cama","Nivellement du plateau","Druckbett nivellieren","热床调平"],
  "Cleaning nozzle":["Czyszczenie dyszy","Limpiando boquilla","Nettoyage de la buse","Düse reinigen","喷嘴清洁"],
  "Calibrating":["Kalibracja","Calibrando","Étalonnage","Kalibrierung","校准中"],
  "Changing filament":["Zmiana filamentu","Cambiando filamento","Changement de filament","Filamentwechsel","更换耗材"],
  "Unloading filament":["Wyładowywanie filamentu","Descargando filamento","Déchargement du filament","Filament entladen","卸载耗材"],
  "Loading filament":["Ładowanie filamentu","Cargando filamento","Chargement du filament","Filament laden","装载耗材"],
  "Purging filament":["Przepłukiwanie filamentu","Purgando filamento","Purge du filament","Filament spülen","清理耗材"],
  "Printing":["Drukowanie","Imprimiendo","Impression","Drucken","打印中"],
  "Paused":["Pauza","En pausa","En pause","Pausiert","已暂停"],
  "Complete":["Ukończono","Completado","Terminé","Fertig","已完成"],
  "Failed":["Błąd","Fallido","Échec","Fehlgeschlagen","失败"],
  "Cancelled":["Anulowano","Cancelado","Annulé","Abgebrochen","已取消"],
  "Unavailable":["Niedostępna","No disponible","Indisponible","Nicht verfügbar","不可用"],
  "Printer animations":["Animacje drukarki","Animaciones de la impresora","Animations de l’imprimante","Druckeranimationen","打印机动画"],
  "Add a dedicated, theme-matched reactions screen before the printer status screens.":["Dodaj osobny ekran reakcji dopasowany do motywu przed ekranami stanu drukarki.","Añade una pantalla de reacciones adaptada al tema antes de las pantallas de estado de la impresora.","Ajoutez un écran de réactions assorti au thème avant les écrans d’état de l’imprimante.","Füge vor den Druckerstatusseiten einen eigenen, zum Design passenden Reaktionsbildschirm hinzu.","在打印机状态页面之前添加一个与主题匹配的独立反应屏幕。"],
  "Screen background":["Tło ekranu","Fondo de pantalla","Arrière-plan de l’écran","Bildschirmhintergrund","屏幕背景"],
  "Sounds":["Dźwięki","Sonidos","Sons","Töne","声音"],
  "Camera":["Kamera","Cámara","Caméra","Kamera","摄像头"],
  "Choose how camera pages start. Live is used only when the selected printer supports a safe continuous stream.":["Wybierz tryb otwierania ekranu kamery. Tryb na żywo jest używany tylko wtedy, gdy wybrana drukarka obsługuje bezpieczny ciągły strumień.","Elige cómo se abren las páginas de cámara. El modo en directo solo se usa cuando la impresora seleccionada admite una transmisión continua segura.","Choisissez le mode d’ouverture des pages caméra. Le direct n’est utilisé que si l’imprimante sélectionnée prend en charge un flux continu sûr.","Lege fest, wie Kameraseiten starten. Live wird nur verwendet, wenn der ausgewählte Drucker einen sicheren kontinuierlichen Stream unterstützt.","选择摄像头页面的启动方式。仅当所选打印机支持安全的连续视频流时才使用实时模式。"],
  "Default camera mode":["Domyślny tryb kamery","Modo de cámara predeterminado","Mode caméra par défaut","Standard-Kameramodus","默认摄像头模式"],
  "Snapshots":["Migawki","Instantáneas","Instantanés","Momentaufnahmen","快照"],
  "Live":["Na żywo","En directo","En direct","Live","实时"],
  "Snapshot refresh rate":["Częstotliwość odświeżania migawek","Frecuencia de actualización de instantáneas","Fréquence d’actualisation des instantanés","Aktualisierungsrate der Momentaufnahmen","快照刷新率"],
  "1 frame per second":["1 klatka na sekundę","1 fotograma por segundo","1 image par seconde","1 Bild pro Sekunde","每秒 1 帧"],
  "2 frames per second":["2 klatki na sekundę","2 fotogramas por segundo","2 images par seconde","2 Bilder pro Sekunde","每秒 2 帧"],
  "5 frames per second":["5 klatek na sekundę","5 fotogramas por segundo","5 images par seconde","5 Bilder pro Sekunde","每秒 5 帧"],
  "The camera backend may lower this rate when the printer or display needs it.":["Obsługa kamery może obniżyć tę częstotliwość, jeśli wymaga tego drukarka lub ekran.","El sistema de cámara puede reducir esta frecuencia si la impresora o la pantalla lo necesitan.","Le système de caméra peut réduire cette fréquence si l’imprimante ou l’écran l’exige.","Die Kamera kann diese Rate verringern, wenn Drucker oder Display es erfordern.","摄像头系统可能会根据打印机或屏幕的需要降低此刷新率。"],
  "Save camera settings":["Zapisz ustawienia kamery","Guardar ajustes de cámara","Enregistrer les réglages de la caméra","Kameraeinstellungen speichern","保存摄像头设置"],
  "Connected Printers":["Połączone drukarki","Impresoras conectadas","Imprimantes connectées","Verbundene Drucker","已连接的打印机"],
  "Choose the printer PrintDeck should monitor, or use the gear to manage a saved connection.":["Wybierz drukarkę monitorowaną przez PrintDeck lub użyj koła zębatego, aby zarządzać zapisanym połączeniem.","Elige la impresora que PrintDeck debe supervisar o usa el engranaje para gestionar una conexión guardada.","Choisissez l’imprimante à surveiller ou utilisez l’engrenage pour gérer une connexion enregistrée.","Wähle den zu überwachenden Drucker oder verwalte eine gespeicherte Verbindung über das Zahnrad.","选择 PrintDeck 要监控的打印机，或使用齿轮管理已保存的连接。"],
  "Checks when offline printers are back online.":["Sprawdza, czy drukarki są znów online.","Comprueba cuándo vuelven las impresoras.","Vérifie si les imprimantes sont de nouveau en ligne.","Prüft, ob Drucker wieder online sind.","检查离线打印机何时重新上线。"],
  "Refresh: Off":["Odświeżanie: wyłączone","Actualización: desactivada","Actualisation : désactivée","Aktualisierung: aus","刷新：关闭"],
  "Refresh every 30 seconds":["Odświeżaj co 30 sekund","Actualizar cada 30 segundos","Actualiser toutes les 30 secondes","Alle 30 Sekunden aktualisieren","每 30 秒刷新"],
  "Refresh every 60 seconds":["Odświeżaj co 60 sekund","Actualizar cada 60 segundos","Actualiser toutes les 60 secondes","Alle 60 Sekunden aktualisieren","每 60 秒刷新"],
  "Refresh every 3 minutes":["Odświeżaj co 3 minuty","Actualizar cada 3 minutos","Actualiser toutes les 3 minutes","Alle 3 Minuten aktualisieren","每 3 分钟刷新"],
  "Refresh every 5 minutes":["Odświeżaj co 5 minut","Actualizar cada 5 minutos","Actualiser toutes les 5 minutes","Alle 5 Minuten aktualisieren","每 5 分钟刷新"],
  "Choose a Theme":["Wybierz motyw","Elige un tema","Choisissez un thème","Design auswählen","选择主题"],
  "Each theme transforms the complete PrintDeck interface.":["Każdy motyw zmienia cały interfejs PrintDeck.","Cada tema transforma toda la interfaz de PrintDeck.","Chaque thème transforme toute l’interface PrintDeck.","Jedes Design verändert die gesamte PrintDeck-Oberfläche.","每个主题都会改变整个 PrintDeck 界面。"],
  "CUSTOM — Your Colors":["WŁASNY — Twoje kolory","PERSONALIZADO — Tus colores","PERSONNALISÉ — Vos couleurs","EIGENES — Deine Farben","自定义 — 你的颜色"],
  "Color changes are applied immediately to the preview and your PrintDeck screen.":["Zmiany kolorów są od razu stosowane w podglądzie i na ekranie PrintDeck.","Los cambios de color se aplican al instante a la vista previa y a la pantalla de PrintDeck.","Les couleurs sont appliquées immédiatement à l’aperçu et à l’écran PrintDeck.","Farbänderungen werden sofort auf Vorschau und PrintDeck-Display angewendet.","颜色更改会立即应用到预览和 PrintDeck 屏幕。"],
  "Set everyday brightness and choose automatic or fixed orientation.":["Ustaw codzienną jasność oraz automatyczną lub stałą orientację.","Ajusta el brillo habitual y elige orientación automática o fija.","Réglez la luminosité et choisissez une orientation automatique ou fixe.","Alltagshelligkeit sowie automatische oder feste Ausrichtung festlegen.","设置日常亮度并选择自动或固定方向。"],
  "Save battery without hiding an active print. Setup, camera and firmware updates always keep the display awake.":["Oszczędzaj baterię bez ukrywania aktywnego wydruku. Konfiguracja, kamera i aktualizacje zawsze utrzymują ekran włączony.","Ahorra batería sin ocultar una impresión activa. La configuración, la cámara y las actualizaciones mantienen la pantalla activa.","Économisez la batterie sans masquer une impression active. La configuration, la caméra et les mises à jour gardent l’écran actif.","Akku sparen, ohne einen aktiven Druck auszublenden. Einrichtung, Kamera und Updates halten das Display immer aktiv.","在不隐藏打印任务的情况下省电。设置、摄像头和固件更新期间屏幕始终保持唤醒。"],
  "Dimmed brightness":["Jasność po przyciemnieniu","Brillo atenuado","Luminosité atténuée","Gedimmte Helligkeit","调暗后的亮度"],
  "Dim while idle":["Przyciemnij w bezczynności","Atenuar en reposo","Atténuer en veille","Im Leerlauf dimmen","空闲时调暗"],
  "Dim during a print":["Przyciemnij podczas druku","Atenuar durante la impresión","Atténuer pendant l’impression","Während des Drucks dimmen","打印时调暗"],
  "Turn off on battery":["Wyłączaj na baterii","Apagar con batería","Éteindre sur batterie","Im Akkubetrieb ausschalten","使用电池时关闭"],
  "Use these savings on USB power":["Stosuj te oszczędności przy zasilaniu USB","Usar este ahorro con alimentación USB","Utiliser ces économies sur alimentation USB","Diese Energiesparoptionen bei USB-Strom verwenden","USB 供电时也使用这些节能设置"],
  "No, stay awake":["Nie, pozostaw włączony","No, mantener activa","Non, rester allumé","Nein, eingeschaltet lassen","否，保持唤醒"],
  "Yes":["Tak","Sí","Oui","Ja","是"],
  "Screen off while idle":["Wyłącz ekran w bezczynności","Apagar pantalla en reposo","Éteindre l’écran en veille","Display im Leerlauf ausschalten","空闲时关闭屏幕"],
  "Screen off during a print":["Wyłącz ekran podczas druku","Apagar pantalla durante la impresión","Éteindre l’écran pendant l’impression","Display während des Drucks ausschalten","打印时关闭屏幕"],
  "Check printers that are not currently selected so every card stays useful. Both Moonraker and Bambu Lab connections are refreshed locally.":["Sprawdzaj także niewybrane drukarki, aby każda karta była aktualna. Połączenia Moonraker i Bambu Lab są odświeżane lokalnie.","Comprueba también las impresoras no seleccionadas para mantener cada tarjeta actualizada. Las conexiones Moonraker y Bambu Lab se actualizan localmente.","Vérifiez aussi les imprimantes non sélectionnées pour garder chaque carte à jour. Les connexions Moonraker et Bambu Lab sont actualisées localement.","Auch nicht ausgewählte Drucker prüfen, damit jede Karte aktuell bleibt. Moonraker- und Bambu-Lab-Verbindungen werden lokal aktualisiert.","同时检查未选中的打印机，使每张卡片保持最新。Moonraker 和 Bambu Lab 连接均在本地刷新。"],
  "Every 30 seconds":["Co 30 sekund","Cada 30 segundos","Toutes les 30 secondes","Alle 30 Sekunden","每 30 秒"],
  "Every 60 seconds":["Co 60 sekund","Cada 60 segundos","Toutes les 60 secondes","Alle 60 Sekunden","每 60 秒"],
  "Every 3 minutes":["Co 3 minuty","Cada 3 minutos","Toutes les 3 minutes","Alle 3 Minuten","每 3 分钟"],
  "Every 5 minutes":["Co 5 minut","Cada 5 minutos","Toutes les 5 minutes","Alle 5 Minuten","每 5 分钟"],
  "Control the short tones used for status changes, orientation and system feedback.":["Steruj krótkimi dźwiękami zmian stanu, orientacji i potwierdzeń systemowych.","Controla los tonos breves de cambios de estado, orientación y confirmaciones del sistema.","Réglez les sons brefs des changements d’état, d’orientation et des confirmations système.","Kurze Töne für Statusänderungen, Ausrichtung und Systembestätigungen steuern.","控制状态变化、方向和系统反馈使用的短提示音。"],
  "Mute sound":["Wycisz dźwięk","Silenciar sonido","Couper le son","Ton stummschalten","静音"],
  "Choose the local time used for clocks and on-screen estimates. The current UTC offset is shown beside each city.":["Wybierz czas lokalny używany przez zegary i szacunki na ekranie. Przy każdym mieście widoczne jest bieżące przesunięcie UTC.","Elige la hora local de los relojes y estimaciones en pantalla. Junto a cada ciudad se muestra el desfase UTC actual.","Choisissez l’heure locale des horloges et estimations. Le décalage UTC actuel apparaît près de chaque ville.","Lokale Zeit für Uhren und Schätzungen wählen. Neben jeder Stadt steht der aktuelle UTC-Versatz.","选择时钟和屏幕估算使用的本地时间。每个城市旁会显示当前 UTC 偏移。"],
  "Choose time zone on world map":["Wybierz strefę czasową na mapie świata","Elegir zona horaria en el mapa mundial","Choisir le fuseau sur la carte du monde","Zeitzone auf der Weltkarte wählen","在世界地图上选择时区"],
  "Choose on world map":["Wybierz na mapie świata","Elegir en el mapa mundial","Choisir sur la carte du monde","Auf der Weltkarte wählen","在世界地图上选择"],
  "Update available":["Dostępna aktualizacja","Actualización disponible","Mise à jour disponible","Update verfügbar","有可用更新"],
  "Check the official release channel and install a validated update over Wi-Fi.":["Sprawdź oficjalny kanał wydań i zainstaluj zweryfikowaną aktualizację przez Wi‑Fi.","Consulta el canal oficial e instala una actualización validada por Wi‑Fi.","Consultez le canal officiel et installez une mise à jour validée par Wi‑Fi.","Offiziellen Release-Kanal prüfen und ein validiertes Update über WLAN installieren.","检查官方发布渠道并通过 Wi-Fi 安装已验证的更新。"],
  "Firmware update progress":["Postęp aktualizacji oprogramowania","Progreso de actualización del firmware","Progression de la mise à jour","Fortschritt der Firmware-Aktualisierung","固件更新进度"],
  "Loading update status…":["Wczytywanie stanu aktualizacji…","Cargando estado de actualización…","Chargement de l’état de mise à jour…","Update-Status wird geladen…","正在加载更新状态…"],
  "Choose an official PrintDeck release, install from a direct link or upload a firmware file. The display stays awake throughout installation.":["Wybierz oficjalne wydanie PrintDeck, zainstaluj je z bezpośredniego linku lub wgraj plik firmware. Ekran pozostaje włączony przez całą instalację.","Elige una versión oficial, instala desde un enlace directo o sube un archivo de firmware. La pantalla permanece activa durante la instalación.","Choisissez une version officielle, un lien direct ou un fichier de micrologiciel. L’écran reste allumé pendant l’installation.","Offizielles PrintDeck-Release wählen, direkten Link nutzen oder Firmware-Datei hochladen. Das Display bleibt während der Installation aktiv.","选择官方 PrintDeck 版本、使用直接链接安装或上传固件文件。安装期间屏幕会保持唤醒。"],
  "Install an official release":["Zainstaluj oficjalne wydanie","Instalar una versión oficial","Installer une version officielle","Offizielles Release installieren","安装官方版本"],
  "Loading official releases…":["Wczytywanie oficjalnych wydań…","Cargando versiones oficiales…","Chargement des versions officielles…","Offizielle Releases werden geladen…","正在加载官方版本…"],
  "Open this section while connected to the internet to load official releases.":["Otwórz tę sekcję przy połączeniu z internetem, aby wczytać oficjalne wydania.","Abre esta sección con conexión a internet para cargar las versiones oficiales.","Ouvrez cette section avec Internet pour charger les versions officielles.","Diesen Bereich mit Internetverbindung öffnen, um offizielle Releases zu laden.","连接互联网后打开此部分以加载官方版本。"],
  "Install from an HTTPS URL":["Zainstaluj z adresu HTTPS","Instalar desde una URL HTTPS","Installer depuis une URL HTTPS","Von HTTPS-URL installieren","从 HTTPS 网址安装"],
  "Upload an official .bin file":["Wgraj oficjalny plik .bin","Subir un archivo .bin oficial","Téléverser un fichier .bin officiel","Offizielle .bin-Datei hochladen","上传官方 .bin 文件"],
  "Connect PrintDeck to the same local network as your printers.":["Połącz PrintDeck z tą samą siecią lokalną co drukarki.","Conecta PrintDeck a la misma red local que tus impresoras.","Connectez PrintDeck au même réseau local que vos imprimantes.","PrintDeck mit demselben lokalen Netzwerk wie die Drucker verbinden.","将 PrintDeck 连接到打印机所在的同一本地网络。"],
  "Connected to:":["Połączono z:","Conectado a:","Connecté à :","Verbunden mit:","已连接到："],
  "Preparing nearby networks…":["Przygotowywanie pobliskich sieci…","Preparando redes cercanas…","Préparation des réseaux proches…","Netzwerke in der Nähe werden vorbereitet…","正在准备附近的网络…"],
  "Language":["Język","Idioma","Langue","Sprache","语言"],
  "Page appearance":["Wygląd strony","Apariencia de la página","Apparence de la page","Seitendarstellung","页面外观"],
  "Light appearance":["Jasny wygląd","Apariencia clara","Apparence claire","Helle Darstellung","浅色外观"],
  "Dark appearance":["Ciemny wygląd","Apariencia oscura","Apparence sombre","Dunkle Darstellung","深色外观"],
  "Automatic appearance":["Wygląd zgodny z systemem","Apariencia automática","Apparence automatique","Automatische Darstellung","跟随系统外观"],
  "CORE One · MK4/S · XL · MINI/+":["CORE One · MK4/S · XL · MINI/+","CORE One · MK4/S · XL · MINI/+","CORE One · MK4/S · XL · MINI/+","CORE One · MK4/S · XL · MINI/+","CORE One · MK4/S · XL · MINI/+"],
  "Close":["Zamknij","Cerrar","Fermer","Schließen","关闭"],
  "Find my printer on network":["Znajdź drukarkę w sieci","Buscar mi impresora en la red","Trouver mon imprimante sur le réseau","Drucker im Netzwerk finden","在网络中查找打印机"],
  "Scanning network":["Skanowanie sieci","Escaneando la red","Analyse du réseau","Netzwerk wird durchsucht","正在扫描网络"],
  "Scan again":["Skanuj ponownie","Escanear de nuevo","Relancer l’analyse","Erneut suchen","重新扫描"],
  "The current printer search could not be stopped. Please try again.":["Nie udało się zatrzymać bieżącego wyszukiwania drukarek. Spróbuj ponownie.","No se pudo detener la búsqueda de impresoras actual. Inténtalo de nuevo.","La recherche d’imprimantes en cours n’a pas pu être arrêtée. Réessayez.","Die aktuelle Druckersuche konnte nicht beendet werden. Bitte versuche es erneut.","无法停止当前的打印机搜索。请重试。"],
  "Printer name":["Nazwa drukarki","Nombre de la impresora","Nom de l’imprimante","Druckername","打印机名称"],
  "IP address or hostname":["Adres IP lub nazwa hosta","Dirección IP o nombre de host","Adresse IP ou nom d’hôte","IP-Adresse oder Hostname","IP 地址或主机名"],
  "Port":["Port","Puerto","Port","Port","端口"],
  "API key":["Klucz API","Clave API","Clé API","API-Schlüssel","API 密钥"],
  "(optional)":["(opcjonalnie)","(opcional)","(facultatif)","(optional)","（可选）"],
  "Show":["Pokaż","Mostrar","Afficher","Anzeigen","显示"],
  "Hide":["Ukryj","Ocultar","Masquer","Ausblenden","隐藏"],
  "Printer identity":["Tożsamość drukarki","Identidad de la impresora","Identité de l’imprimante","Druckeridentität","打印机身份"],
  "Detect printer":["Wykryj drukarkę","Detectar impresora","Détecter l’imprimante","Drucker erkennen","检测打印机"],
  "Manufacturer":["Producent","Fabricante","Fabricant","Hersteller","制造商"],
  "Model":["Model","Modelo","Modèle","Modell","型号"],
  "Printer serial number":["Numer seryjny drukarki","Número de serie de la impresora","Numéro de série de l’imprimante","Seriennummer des Druckers","打印机序列号"],
  "LAN access code":["Kod dostępu LAN","Código de acceso LAN","Code d’accès LAN","LAN-Zugangscode","LAN 访问码"],
  "Generate report":["Wygeneruj raport","Generar informe","Générer le rapport","Bericht erstellen","生成报告"],
  "Download report":["Pobierz raport","Descargar informe","Télécharger le rapport","Bericht herunterladen","下载报告"],
  "Connect to Wi-Fi":["Połącz z Wi‑Fi","Conectar a Wi‑Fi","Se connecter au Wi‑Fi","Mit WLAN verbinden","连接 Wi-Fi"],
  "Looking for nearby Wi-Fi networks…":["Wyszukiwanie pobliskich sieci Wi‑Fi…","Buscando redes Wi‑Fi cercanas…","Recherche des réseaux Wi‑Fi proches…","Suche nach WLAN-Netzwerken…","正在查找附近的 Wi-Fi 网络…"],
  "Could not scan for Wi-Fi networks. Try again.":["Nie udało się wyszukać sieci Wi‑Fi. Spróbuj ponownie.","No se pudieron buscar redes Wi‑Fi. Inténtalo de nuevo.","Impossible de rechercher les réseaux Wi‑Fi. Réessayez.","WLAN-Netzwerke konnten nicht gesucht werden. Bitte erneut versuchen.","无法扫描 Wi-Fi 网络。请重试。"],
  "Searching nearby networks…":["Wyszukiwanie pobliskich sieci…","Buscando redes cercanas…","Recherche des réseaux proches…","Suche nach Netzwerken…","正在搜索附近的网络…"],
  "Scan networks again":["Przeskanuj sieci ponownie","Volver a buscar redes","Rechercher à nouveau les réseaux","Netzwerke erneut suchen","重新扫描网络"],
  "Show Wi-Fi password":["Pokaż hasło Wi‑Fi","Mostrar contraseña Wi‑Fi","Afficher le mot de passe Wi‑Fi","WLAN-Passwort anzeigen","显示 Wi-Fi 密码"],
  "Show password":["Pokaż hasło","Mostrar contraseña","Afficher le mot de passe","Passwort anzeigen","显示密码"],
  "8-character access code":["8-znakowy kod dostępu","Código de acceso de 8 caracteres","Code d’accès à 8 caractères","8-stelliger Zugangscode","8 位访问码"],
  "Bambu Lab IP address or hostname":["Adres IP lub nazwa hosta Bambu Lab","Dirección IP o nombre de host de Bambu Lab","Adresse IP ou nom d’hôte Bambu Lab","Bambu-Lab-IP-Adresse oder Hostname","Bambu Lab IP 地址或主机名"],
  "Connect directly over local MQTT/TLS using the printer IP, serial number and LAN access code.":["Połącz bezpośrednio przez lokalne MQTT/TLS, używając adresu IP, numeru seryjnego i kodu LAN drukarki.","Conecta directamente por MQTT/TLS local con la IP, el número de serie y el código LAN de la impresora.","Connexion directe en MQTT/TLS local avec l’IP, le numéro de série et le code LAN de l’imprimante.","Direkt über lokales MQTT/TLS mit IP, Seriennummer und LAN-Code verbinden.","使用打印机 IP、序列号和 LAN 访问码通过本地 MQTT/TLS 直接连接。"],
  "Connect through the local Moonraker HTTP API.":["Połącz przez lokalne API HTTP Moonraker.","Conecta mediante la API HTTP local de Moonraker.","Connexion via l’API HTTP locale Moonraker.","Über die lokale Moonraker-HTTP-API verbinden.","通过本地 Moonraker HTTP API 连接。"],
  "To find this code, open the LAN Only Mode or Developer Mode screen on the printer and copy the code shown there. You do not need to enable either option.":["Aby znaleźć ten kod, otwórz na drukarce ekran LAN Only Mode lub Developer Mode i przepisz wyświetlony kod. Nie musisz włączać żadnej z tych opcji.","Para encontrar este código, abre la pantalla LAN Only Mode o Developer Mode en la impresora y copia el código que aparece. No necesitas activar ninguna de las dos opciones.","Pour trouver ce code, ouvrez l’écran LAN Only Mode ou Developer Mode sur l’imprimante et copiez le code affiché. Il n’est pas nécessaire d’activer l’une de ces options.","Öffne am Drucker die Seite LAN Only Mode oder Developer Mode und übernimm den dort angezeigten Code. Du musst keine der beiden Optionen aktivieren.","要查找此访问码，请在打印机上打开“仅局域网模式”或“开发者模式”页面，并复制其中显示的访问码。无需启用任一选项。"],
  "Enter the address to detect manufacturer and model. You can correct both fields.":["Wpisz adres, aby wykryć producenta i model. Oba pola możesz poprawić.","Introduce la dirección para detectar fabricante y modelo. Puedes corregir ambos campos.","Saisissez l’adresse pour détecter le fabricant et le modèle. Vous pouvez corriger les deux champs.","Adresse eingeben, um Hersteller und Modell zu erkennen. Beide Felder können korrigiert werden.","输入地址以检测制造商和型号。两个字段均可修改。"],
  "Enter the connection details, then generate the report.":["Wpisz dane połączenia, a następnie wygeneruj raport.","Introduce los datos de conexión y genera el informe.","Saisissez les informations de connexion, puis générez le rapport.","Verbindungsdaten eingeben und anschließend den Bericht erstellen.","输入连接信息，然后生成报告。"],
  "Local LAN only":["Tylko lokalna sieć LAN","Solo LAN local","Réseau local uniquement","Nur lokales LAN","仅限本地 LAN"],
  "No Bambu Lab account or cloud connection is used. MQTT TLS stays inside your local network.":["Konto Bambu Lab ani połączenie z chmurą nie są używane. MQTT TLS pozostaje w sieci lokalnej.","No se usa ninguna cuenta Bambu Lab ni conexión en la nube. MQTT TLS permanece en la red local.","Aucun compte Bambu Lab ni connexion cloud n’est utilisé. MQTT TLS reste sur le réseau local.","Kein Bambu-Lab-Konto und keine Cloud-Verbindung. MQTT TLS bleibt im lokalen Netzwerk.","不使用 Bambu Lab 帐户或云连接。MQTT TLS 始终位于本地网络。"],
  "PrintDeck settings":["Ustawienia PrintDeck","Ajustes de PrintDeck","Paramètres PrintDeck","PrintDeck-Einstellungen","PrintDeck 设置"],
  "Printers · —":["Drukarki · —","Impresoras · —","Imprimantes · —","Drucker · —","打印机 · —"],
  "Wi-Fi · checking":["Wi‑Fi · sprawdzanie","Wi‑Fi · comprobando","Wi‑Fi · vérification","WLAN · Prüfung","Wi-Fi · 检查中"],
  "Reads Moonraker and printer.cfg without changing the printer.":["Odczytuje Moonraker i printer.cfg bez wprowadzania zmian w drukarce.","Lee Moonraker y printer.cfg sin cambiar la impresora.","Lit Moonraker et printer.cfg sans modifier l’imprimante.","Liest Moonraker und printer.cfg, ohne den Drucker zu verändern.","读取 Moonraker 和 printer.cfg，不会更改打印机。"],
  "Generate a compatibility report and send it to support@printdeck.xyz to help us support more Bambu Lab printers. It contains available data fields and safe numeric ranges, but no connection details or print names. Nothing is uploaded automatically.":["Wygeneruj raport zgodności i wyślij go na support@printdeck.xyz, aby pomóc nam obsługiwać więcej drukarek Bambu Lab. Zawiera dostępne pola danych i bezpieczne zakresy liczbowe, ale nigdy dane połączenia ani nazwy wydruków. Nic nie jest wysyłane automatycznie.","Genera un informe de compatibilidad y envíalo a support@printdeck.xyz para ayudarnos a admitir más impresoras Bambu Lab. Incluye los campos de datos disponibles y rangos numéricos seguros, pero nunca datos de conexión ni nombres de impresiones. Nada se sube automáticamente.","Générez un rapport de compatibilité et envoyez-le à support@printdeck.xyz pour nous aider à prendre en charge davantage d’imprimantes Bambu Lab. Il contient les champs de données disponibles et des plages numériques sûres, mais jamais les informations de connexion ni les noms d’impression. Rien n’est envoyé automatiquement.","Erstelle einen Kompatibilitätsbericht und sende ihn an support@printdeck.xyz, damit wir mehr Bambu-Lab-Drucker unterstützen können. Er enthält verfügbare Datenfelder und sichere Zahlenbereiche, aber niemals Verbindungsdaten oder Drucknamen. Nichts wird automatisch hochgeladen.","生成兼容性报告并将其发送至 support@printdeck.xyz，帮助我们支持更多 Bambu Lab 打印机。报告包含可用数据字段和安全数值范围，但绝不会包含连接信息或打印任务名称。任何内容都不会自动上传。"],
  "e.g. Creality":["np. Creality","p. ej. Creality","p. ex. Creality","z. B. Creality","例如 Creality"],
  "e.g. K2 Plus":["np. K2 Plus","p. ej. K2 Plus","p. ex. K2 Plus","z. B. K2 Plus","例如 K2 Plus"]
  ,"1 minute":["1 minuta","1 minuto","1 minute","1 Minute","1 分钟"]
  ,"2 minutes":["2 minuty","2 minutos","2 minutes","2 Minuten","2 分钟"]
  ,"3 minutes":["3 minuty","3 minutos","3 minutes","3 Minuten","3 分钟"]
  ,"5 minutes":["5 minut","5 minutos","5 minutes","5 Minuten","5 分钟"]
  ,"10 minutes":["10 minut","10 minutos","10 minutes","10 Minuten","10 分钟"]
  ,"10 seconds":["10 sekund","10 segundos","10 secondes","10 Sekunden","10 秒"]
  ,"20 seconds":["20 sekund","20 segundos","20 secondes","20 Sekunden","20 秒"]
  ,"30 seconds":["30 sekund","30 segundos","30 secondes","30 Sekunden","30 秒"]
  ,"45 seconds":["45 sekund","45 segundos","45 secondes","45 Sekunden","45 秒"]
  ,"90 seconds":["90 sekund","90 segundos","90 secondes","90 Sekunden","90 秒"]
  ,"Choose a Wi-Fi network":["Wybierz sieć Wi‑Fi","Elige una red Wi‑Fi","Choisissez un réseau Wi‑Fi","WLAN auswählen","选择 Wi-Fi 网络"]
  ,"Other network / Hidden":["Inna sieć / Ukryta","Otra red / Oculta","Autre réseau / Masqué","Anderes Netzwerk / Verborgen","其他网络 / 隐藏网络"]
  ,"One network found.":["Znaleziono jedną sieć.","Se encontró una red.","Un réseau trouvé.","Ein Netzwerk gefunden.","找到一个网络。"]
  ,"No visible networks found. Choose Other network / Hidden.":["Nie znaleziono widocznych sieci. Wybierz Inna sieć / Ukryta.","No se encontraron redes visibles. Elige Otra red / Oculta.","Aucun réseau visible. Choisissez Autre réseau / Masqué.","Keine sichtbaren Netzwerke gefunden. Anderes Netzwerk / Verborgen wählen.","未找到可见网络。请选择其他网络 / 隐藏网络。"]
  ,"Choose a network or enter its name.":["Wybierz sieć lub wpisz jej nazwę.","Elige una red o introduce su nombre.","Choisissez un réseau ou saisissez son nom.","Netzwerk wählen oder Namen eingeben.","选择网络或输入其名称。"]
  ,"Check & save Wi-Fi":["Sprawdź i zapisz Wi‑Fi","Comprobar y guardar Wi‑Fi","Vérifier et enregistrer le Wi‑Fi","WLAN prüfen und speichern","检查并保存 Wi-Fi"]
  ,"Checking your Wi-Fi connection…":["Sprawdzanie połączenia Wi‑Fi…","Comprobando la conexión Wi‑Fi…","Vérification de la connexion Wi‑Fi…","WLAN-Verbindung wird geprüft…","正在检查 Wi-Fi 连接…"]
  ,"Wi-Fi verified. PrintDeck is restarting…":["Połączenie Wi‑Fi sprawdzone. PrintDeck uruchamia się ponownie…","Wi‑Fi verificado. PrintDeck se está reiniciando…","Wi‑Fi vérifié. PrintDeck redémarre…","WLAN geprüft. PrintDeck startet neu…","已验证 Wi-Fi。PrintDeck 正在重启…"]
  ,"Saving your Wi-Fi connection…":["Zapisywanie połączenia Wi‑Fi…","Guardando la conexión Wi‑Fi…","Enregistrement de la connexion Wi‑Fi…","WLAN-Verbindung wird gespeichert…","正在保存 Wi-Fi 连接…"]
  ,"PrintDeck could not join this Wi-Fi network. Check the password and try again.":["PrintDeck nie mógł połączyć się z tą siecią Wi‑Fi. Sprawdź hasło i spróbuj ponownie.","PrintDeck no pudo conectarse a esta red Wi‑Fi. Comprueba la contraseña e inténtalo de nuevo.","PrintDeck n’a pas pu rejoindre ce réseau Wi‑Fi. Vérifiez le mot de passe et réessayez.","PrintDeck konnte diesem WLAN nicht beitreten. Prüfe das Passwort und versuche es erneut.","PrintDeck 无法加入此 Wi-Fi 网络。请检查密码后重试。"]
  ,"PrintDeck could not verify this Wi-Fi network. Stay connected to the PrintDeck setup network and try again.":["PrintDeck nie mógł sprawdzić tej sieci Wi‑Fi. Pozostań połączony z siecią konfiguracji PrintDeck i spróbuj ponownie.","PrintDeck no pudo verificar esta red Wi‑Fi. Mantén la conexión con la red de configuración de PrintDeck e inténtalo de nuevo.","PrintDeck n’a pas pu vérifier ce réseau Wi‑Fi. Restez connecté au réseau de configuration PrintDeck et réessayez.","PrintDeck konnte dieses WLAN nicht prüfen. Bleibe mit dem PrintDeck-Einrichtungsnetzwerk verbunden und versuche es erneut.","PrintDeck 无法验证此 Wi-Fi 网络。请保持连接 PrintDeck 设置网络后重试。"]
  ,"PrintDeck could not verify this Wi-Fi network. The previous Wi-Fi settings were kept.":["PrintDeck nie mógł sprawdzić tej sieci Wi‑Fi. Zachowano poprzednie ustawienia Wi‑Fi.","PrintDeck no pudo verificar esta red Wi‑Fi. Se conservaron los ajustes de Wi‑Fi anteriores.","PrintDeck n’a pas pu vérifier ce réseau Wi‑Fi. Les réglages Wi‑Fi précédents ont été conservés.","PrintDeck konnte dieses WLAN nicht prüfen. Die bisherigen WLAN-Einstellungen wurden beibehalten.","PrintDeck 无法验证此 Wi-Fi 网络。已保留之前的 Wi-Fi 设置。"]
  ,"The Wi-Fi check was interrupted. Stay connected to the PrintDeck setup network and try again.":["Sprawdzanie Wi‑Fi zostało przerwane. Pozostań połączony z siecią konfiguracji PrintDeck i spróbuj ponownie.","La comprobación de Wi‑Fi se interrumpió. Mantén la conexión con la red de configuración de PrintDeck e inténtalo de nuevo.","La vérification Wi‑Fi a été interrompue. Restez connecté au réseau de configuration PrintDeck et réessayez.","Die WLAN-Prüfung wurde unterbrochen. Bleibe mit dem PrintDeck-Einrichtungsnetzwerk verbunden und versuche es erneut.","Wi-Fi 检查已中断。请保持连接 PrintDeck 设置网络后重试。"]
  ,"The Wi-Fi check changed the connection. Reopen Web Config after PrintDeck reconnects. Incorrect Wi-Fi details are not saved.":["Sprawdzenie Wi‑Fi zmieniło połączenie. Otwórz ponownie Web Config, gdy PrintDeck się połączy. Nieprawidłowe dane Wi‑Fi nie są zapisywane.","La comprobación de Wi‑Fi cambió la conexión. Vuelve a abrir Web Config cuando PrintDeck se conecte. Los datos de Wi‑Fi incorrectos no se guardan.","La vérification Wi‑Fi a modifié la connexion. Rouvrez Web Config une fois PrintDeck reconnecté. Les informations Wi‑Fi incorrectes ne sont pas enregistrées.","Die WLAN-Prüfung hat die Verbindung geändert. Öffne Web Config erneut, sobald PrintDeck wieder verbunden ist. Falsche WLAN-Daten werden nicht gespeichert.","Wi-Fi 检查已更改连接。PrintDeck 重新连接后，请重新打开 Web Config。错误的 Wi-Fi 信息不会被保存。"]
  ,"Wi-Fi saved. PrintDeck is restarting to connect…":["Wi‑Fi zapisane. PrintDeck uruchamia się ponownie, aby się połączyć…","Wi‑Fi guardado. PrintDeck se reinicia para conectar…","Wi‑Fi enregistré. PrintDeck redémarre pour se connecter…","WLAN gespeichert. PrintDeck startet für die Verbindung neu…","Wi-Fi 已保存。PrintDeck 正在重启以连接…"]
  ,"Wi-Fi details saved":["Dane Wi‑Fi zapisane","Datos de Wi‑Fi guardados","Informations Wi‑Fi enregistrées","WLAN-Daten gespeichert","Wi-Fi 信息已保存"]
  ,"PrintDeck is restarting and joining":["PrintDeck uruchamia się ponownie i łączy z siecią","PrintDeck se está reiniciando y conectando a","PrintDeck redémarre et se connecte à","PrintDeck startet neu und verbindet sich mit","PrintDeck 正在重启并连接到"]
  ,"Reconnect this device to the same Wi-Fi network if it does not reconnect automatically.":["Jeśli to urządzenie nie połączy się automatycznie, połącz je ponownie z tą samą siecią Wi‑Fi.","Si este dispositivo no se vuelve a conectar automáticamente, conéctalo de nuevo a la misma red Wi‑Fi.","Si cet appareil ne se reconnecte pas automatiquement, reconnectez-le au même réseau Wi‑Fi.","Falls sich dieses Gerät nicht automatisch verbindet, verbinde es erneut mit demselben WLAN.","如果此设备未自动重新连接，请将其重新连接到同一 Wi-Fi 网络。"]
  ,"On PrintDeck, open Web Config and enter the address shown on its screen.":["Na PrintDeck otwórz Web Config i wpisz w przeglądarce adres pokazany na ekranie.","En PrintDeck, abre Web Config e introduce en el navegador la dirección que aparece en la pantalla.","Sur PrintDeck, ouvrez Web Config et saisissez dans le navigateur l’adresse affichée à l’écran.","Öffne Web Config auf PrintDeck und gib die dort angezeigte Adresse im Browser ein.","在 PrintDeck 上打开 Web Config，然后在浏览器中输入屏幕上显示的地址。"]
  ,"The setup address 192.168.4.1 will no longer be available.":["Adres konfiguracji 192.168.4.1 nie będzie już dostępny.","La dirección de configuración 192.168.4.1 dejará de estar disponible.","L’adresse de configuration 192.168.4.1 ne sera plus disponible.","Die Einrichtungsadresse 192.168.4.1 ist danach nicht mehr erreichbar.","设置地址 192.168.4.1 将不再可用。"]
  ,"Wi-Fi · connected":["Wi‑Fi · połączono","Wi‑Fi · conectado","Wi‑Fi · connecté","WLAN · verbunden","Wi-Fi · 已连接"]
  ,"Wi-Fi · offline":["Wi‑Fi · offline","Wi‑Fi · sin conexión","Wi‑Fi · hors ligne","WLAN · offline","Wi-Fi · 离线"]
  ,"Wi-Fi · setup mode":["Wi‑Fi · tryb konfiguracji","Wi‑Fi · modo de configuración","Wi‑Fi · mode configuration","WLAN · Einrichtungsmodus","Wi-Fi · 设置模式"]
  ,"Wi-Fi status: checking":["Sprawdzanie stanu Wi‑Fi","Comprobando el estado de Wi‑Fi","Vérification de l’état du Wi‑Fi","WLAN-Status wird geprüft","正在检查 Wi-Fi 状态"]
  ,"Wi-Fi connected":["Wi‑Fi połączone","Wi‑Fi conectado","Wi‑Fi connecté","WLAN verbunden","Wi-Fi 已连接"]
  ,"Wi-Fi offline":["Wi‑Fi offline","Wi‑Fi sin conexión","Wi‑Fi hors ligne","WLAN offline","Wi-Fi 离线"]
  ,"Wi-Fi setup mode":["Tryb konfiguracji Wi‑Fi","Modo de configuración Wi‑Fi","Mode de configuration Wi‑Fi","WLAN-Einrichtungsmodus","Wi-Fi 设置模式"]
  ,"Sound on":["Dźwięk włączony","Sonido activado","Son activé","Ton eingeschaltet","声音已开启"]
  ,"Sound muted":["Dźwięk wyciszony","Sonido silenciado","Son coupé","Ton stummgeschaltet","声音已静音"]
  ,"Battery status":["Stan baterii","Estado de la batería","État de la batterie","Batteriestatus","电池状态"]
  ,"Battery: {percent}%":["Bateria: {percent}%","Batería: {percent}%","Batterie : {percent}%","Batterie: {percent}%","电池：{percent}%"]
  ,"Battery charging: {percent}%":["Ładowanie baterii: {percent}%","Batería cargando: {percent}%","Batterie en charge : {percent}%","Batterie wird geladen: {percent}%","电池充电中：{percent}%"]
  ,"External power · Battery: {percent}%":["Zasilanie zewnętrzne · Bateria: {percent}%","Alimentación externa · Batería: {percent}%","Alimentation externe · Batterie : {percent}%","Externe Stromversorgung · Batterie: {percent}%","外部供电 · 电池：{percent}%"]
  ,"External power · No battery":["Zasilanie zewnętrzne · Brak baterii","Alimentación externa · Sin batería","Alimentation externe · Sans batterie","Externe Stromversorgung · Kein Akku","外部供电 · 未连接电池"]
  ,"Setup mode":["Tryb konfiguracji","Modo de configuración","Mode configuration","Einrichtungsmodus","设置模式"]
  ,"Printers · ":["Drukarki · ","Impresoras · ","Imprimantes · ","Drucker · ","打印机 · "]
  ,"Saving your changes…":["Zapisywanie zmian…","Guardando cambios…","Enregistrement des modifications…","Änderungen werden gespeichert…","正在保存更改…"]
  ,"Saved. PrintDeck is restarting to apply this change…":["Zapisano. PrintDeck uruchamia się ponownie, aby zastosować zmianę…","Guardado. PrintDeck se reinicia para aplicar el cambio…","Enregistré. PrintDeck redémarre pour appliquer la modification…","Gespeichert. PrintDeck startet neu, um die Änderung anzuwenden…","已保存。PrintDeck 正在重启以应用更改…"]
  ,"Muted":["Wyciszono","Silenciado","Muet","Stumm","已静音"]
  ,"Restore sound":["Przywróć dźwięk","Restaurar sonido","Rétablir le son","Ton wiederherstellen","恢复声音"]
  ,"Signal":["Sygnał","Señal","Signal","Signal","信号"]
  ,"Banana":["Banana","Banana","Banana","Banana","Banana"]
  ,"Solstice":["Przesilenie","Solsticio","Solstice","Sonnenwende","至日"]
  ,"Glacier":["Lodowiec","Glaciar","Glacier","Gletscher","冰川"]
  ,"Aurora":["Zorza","Aurora","Aurore","Aurora","极光"]
  ,"Grove":["Gaj","Arboleda","Bosquet","Hain","林间"]
  ,"Graphite":["Grafit","Grafito","Graphite","Graphit","石墨"]
  ,"Garnet":["Granat","Granate","Grenat","Granat","石榴红"]
  ,"Midnight Halo":["Midnight Halo","Midnight Halo","Midnight Halo","Midnight Halo","Midnight Halo"]
  ,"Red Dragon":["Czerwony Smok","Dragón Rojo","Dragon Rouge","Roter Drache","赤龙"]
  ,"Retro Terminal":["Terminal retro","Terminal retro","Terminal rétro","Retro-Terminal","复古终端"]
  ,"True AMOLED black with electric-blue halos and layered midnight surfaces.":["Prawdziwa czerń AMOLED, elektrycznoniebieskie poświaty i warstwowe nocne powierzchnie.","Negro AMOLED real, halos azul eléctrico y superficies nocturnas en capas.","Noir AMOLED véritable, halos bleu électrique et surfaces nocturnes superposées.","Echtes AMOLED-Schwarz, elektrisch blaue Lichtkränze und geschichtete Nachtflächen.","纯正 AMOLED 黑色、电光蓝光晕与层叠午夜界面。"]
  ,"Near-black surfaces, razor-red framing and a deep crimson glow.":["Niemal czarne powierzchnie, ostre czerwone ramy i głęboka karmazynowa poświata.","Superficies casi negras, marcos rojo intenso y un profundo resplandor carmesí.","Surfaces presque noires, encadrements rouge vif et profonde lueur cramoisie.","Nahezu schwarze Flächen, scharfrote Rahmen und ein tiefes karminrotes Leuchten.","近黑色表面、锐利红色边框与深邃绯红光晕。"]
  ,"Amber CRT readouts, phosphor green signals and strict terminal geometry.":["Bursztynowe odczyty CRT, fosforowe zielone sygnały i surowa geometria terminala.","Lecturas CRT ámbar, señales verde fósforo y geometría estricta de terminal.","Lectures CRT ambrées, signaux vert phosphore et géométrie stricte de terminal.","Bernsteinfarbene CRT-Anzeigen, phosphorgrüne Signale und strenge Terminal-Geometrie.","琥珀色 CRT 读数、磷光绿色信号与严格的终端几何。"]
  ,"Build a palette around your own colors.":["Zbuduj paletę z własnych kolorów.","Crea una paleta con tus propios colores.","Créez une palette autour de vos couleurs.","Erstelle eine Palette mit deinen eigenen Farben.","使用你自己的颜色创建调色板。"]
  ,"Pure black with electric teal and signal-green accents.":["Czysta czerń z elektrycznym turkusem i sygnałową zielenią.","Negro puro con turquesa eléctrico y acentos verde señal.","Noir pur avec turquoise électrique et accents vert signal.","Reines Schwarz mit elektrischem Türkis und signalgrünen Akzenten.","纯黑基底，搭配电光青绿与信号绿色点缀。"]
  ,"Deep charcoal with banana yellow and crisp cyan highlights.":["Głęboki grafit, bananowa żółć i wyraziste cyjanowe akcenty.","Carbón oscuro, amarillo plátano y nítidos acentos cian.","Anthracite profond, jaune banane et accents cyan nets.","Tiefes Anthrazit, Bananengelb und klare Cyan-Akzente.","深炭黑、香蕉黄与清晰的青色点缀。"]
  ,"Warm coral and amber over deep aubergine.":["Ciepły koral i bursztyn na głębokim bakłażanie.","Coral y ámbar cálidos sobre berenjena profunda.","Corail et ambre chauds sur une aubergine profonde.","Warmes Korall und Bernstein auf tiefem Aubergine.","暖珊瑚与琥珀叠加在深茄紫之上。"]
  ,"A bright, airy palette with cool cyan details.":["Jasna, lekka paleta z chłodnymi cyjanowymi detalami.","Una paleta clara y ligera con detalles cian fríos.","Une palette claire et aérienne aux détails cyan froids.","Eine helle, luftige Palette mit kühlen Cyan-Details.","明亮通透的配色，辅以冷青色细节。"]
  ,"Magenta and cyan balanced over rich violet.":["Magenta i cyjan zrównoważone na głębokim fiolecie.","Magenta y cian equilibrados sobre violeta intenso.","Magenta et cyan équilibrés sur un violet profond.","Magenta und Cyan, ausbalanciert auf sattem Violett.","洋红与青色在浓郁紫色上取得平衡。"]
  ,"Leaf green and soft moss over deep woodland olive.":["Liściasta zieleń i miękki mech na tle głębokiej leśnej oliwki.","Verde hoja y musgo suave sobre un profundo oliva de bosque.","Vert feuillage et mousse douce sur un olive boisé profond.","Blattgrün und sanftes Moos auf tiefem Waldoliv.","叶绿色与柔和苔绿色，衬以深林橄榄色。"]
  ,"A restrained monochrome palette with crisp contrast.":["Powściągliwa monochromatyczna paleta o czystym kontraście.","Una paleta monocroma sobria con contraste nítido.","Une palette monochrome sobre au contraste net.","Eine zurückhaltende monochrome Palette mit klarem Kontrast.","克制的单色配色与利落对比。"]
  ,"Dusty rose and soft blush over deep wine.":["Przygaszony róż i jasny pudrowy akcent na głębokim winnym tle.","Rosa empolvado y rubor suave sobre un vino profundo.","Rose poudré et rose tendre sur un lie-de-vin profond.","Altrosa und zartes Rosé auf tiefem Weinrot.","灰粉色与柔和浅粉，衬以深酒红色。"]
  ,"This printer is offline and cannot be made active.":["Ta drukarka jest offline i nie może zostać ustawiona jako aktywna.","Esta impresora está sin conexión y no puede activarse.","Cette imprimante est hors ligne et ne peut pas être activée.","Dieser Drucker ist offline und kann nicht aktiviert werden.","此打印机离线，无法设为当前打印机。"]
  ,"Offline printers cannot be selected":["Nie można wybrać drukarki offline","No se pueden seleccionar impresoras sin conexión","Les imprimantes hors ligne ne peuvent pas être sélectionnées","Offline-Drucker können nicht ausgewählt werden","无法选择离线打印机"]
  ,"Add Bambu Lab printer":["Dodaj drukarkę Bambu Lab","Añadir impresora Bambu Lab","Ajouter une imprimante Bambu Lab","Bambu-Lab-Drucker hinzufügen","添加 Bambu Lab 打印机"]
  ,"Add Moonraker printer":["Dodaj drukarkę Moonraker","Añadir impresora Moonraker","Ajouter une imprimante Moonraker","Moonraker-Drucker hinzufügen","添加 Moonraker 打印机"]
  ,"Local-only MQTT connection; no cloud account is used.":["Lokalne połączenie MQTT; konto w chmurze nie jest używane.","Conexión MQTT solo local; no se usa cuenta en la nube.","Connexion MQTT locale uniquement ; aucun compte cloud.","Rein lokale MQTT-Verbindung; kein Cloud-Konto.","仅本地 MQTT 连接；不使用云帐户。"]
  ,"Direct connection to Klipper through the Moonraker API.":["Bezpośrednie połączenie z Klipperem przez API Moonraker.","Conexión directa a Klipper mediante la API Moonraker.","Connexion directe à Klipper via l’API Moonraker.","Direkte Klipper-Verbindung über die Moonraker-API.","通过 Moonraker API 直接连接 Klipper。"]
  ,"Leave blank to keep the saved key":["Pozostaw puste, aby zachować zapisany klucz","Déjalo vacío para conservar la clave guardada","Laissez vide pour conserver la clé enregistrée","Leer lassen, um den gespeicherten Schlüssel zu behalten","留空以保留已保存的密钥"]
  ,"Leave blank to keep the saved code":["Pozostaw puste, aby zachować zapisany kod","Déjalo vacío para conservar el código guardado","Laissez vide pour conserver le code enregistré","Leer lassen, um den gespeicherten Code zu behalten","留空以保留已保存的代码"]
  ,"Optional on a trusted LAN":["Opcjonalny w zaufanej sieci LAN","Opcional en una LAN de confianza","Facultatif sur un réseau local fiable","Optional in einem vertrauenswürdigen LAN","在可信 LAN 中可选"]
  ,"Enter the Moonraker address first.":["Najpierw wpisz adres Moonraker.","Introduce primero la dirección de Moonraker.","Saisissez d’abord l’adresse Moonraker.","Zuerst die Moonraker-Adresse eingeben.","请先输入 Moonraker 地址。"]
  ,"Reading Moonraker and printer identity…":["Odczytywanie Moonraker i danych drukarki…","Leyendo Moonraker y la identidad de la impresora…","Lecture de Moonraker et de l’identité de l’imprimante…","Moonraker und Druckeridentität werden gelesen…","正在读取 Moonraker 和打印机身份…"]
  ,"Detect the printer or enter its manufacturer.":["Wykryj drukarkę lub wpisz jej producenta.","Detecta la impresora o introduce su fabricante.","Détectez l’imprimante ou saisissez son fabricant.","Drucker erkennen oder Hersteller eingeben.","检测打印机或输入制造商。"]
  ,"Saving printer…":["Zapisywanie drukarki…","Guardando impresora…","Enregistrement de l’imprimante…","Drucker wird gespeichert…","正在保存打印机…"]
  ,"Search complete":["Wyszukiwanie zakończone","Búsqueda completada","Recherche terminée","Suche abgeschlossen","搜索完成"]
  ,"Search finished":["Wyszukiwanie zakończone","Búsqueda finalizada","Recherche terminée","Suche beendet","搜索结束"]
  ,"Bambu Lab printer":["Drukarka Bambu Lab","Impresora Bambu Lab","Imprimante Bambu Lab","Bambu-Lab-Drucker","Bambu Lab 打印机"]
  ,"Moonraker printer":["Drukarka Moonraker","Impresora Moonraker","Imprimante Moonraker","Moonraker-Drucker","Moonraker 打印机"]
  ,"ADD +":["DODAJ +","AÑADIR +","AJOUTER +","HINZUFÜGEN +","添加 +"]
  ,"My Printer":["Moja drukarka","Mi impresora","Mon imprimante","Mein Drucker","我的打印机"]
  ,"Edit":["Edytuj","Editar","Modifier","Bearbeiten","编辑"]
  ,"printer":["drukarka","impresora","imprimante","Drucker","打印机"]
  ,"Hide Wi-Fi password":["Ukryj hasło Wi‑Fi","Ocultar contraseña Wi‑Fi","Masquer le mot de passe Wi‑Fi","WLAN-Passwort ausblenden","隐藏 Wi-Fi 密码"]
  ,"Hide password":["Ukryj hasło","Ocultar contraseña","Masquer le mot de passe","Passwort ausblenden","隐藏密码"]
  ,"networks found.":["znalezionych sieci.","redes encontradas.","réseaux trouvés.","Netzwerke gefunden.","个网络。"]
  ,"Printing":["Drukowanie","Imprimiendo","Impression","Druckt","打印中"]
  ,"Print complete":["Wydruk zakończony","Impresión completada","Impression terminée","Druck abgeschlossen","打印完成"]
  ,"Needs attention":["Wymaga uwagi","Requiere atención","Nécessite votre attention","Aufmerksamkeit erforderlich","需要处理"]
  ,"Ready":["Gotowa","Lista","Prête","Bereit","就绪"]
  ,"Preparing":["Przygotowanie","Preparando","Préparation","Vorbereitung","准备中"]
  ,"Paused":["Wstrzymano","Pausado","En pause","Pausiert","已暂停"]
  ,"Filament change":["Zmiana filamentu","Cambio de filamento","Changement de filament","Filamentwechsel","更换耗材"]
  ,"Printer offline":["Drukarka offline","Impresora sin conexión","Imprimante hors ligne","Drucker offline","打印机离线"]
  ,"Status unavailable":["Stan niedostępny","Estado no disponible","État indisponible","Status nicht verfügbar","状态不可用"]
  ,"LEFT":["POZOSTAŁO","RESTANTE","RESTANT","RESTZEIT","剩余"]
  ,"Print preview":["Podgląd wydruku","Vista previa de impresión","Aperçu de l’impression","Druckvorschau","打印预览"]
  ,"TOTAL":["ŁĄCZNIE","TOTAL","TOTAL","GESAMT","总计"]
  ,"Layer":["Warstwa","Capa","Couche","Schicht","层"]
  ,"Loading official PrintDeck releases…":["Wczytywanie oficjalnych wydań PrintDeck…","Cargando versiones oficiales de PrintDeck…","Chargement des versions officielles de PrintDeck…","Offizielle PrintDeck-Releases werden geladen…","正在加载官方 PrintDeck 版本…"]
  ,"The official release list is unavailable.":["Lista oficjalnych wydań jest niedostępna.","La lista oficial de versiones no está disponible.","La liste officielle des versions est indisponible.","Die offizielle Release-Liste ist nicht verfügbar.","官方版本列表不可用。"]
  ,"No installable PrintDeck releases were found.":["Nie znaleziono wydań PrintDeck możliwych do zainstalowania.","No se encontraron versiones de PrintDeck instalables.","Aucune version installable de PrintDeck n’a été trouvée.","Keine installierbaren PrintDeck-Releases gefunden.","未找到可安装的 PrintDeck 版本。"]
  ,"Official releases unavailable":["Oficjalne wydania niedostępne","Versiones oficiales no disponibles","Versions officielles indisponibles","Offizielle Releases nicht verfügbar","官方版本不可用"]
  ,"Starting the selected firmware download…":["Rozpoczynanie pobierania wybranego firmware…","Iniciando la descarga del firmware seleccionado…","Démarrage du téléchargement du micrologiciel sélectionné…","Download der ausgewählten Firmware wird gestartet…","正在开始下载所选固件…"]
  ,"Starting firmware download…":["Rozpoczynanie pobierania firmware…","Iniciando la descarga del firmware…","Démarrage du téléchargement du micrologiciel…","Firmware-Download wird gestartet…","正在开始下载固件…"]
  ,"Download started. Keep PrintDeck powered.":["Pobieranie rozpoczęte. Pozostaw PrintDeck podłączony do zasilania.","Descarga iniciada. Mantén PrintDeck encendido.","Téléchargement démarré. Gardez PrintDeck alimenté.","Download gestartet. PrintDeck mit Strom versorgen.","下载已开始。请保持 PrintDeck 供电。"]
  ,"Enter a direct HTTPS firmware URL.":["Wpisz bezpośredni adres HTTPS firmware.","Introduce una URL HTTPS directa del firmware.","Saisissez une URL HTTPS directe du micrologiciel.","Direkte HTTPS-URL der Firmware eingeben.","请输入固件的直接 HTTPS 网址。"]
  ,"Choose a PrintDeck .bin file first.":["Najpierw wybierz plik PrintDeck .bin.","Elige primero un archivo .bin de PrintDeck.","Choisissez d’abord un fichier .bin PrintDeck.","Zuerst eine PrintDeck-.bin-Datei wählen.","请先选择 PrintDeck .bin 文件。"]
  ,"This full firmware file is incomplete.":["Ten pełny plik firmware jest niekompletny.","Este archivo de firmware completo está incompleto.","Ce fichier complet de micrologiciel est incomplet.","Diese vollständige Firmware-Datei ist unvollständig.","此完整固件文件不完整。"]
  ,"Preparing the OTA image from the full release file…":["Przygotowywanie obrazu OTA z pełnego pliku wydania…","Preparando la imagen OTA desde el archivo completo…","Préparation de l’image OTA depuis le fichier complet…","OTA-Abbild aus der vollständigen Release-Datei wird vorbereitet…","正在从完整版本文件准备 OTA 镜像…"]
  ,"Uploading firmware…":["Wgrywanie firmware…","Subiendo firmware…","Téléversement du micrologiciel…","Firmware wird hochgeladen…","正在上传固件…"]
  ,"Firmware installed. PrintDeck is restarting…":["Firmware zainstalowane. PrintDeck uruchamia się ponownie…","Firmware instalado. PrintDeck se reinicia…","Micrologiciel installé. PrintDeck redémarre…","Firmware installiert. PrintDeck startet neu…","固件已安装。PrintDeck 正在重启…"]
  ,"The firmware could not be installed.":["Nie udało się zainstalować firmware.","No se pudo instalar el firmware.","Le micrologiciel n’a pas pu être installé.","Die Firmware konnte nicht installiert werden.","无法安装固件。"]
  ,"The upload was interrupted. The current firmware was kept.":["Wgrywanie przerwano. Zachowano bieżące firmware.","La carga se interrumpió. Se conservó el firmware actual.","Le téléversement a été interrompu. Le micrologiciel actuel a été conservé.","Upload unterbrochen. Die aktuelle Firmware wurde beibehalten.","上传已中断。当前固件已保留。"]
  ,"Install this PrintDeck update and restart the device?":["Zainstalować tę aktualizację PrintDeck i uruchomić urządzenie ponownie?","¿Instalar esta actualización de PrintDeck y reiniciar el dispositivo?","Installer cette mise à jour PrintDeck et redémarrer l’appareil ?","Dieses PrintDeck-Update installieren und das Gerät neu starten?","安装此 PrintDeck 更新并重启设备？"]
  ,"Download and install firmware from this URL?":["Pobrać i zainstalować firmware z tego adresu?","¿Descargar e instalar el firmware desde esta URL?","Télécharger et installer le micrologiciel depuis cette URL ?","Firmware von dieser URL herunterladen und installieren?","从此网址下载并安装固件？"]
  ,"PrintDeck — Your 3D Printing Display":["PrintDeck — Twój ekran druku 3D","PrintDeck — Tu pantalla de impresión 3D","PrintDeck — Votre écran d’impression 3D","PrintDeck — Dein 3D-Druck-Display","PrintDeck — 你的 3D 打印显示屏"]
  ,"Device settings sections":["Sekcje ustawień urządzenia","Secciones de ajustes del dispositivo","Sections des paramètres de l’appareil","Bereiche der Geräteeinstellungen","设备设置部分"]
  ,"Copy from printer settings":["Skopiuj z ustawień drukarki","Copiar de los ajustes de la impresora","Copier depuis les paramètres de l’imprimante","Aus den Druckereinstellungen kopieren","从打印机设置中复制"]
  ,"Join the same network used by your printers and the device you are using now.":["Połącz się z tą samą siecią, której używają drukarki i obecne urządzenie.","Conéctate a la misma red que usan tus impresoras y este dispositivo.","Rejoignez le même réseau que vos imprimantes et l’appareil actuel.","Mit demselben Netzwerk wie Drucker und aktuelles Gerät verbinden.","连接打印机和当前设备所使用的同一网络。"]
  ,"Help improve PrintDeck":["Pomóż ulepszać PrintDeck","Ayúdanos a mejorar PrintDeck","Aidez-nous à améliorer PrintDeck","Hilf uns, PrintDeck zu verbessern","帮助改进 PrintDeck"]
  ,"Atlantic":["Atlantyk","Atlántico","Atlantique","Atlantik","大西洋"]
  ,"Europe":["Europa","Europa","Europe","Europa","欧洲"]
  ,"Africa":["Afryka","África","Afrique","Afrika","非洲"]
  ,"North America":["Ameryka Północna","América del Norte","Amérique du Nord","Nordamerika","北美洲"]
  ,"Central and South America":["Ameryka Środkowa i Południowa","Centroamérica y Sudamérica","Amérique centrale et du Sud","Mittel- und Südamerika","中美洲和南美洲"]
  ,"Asia":["Azja","Asia","Asie","Asien","亚洲"]
  ,"Australia and Pacific":["Australia i Pacyfik","Australia y Pacífico","Australie et Pacifique","Australien und Pazifik","澳大利亚和太平洋地区"]
  ,"Ready to check for updates.":["Gotowe do sprawdzenia aktualizacji.","Listo para buscar actualizaciones.","Prêt à rechercher des mises à jour.","Bereit zur Suche nach Updates.","可以检查更新。"]
  ,"Scanning":["Skanowanie","Escaneando","Analyse de","Suche in","正在扫描"]
  ,"your Wi-Fi":["Twojej sieci Wi‑Fi","tu Wi‑Fi","votre Wi‑Fi","deinem WLAN","你的 Wi-Fi"]
  ,"Choose one sound style for every PrintDeck notification, then set its volume.":["Wybierz jeden styl dźwięków dla wszystkich powiadomień PrintDeck, a następnie ustaw jego głośność.","Elige un estilo de sonido para todas las notificaciones de PrintDeck y ajusta su volumen.","Choisissez un style sonore pour toutes les notifications PrintDeck, puis réglez son volume.","Wähle einen Klangstil für alle PrintDeck-Benachrichtigungen und stelle dann die Lautstärke ein.","为所有 PrintDeck 通知选择一种声音风格，然后设置音量。"]
  ,"Sound preset":["Preset dźwięków","Preajuste de sonido","Préréglage sonore","Klangprofil","声音预设"]
  ,"Modern":["Nowoczesny","Moderno","Moderne","Modern","现代"]
  ,"Layered interface effects with a polished, expressive sound.":["Warstwowe efekty interfejsu o dopracowanym, wyrazistym brzmieniu.","Efectos de interfaz en capas con un sonido pulido y expresivo.","Des effets d’interface superposés au son soigné et expressif.","Vielschichtige Oberflächeneffekte mit einem ausgefeilten, ausdrucksstarken Klang.","层次丰富、精致且富有表现力的界面音效。"]
  ,"Soft":["Łagodny","Suave","Doux","Sanft","柔和"]
  ,"Gentle tones for a quieter workspace.":["Delikatne dźwięki do spokojniejszego miejsca pracy.","Tonos suaves para un espacio de trabajo más tranquilo.","Des sons discrets pour un espace de travail plus calme.","Sanfte Töne für eine ruhigere Arbeitsumgebung.","适合安静工作环境的柔和提示音。"]
  ,"Retro":["Retro","Retro","Rétro","Retro","复古"]
  ,"Classic, simple digital beeps.":["Klasyczne, proste cyfrowe piknięcia.","Pitidos digitales clásicos y sencillos.","Des bips numériques classiques et simples.","Klassische, einfache digitale Pieptöne.","经典而简洁的数字蜂鸣音。"]
  ,"Arcade":["Arcade","Arcade","Arcade","Arcade","街机"]
  ,"Bright game-style tones with energetic rises and zaps.":["Jasne dźwięki w stylu gier z energicznymi podbiciami i efektami zap.","Tonos brillantes de estilo arcade con subidas enérgicas y descargas.","Des sons de jeu éclatants avec des montées énergiques et des décharges.","Helle Spielklänge mit energischen Anstiegen und Zaps.","明亮的游戏风格音效，带有充满活力的上升音和电击声。"]
  ,"Sci-Fi":["Sci-Fi","Ciencia ficción","Science-fiction","Sci-Fi","科幻"]
  ,"Futuristic lasers, force fields and mechanical cues.":["Futurystyczne lasery, pola siłowe i mechaniczne sygnały.","Láseres futuristas, campos de fuerza y señales mecánicas.","Lasers futuristes, champs de force et signaux mécaniques.","Futuristische Laser, Kraftfelder und mechanische Signale.","未来感十足的激光、力场和机械提示音。"]
  ,"Voice notifications":["Komunikaty głosowe","Avisos de voz","Notifications vocales","Sprachmeldungen","语音通知"]
  ,"Multilingual spoken messages for supported events, with clean tones for frequent interface cues.":["Wielojęzyczne komunikaty głosowe dla obsługiwanych zdarzeń oraz czyste dźwięki dla częstych sygnałów interfejsu.","Mensajes de voz multilingües para eventos compatibles y tonos limpios para las señales frecuentes de la interfaz.","Messages vocaux multilingues pour les événements pris en charge, avec des sons épurés pour les signaux fréquents de l’interface.","Mehrsprachige Sprachmeldungen für unterstützte Ereignisse und klare Töne für häufige Oberflächensignale.","为支持的事件提供多语言语音消息，常用界面提示则使用简洁提示音。"]
  ,"Test notification sounds":["Testowanie dźwięków powiadomień","Probar sonidos de notificación","Tester les sons de notification","Benachrichtigungstöne testen","测试通知声音"]
  ,"Preview each event with the selected preset and volume. Testing does not save your changes.":["Odsłuchaj każde zdarzenie z wybranym presetem i głośnością. Testowanie nie zapisuje zmian.","Escucha cada evento con el preajuste y el volumen seleccionados. Las pruebas no guardan los cambios.","Écoutez chaque événement avec le préréglage et le volume choisis. Le test n’enregistre pas vos modifications.","Höre jedes Ereignis mit dem gewählten Profil und der Lautstärke an. Beim Testen werden Änderungen nicht gespeichert.","使用所选预设和音量试听各个事件。测试不会保存更改。"]
  ,"Notification sounds":["Dźwięki powiadomień","Sonidos de notificación","Sons de notification","Benachrichtigungstöne","通知声音"]
  ,"Mute any event you do not want to hear. Test sound always plays a preview, even when that event is muted.":["Wycisz zdarzenia, których nie chcesz słyszeć. Przycisk „Odtwórz dźwięk” zawsze uruchamia odsłuch, nawet gdy dane zdarzenie jest wyciszone.","Silencia los eventos que no quieras oír. Probar sonido siempre reproduce una vista previa, incluso si el evento está silenciado.","Coupez les événements que vous ne souhaitez pas entendre. Tester le son lance toujours un aperçu, même si l’événement est muet.","Schalte Ereignisse stumm, die du nicht hören möchtest. Ton testen spielt immer eine Vorschau ab, auch wenn das Ereignis stummgeschaltet ist.","将不想听到的事件静音。即使事件已静音，测试声音仍会播放预览。"]
  ,"Mute":["Wycisz","Silenciar","Couper","Stumm","静音"]
  ,"Power on or restart":["Włączenie lub restart","Encendido o reinicio","Mise sous tension ou redémarrage","Einschalten oder Neustart","开机或重启"]
  ,"Screen navigation":["Nawigacja po ekranach","Navegación por pantallas","Navigation entre les écrans","Bildschirmnavigation","屏幕导航"]
  ,"Automatic screen rotation":["Automatyczny obrót ekranu","Rotación automática de pantalla","Rotation automatique de l’écran","Automatische Bildschirmdrehung","自动旋转屏幕"]
  ,"Print started":["Rozpoczęcie druku","Impresión iniciada","Impression démarrée","Druck gestartet","打印开始"]
  ,"Print paused":["Wstrzymanie druku","Impresión pausada","Impression en pause","Druck pausiert","打印暂停"]
  ,"Print finished":["Zakończenie druku","Impresión terminada","Impression terminée","Druck abgeschlossen","打印完成"]
  ,"Print error":["Błąd druku","Error de impresión","Erreur d’impression","Druckfehler","打印错误"]
  ,"New Bambu HMS warning":["Nowe ostrzeżenie Bambu HMS","Nueva advertencia HMS de Bambu","Nouvel avertissement HMS Bambu","Neue Bambu-HMS-Warnung","新的 Bambu HMS 警告"]
  ,"Filament feeding":["Podawanie filamentu","Carga de filamento","Chargement du filament","Filamentzufuhr","进料耗材"]
  ,"Shutdown countdown":["Odliczanie do wyłączenia","Cuenta atrás para apagar","Compte à rebours avant l’arrêt","Countdown zum Ausschalten","关机倒计时"]
  ,"Power off":["Wyłączenie urządzenia","Apagado","Arrêt de l’appareil","Ausschalten","关机"]
  ,"Test sound":["Odtwórz dźwięk","Probar sonido","Tester le son","Ton testen","测试声音"]
  ,"Turn up the sound volume and try again.":["Zwiększ głośność dźwięku i spróbuj ponownie.","Sube el volumen del sonido e inténtalo de nuevo.","Augmentez le volume sonore et réessayez.","Erhöhe die Lautstärke und versuche es erneut.","请调高音量后重试。"]
  ,"Playing sound…":["Odtwarzanie dźwięku…","Reproduciendo sonido…","Lecture du son…","Ton wird abgespielt…","正在播放声音…"]
  ,"Wait for the current sound to finish and try again.":["Poczekaj, aż bieżący dźwięk się zakończy, i spróbuj ponownie.","Espera a que termine el sonido actual y vuelve a intentarlo.","Attendez la fin du son en cours, puis réessayez.","Warte, bis der aktuelle Ton beendet ist, und versuche es erneut.","请等待当前声音播放完毕，然后重试。"]
  ,"The sound test request is too long.":["Żądanie testu dźwięku jest zbyt długie.","La solicitud de prueba de sonido es demasiado larga.","La demande de test sonore est trop longue.","Die Anfrage zum Tontest ist zu lang.","声音测试请求过长。"]
  ,"Choose a valid sound preset and event.":["Wybierz prawidłowy preset dźwięków i zdarzenie.","Elige un preajuste de sonido y un evento válidos.","Choisissez un préréglage sonore et un événement valides.","Wähle ein gültiges Klangprofil und Ereignis.","请选择有效的声音预设和事件。"]
  ,"Sound testing is unavailable.":["Testowanie dźwięków jest niedostępne.","La prueba de sonido no está disponible.","Le test sonore est indisponible.","Der Tontest ist nicht verfügbar.","声音测试不可用。"]
  ,"Print progress: 25%":["Postęp druku: 25%","Progreso de impresión: 25%","Progression de l’impression : 25 %","Druckfortschritt: 25 %","打印进度：25%"]
  ,"Print progress: 50%":["Postęp druku: 50%","Progreso de impresión: 50%","Progression de l’impression : 50 %","Druckfortschritt: 50 %","打印进度：50%"]
  ,"Print progress: 75%":["Postęp druku: 75%","Progreso de impresión: 75%","Progression de l’impression : 75 %","Druckfortschritt: 75 %","打印进度：75%"]
  ,"Choose what the screen does when you are not using PrintDeck. Every change is saved automatically.":["Wybierz, co ma robić ekran, gdy nie używasz PrintDeck. Każda zmiana zapisuje się automatycznie.","Elige qué hace la pantalla cuando no usas PrintDeck. Cada cambio se guarda automáticamente.","Choisissez le comportement de l’écran lorsque vous n’utilisez pas PrintDeck. Chaque modification est enregistrée automatiquement.","Lege fest, wie sich der Bildschirm verhält, wenn du PrintDeck nicht verwendest. Jede Änderung wird automatisch gespeichert.","选择不使用 PrintDeck 时屏幕的行为。每项更改都会自动保存。"]
  ,"Screen behavior":["Zachowanie ekranu","Comportamiento de la pantalla","Comportement de l’écran","Bildschirmverhalten","屏幕行为"]
  ,"Choose whether the screen dims, turns fully black, and follows these rules on USB power.":["Wybierz, czy ekran ma się przyciemniać, całkowicie wygaszać i stosować te zasady przy zasilaniu USB.","Elige si la pantalla se atenúa, se apaga por completo y aplica estas reglas con alimentación USB.","Choisissez si l’écran s’atténue, devient totalement noir et applique ces règles sur alimentation USB.","Lege fest, ob der Bildschirm gedimmt, vollständig ausgeschaltet und diese Regeln bei USB-Strom angewendet werden.","选择屏幕是否变暗、完全熄灭，以及连接 USB 电源时是否应用这些规则。"]
  ,"Dim the screen first":["Najpierw przyciemnij ekran","Atenuar primero la pantalla","Atténuer d’abord l’écran","Bildschirm zuerst dimmen","先调暗屏幕"]
  ,"Reduces brightness before the screen turns fully off.":["Zmniejsza jasność, zanim ekran całkowicie się wyłączy.","Reduce el brillo antes de que la pantalla se apague por completo.","Réduit la luminosité avant l’extinction complète de l’écran.","Verringert die Helligkeit, bevor der Bildschirm vollständig ausgeht.","在屏幕完全熄灭前先降低亮度。"]
  ,"Brightness while dimmed":["Jasność po przyciemnieniu","Brillo atenuado","Luminosité atténuée","Helligkeit beim Dimmen","调暗后的亮度"]
  ,"Automatic chooses a comfortable low level based on normal brightness.":["Tryb automatyczny dobiera wygodny niski poziom na podstawie zwykłej jasności.","Automático elige un nivel bajo cómodo según el brillo normal.","Le mode automatique choisit un niveau faible confortable selon la luminosité normale.","Automatisch wählt anhand der normalen Helligkeit eine angenehme niedrige Stufe.","自动模式会根据正常亮度选择舒适的低亮度。"]
  ,"Allow the screen to turn off":["Zezwól na całkowite wyłączenie ekranu","Permitir que la pantalla se apague","Autoriser l’extinction de l’écran","Ausschalten des Bildschirms erlauben","允许屏幕完全熄灭"]
  ,"Makes the display fully black after the selected time.":["Po wybranym czasie ekran staje się całkowicie czarny.","Deja la pantalla totalmente negra después del tiempo seleccionado.","Rend l’écran totalement noir après le délai choisi.","Schaltet den Bildschirm nach der gewählten Zeit vollständig schwarz.","在所选时间后使屏幕完全变黑。"]
  ,"Use these timers on USB power":["Używaj tych czasów przy zasilaniu USB","Usar estos temporizadores con alimentación USB","Utiliser ces délais sur alimentation USB","Diese Timer bei USB-Strom verwenden","连接 USB 电源时使用这些定时器"]
  ,"When off, the screen stays awake while PrintDeck is connected to USB.":["Gdy wyłączone, ekran pozostaje aktywny, kiedy PrintDeck jest podłączony do USB.","Si está desactivado, la pantalla permanece encendida cuando PrintDeck está conectado por USB.","Si cette option est désactivée, l’écran reste allumé lorsque PrintDeck est connecté en USB.","Wenn diese Option aus ist, bleibt der Bildschirm bei einer USB-Verbindung eingeschaltet.","关闭此项时，PrintDeck 连接 USB 后屏幕会保持亮起。"]
  ,"Off — stay awake":["Wyłączone — ekran zawsze aktywny","Desactivado — mantener encendida","Désactivé — rester allumé","Aus — eingeschaltet lassen","关闭 — 保持亮起"]
  ,"When no print is running":["Gdy drukowanie nie trwa","Cuando no hay una impresión en curso","Lorsqu’aucune impression n’est en cours","Wenn kein Druck läuft","未进行打印时"]
  ,"These timers start after the last touch, swipe, or button press.":["Te czasy są liczone od ostatniego dotknięcia, przesunięcia lub naciśnięcia przycisku.","Estos temporizadores empiezan después del último toque, deslizamiento o pulsación de botón.","Ces délais commencent après le dernier toucher, balayage ou appui sur un bouton.","Diese Timer starten nach der letzten Berührung, Wischgeste oder Tastenbetätigung.","这些定时器从最后一次触摸、滑动或按键后开始计时。"]
  ,"Dim after":["Przyciemnij po","Atenuar después de","Atténuer après","Dimmen nach","多久后调暗"]
  ,"How long PrintDeck waits before lowering brightness.":["Czas oczekiwania przed zmniejszeniem jasności.","Tiempo que espera PrintDeck antes de reducir el brillo.","Délai avant que PrintDeck réduise la luminosité.","Wartezeit, bevor PrintDeck die Helligkeit verringert.","PrintDeck 降低亮度前等待的时间。"]
  ,"Turn off after":["Wyłącz ekran po","Apagar después de","Éteindre après","Ausschalten nach","多久后熄灭"]
  ,"How long PrintDeck waits before making the screen black.":["Czas oczekiwania przed całkowitym wygaszeniem ekranu.","Tiempo que espera PrintDeck antes de dejar la pantalla negra.","Délai avant que PrintDeck rende l’écran noir.","Wartezeit, bevor PrintDeck den Bildschirm vollständig ausschaltet.","PrintDeck 使屏幕完全变黑前等待的时间。"]
  ,"During a print on active/selected printer":["Podczas druku na aktywnej/wybranej drukarce","Durante una impresión en la impresora activa/seleccionada","Pendant une impression sur l’imprimante active/sélectionnée","Während eines Drucks auf dem aktiven/ausgewählten Drucker","在当前使用/选中的打印机打印期间"]
  ,"Use longer times if you want to glance at progress without touching the screen.":["Ustaw dłuższy czas, jeśli chcesz sprawdzać postęp bez dotykania ekranu.","Usa tiempos más largos si quieres consultar el progreso sin tocar la pantalla.","Choisissez des délais plus longs pour consulter la progression sans toucher l’écran.","Wähle längere Zeiten, wenn du den Fortschritt ohne Berührung ablesen möchtest.","如果希望无需触摸屏幕即可查看进度，请设置更长的时间。"]
  ,"How long PrintDeck waits before lowering brightness during a print.":["Czas oczekiwania przed zmniejszeniem jasności podczas drukowania.","Tiempo que espera PrintDeck antes de reducir el brillo durante una impresión.","Délai avant que PrintDeck réduise la luminosité pendant une impression.","Wartezeit, bevor PrintDeck die Helligkeit während eines Drucks verringert.","打印期间 PrintDeck 降低亮度前等待的时间。"]
  ,"How long PrintDeck waits before making the screen black during a print.":["Czas oczekiwania przed całkowitym wygaszeniem ekranu podczas drukowania.","Tiempo que espera PrintDeck antes de dejar la pantalla negra durante una impresión.","Délai avant que PrintDeck rende l’écran noir pendant une impression.","Wartezeit, bevor PrintDeck den Bildschirm während eines Drucks ausschaltet.","打印期间 PrintDeck 使屏幕完全变黑前等待的时间。"]
  ,"Wake options":["Opcje wybudzania","Opciones de activación","Options de réveil","Aufweckoptionen","唤醒选项"]
  ,"Choose an additional way to wake a fully black screen.":["Wybierz dodatkowy sposób wybudzania całkowicie wygaszonego ekranu.","Elige otra forma de activar una pantalla completamente apagada.","Choisissez une méthode supplémentaire pour réveiller un écran totalement noir.","Wähle eine zusätzliche Möglichkeit, einen vollständig schwarzen Bildschirm aufzuwecken.","选择一种额外方式来唤醒完全熄灭的屏幕。"]
  ,"Wake when orientation changes":["Wybudzaj po zmianie orientacji","Activar al cambiar la orientación","Réveiller au changement d’orientation","Bei Ausrichtungsänderung aufwecken","方向变化时唤醒"]
  ,"Lifting or turning PrintDeck wakes the screen. Requires Rotate automatically in Display & Brightness.":["Podniesienie lub obrócenie PrintDeck wybudza ekran. Wymaga opcji Obracaj automatycznie w sekcji Ekran i jasność.","Levantar o girar PrintDeck activa la pantalla. Requiere Girar automáticamente en Pantalla y brillo.","Soulever ou tourner PrintDeck réveille l’écran. Nécessite Rotation automatique dans Écran et luminosité.","Beim Anheben oder Drehen von PrintDeck wird der Bildschirm geweckt. Erfordert Automatisch drehen unter Display und Helligkeit.","拿起或转动 PrintDeck 即可唤醒屏幕。需要在“屏幕和亮度”中启用“自动旋转”。"]
  ,"Setup, camera view, and firmware updates always keep the screen awake.":["Konfiguracja, widok kamery i aktualizacje oprogramowania zawsze utrzymują ekran aktywny.","La configuración, la vista de cámara y las actualizaciones de firmware mantienen siempre la pantalla encendida.","La configuration, la vue caméra et les mises à jour du micrologiciel maintiennent toujours l’écran allumé.","Einrichtung, Kameraansicht und Firmware-Updates halten den Bildschirm immer eingeschaltet.","设置、摄像头画面和固件更新期间，屏幕始终保持亮起。"]
  ,"Dim after when no print is running":["Przyciemnij po zakończeniu aktywności bez trwającego druku","Atenuar cuando no hay una impresión en curso","Atténuer lorsqu’aucune impression n’est en cours","Dimmen, wenn kein Druck läuft","未进行打印时多久后调暗"]
  ,"Turn off after when no print is running":["Wyłącz ekran po zakończeniu aktywności bez trwającego druku","Apagar cuando no hay una impresión en curso","Éteindre lorsqu’aucune impression n’est en cours","Ausschalten, wenn kein Druck läuft","未进行打印时多久后熄灭"]
  ,"Dim after during a print":["Przyciemnij po podczas drukowania","Atenuar durante una impresión","Atténuer pendant une impression","Während eines Drucks dimmen","打印期间多久后调暗"]
  ,"Turn off after during a print":["Wyłącz ekran po podczas drukowania","Apagar durante una impresión","Éteindre pendant une impression","Während eines Drucks ausschalten","打印期间多久后熄灭"]
  ,"Device":["Urządzenie","Dispositivo","Appareil","Gerät","设备"]
  ,"Live system information from this PrintDeck. Values update automatically.":["Bieżące informacje systemowe z tego PrintDeck. Wartości odświeżają się automatycznie.","Información del sistema de este PrintDeck en tiempo real. Los valores se actualizan automáticamente.","Informations système en direct de ce PrintDeck. Les valeurs s’actualisent automatiquement.","Live-Systeminformationen dieses PrintDeck. Die Werte werden automatisch aktualisiert.","此 PrintDeck 的实时系统信息。数值会自动更新。"]
  ,"Current device":["Bieżące urządzenie","Dispositivo actual","Appareil actuel","Aktuelles Gerät","当前设备"]
  ,"Uptime":["Czas pracy","Tiempo activo","Durée de fonctionnement","Betriebszeit","运行时间"]
  ,"CPU":["Procesor","CPU","Processeur","CPU","处理器"]
  ,"Internal RAM":["Pamięć wewnętrzna","RAM interna","Mémoire interne","Interner RAM","内部内存"]
  ,"PSRAM":["PSRAM","PSRAM","PSRAM","PSRAM","PSRAM"]
  ,"Flash":["Pamięć flash","Memoria flash","Mémoire flash","Flash-Speicher","闪存"]
  ,"Storage":["Magazyn danych","Almacenamiento","Stockage","Datenspeicher","存储空间"]
  ,"Network":["Sieć","Red","Réseau","Netzwerk","网络"]
  ,"Display":["Ekran","Pantalla","Écran","Display","显示屏"]
  ,"System":["System","Sistema","Système","System","系统"]
  ,"Internal RAM usage":["Wykorzystanie pamięci wewnętrznej","Uso de la RAM interna","Utilisation de la mémoire interne","Auslastung des internen RAM","内部内存用量"]
  ,"PSRAM usage":["Wykorzystanie PSRAM","Uso de PSRAM","Utilisation de la PSRAM","PSRAM-Auslastung","PSRAM 用量"]
  ,"Storage usage":["Wykorzystanie magazynu danych","Uso del almacenamiento","Utilisation du stockage","Speichernutzung","存储空间用量"]
  ,"Not available":["Niedostępne","No disponible","Indisponible","Nicht verfügbar","不可用"]
  ,"used":["wykorzystano","usado","utilisés","belegt","已使用"]
  ,"free":["wolne","libres","libres","frei","可用"]
  ,"lowest free":["minimum wolnej pamięci","mínimo libre","minimum libre","niedrigster freier Wert","最低可用"]
  ,"Firmware partition":["Partycja oprogramowania","Partición del firmware","Partition du micrologiciel","Firmware-Partition","固件分区"]
  ,"Content partition":["Partycja zawartości","Partición de contenido","Partition de contenu","Inhaltspartition","内容分区"]
  ,"Connected":["Połączono","Conectado","Connecté","Verbunden","已连接"]
  ,"Offline":["Brak połączenia","Sin conexión","Hors ligne","Offline","离线"]
  ,"Channel":["Kanał","Canal","Canal","Kanal","信道"]
  ,"Round display":["Okrągły ekran","Pantalla redonda","Écran rond","Rundes Display","圆形显示屏"]
  ,"Square display":["Kwadratowy ekran","Pantalla cuadrada","Écran carré","Quadratisches Display","方形显示屏"]
  ,"Last restart":["Ostatnie uruchomienie","Último reinicio","Dernier redémarrage","Letzter Neustart","上次重启"]
  ,"day":["d","día","jour","Tag","天"]
  ,"days":["d","días","jours","Tage","天"]
  ,"hour":["godz.","hora","heure","Stunde","小时"]
  ,"hours":["godz.","horas","heures","Stunden","小时"]
  ,"minute":["min","minuto","minute","Minute","分钟"]
  ,"minutes":["min","minutos","minutes","Minuten","分钟"]
  ,"core":["rdzeń","núcleo","cœur","Kern","核心"]
  ,"cores":["rdzenie","núcleos","cœurs","Kerne","核心"]
  ,"Power on":["Włączenie zasilania","Encendido","Mise sous tension","Einschalten","上电"]
  ,"External reset":["Reset zewnętrzny","Reinicio externo","Réinitialisation externe","Externer Reset","外部复位"]
  ,"Software restart":["Restart programowy","Reinicio por software","Redémarrage logiciel","Software-Neustart","软件重启"]
  ,"System fault":["Błąd systemu","Fallo del sistema","Défaillance système","Systemfehler","系统故障"]
  ,"Watchdog restart":["Restart przez układ nadzorujący","Reinicio por vigilancia","Redémarrage par surveillance","Watchdog-Neustart","看门狗重启"]
  ,"Deep sleep wake":["Wybudzenie z głębokiego uśpienia","Activación desde suspensión profunda","Réveil après veille profonde","Aufwachen aus Tiefschlaf","深度睡眠唤醒"]
  ,"Brownout":["Spadek napięcia","Caída de tensión","Chute de tension","Spannungseinbruch","欠压"]
  ,"USB reset":["Reset przez USB","Reinicio por USB","Réinitialisation USB","USB-Reset","USB 复位"]
  ,"System restart":["Restart systemu","Reinicio del sistema","Redémarrage système","Systemneustart","系统重启"]
  ,"Power glitch":["Zakłócenie zasilania","Interrupción de alimentación","Perturbation d’alimentation","Stromstörung","电源波动"]
  ,"CPU lockup":["Zablokowanie procesora","Bloqueo de la CPU","Blocage du processeur","CPU-Blockierung","处理器锁死"]
  ,"Backup & Restore":["Kopia i przywracanie","Copia y restauración","Sauvegarde et restauration","Sichern & Wiederherstellen","备份与恢复"]
  ,"Move your complete PrintDeck setup to a safe encrypted file and restore it on compatible PrintDeck hardware.":["Zapisz pełną konfigurację PrintDeck w bezpiecznym, zaszyfrowanym pliku i przywróć ją na zgodnym sprzęcie PrintDeck.","Guarda toda la configuración de PrintDeck en un archivo cifrado seguro y restáurala en hardware PrintDeck compatible.","Enregistrez toute la configuration de PrintDeck dans un fichier chiffré sûr et restaurez-la sur un matériel PrintDeck compatible.","Speichere die vollständige PrintDeck-Einrichtung in einer sicheren, verschlüsselten Datei und stelle sie auf kompatibler PrintDeck-Hardware wieder her.","将完整的 PrintDeck 设置保存到安全的加密文件中，并在兼容的 PrintDeck 硬件上恢复。"]
  ,"Private by design.":["Prywatność od podstaw.","Privado desde el diseño.","Confidentiel par conception.","Datenschutz von Grund auf.","隐私保护融入设计。"]
  ,"Encryption and decryption happen locally between this browser and PrintDeck. Nothing is uploaded to a cloud service. Store the password somewhere safe—without it, the backup cannot be opened or recovered.":["Szyfrowanie i odszyfrowywanie odbywa się lokalnie między tą przeglądarką a PrintDeck. Nic nie jest wysyłane do chmury. Zapisz hasło w bezpiecznym miejscu — bez niego nie można otworzyć ani odzyskać kopii.","El cifrado y descifrado se realizan localmente entre este navegador y PrintDeck. No se sube nada a la nube. Guarda la contraseña en un lugar seguro: sin ella no se puede abrir ni recuperar la copia.","Le chiffrement et le déchiffrement s’effectuent localement entre ce navigateur et PrintDeck. Rien n’est envoyé vers un service cloud. Conservez le mot de passe en lieu sûr : sans lui, la sauvegarde ne peut être ni ouverte ni récupérée.","Ver- und Entschlüsselung erfolgen lokal zwischen diesem Browser und PrintDeck. Nichts wird in einen Cloud-Dienst hochgeladen. Bewahre das Passwort sicher auf – ohne dieses kann die Sicherung weder geöffnet noch wiederhergestellt werden.","加密和解密仅在此浏览器与 PrintDeck 之间本地进行，不会上传到任何云服务。请安全保存密码；没有密码，备份将无法打开或恢复。"]
  ,"Create backup":["Utwórz kopię","Crear copia","Créer une sauvegarde","Sicherung erstellen","创建备份"]
  ,"Includes Wi-Fi, printer profiles and credentials, display and sound settings, reactions, and your custom GIF animations.":["Obejmuje Wi-Fi, profile i dane dostępu do drukarek, ustawienia ekranu i dźwięku, reakcje oraz własne animacje GIF.","Incluye Wi-Fi, perfiles y credenciales de impresoras, ajustes de pantalla y sonido, reacciones y animaciones GIF personalizadas.","Inclut le Wi-Fi, les profils et identifiants d’imprimantes, les réglages d’affichage et de son, les réactions et vos animations GIF personnalisées.","Enthält WLAN, Druckerprofile und Zugangsdaten, Display- und Toneinstellungen, Reaktionen sowie eigene GIF-Animationen.","包括 Wi-Fi、打印机配置和凭据、显示与声音设置、反应以及自定义 GIF 动画。"]
  ,"Backup password":["Hasło kopii","Contraseña de la copia","Mot de passe de la sauvegarde","Sicherungspasswort","备份密码"]
  ,"Confirm backup password":["Potwierdź hasło kopii","Confirmar contraseña","Confirmer le mot de passe","Sicherungspasswort bestätigen","确认备份密码"]
  ,"Create & download encrypted backup":["Utwórz i pobierz zaszyfrowaną kopię","Crear y descargar copia cifrada","Créer et télécharger la sauvegarde chiffrée","Verschlüsselte Sicherung erstellen und herunterladen","创建并下载加密备份"]
  ,"Restore backup":["Przywróć kopię","Restaurar copia","Restaurer une sauvegarde","Sicherung wiederherstellen","恢复备份"]
  ,"Choose a .pdeck file and enter its password. PrintDeck checks compatibility and space before anything changes.":["Wybierz plik .pdeck i wpisz jego hasło. Przed wprowadzeniem zmian PrintDeck sprawdzi zgodność i dostępne miejsce.","Elige un archivo .pdeck e introduce su contraseña. PrintDeck comprueba la compatibilidad y el espacio antes de cambiar nada.","Choisissez un fichier .pdeck et saisissez son mot de passe. PrintDeck vérifie la compatibilité et l’espace disponible avant toute modification.","Wähle eine .pdeck-Datei und gib ihr Passwort ein. PrintDeck prüft Kompatibilität und Speicherplatz, bevor etwas geändert wird.","选择 .pdeck 文件并输入密码。PrintDeck 会在进行任何更改前检查兼容性和可用空间。"]
  ,"PrintDeck backup file":["Plik kopii PrintDeck","Archivo de copia de PrintDeck","Fichier de sauvegarde PrintDeck","PrintDeck-Sicherungsdatei","PrintDeck 备份文件"]
  ,"Check backup":["Sprawdź kopię","Comprobar copia","Vérifier la sauvegarde","Sicherung prüfen","检查备份"]
  ,"Backup ready to restore":["Kopia gotowa do przywrócenia","Copia lista para restaurar","Sauvegarde prête à être restaurée","Sicherung ist zur Wiederherstellung bereit","备份已可恢复"]
  ,"Created":["Utworzono","Creada","Créée","Erstellt","创建时间"]
  ,"Hardware":["Sprzęt","Hardware","Matériel","Hardware","硬件"]
  ,"Printer profiles":["Profile drukarek","Perfiles de impresora","Profils d’imprimante","Druckerprofile","打印机配置"]
  ,"Custom animations":["Własne animacje","Animaciones personalizadas","Animations personnalisées","Eigene Animationen","自定义动画"]
  ,"Backup size":["Rozmiar kopii","Tamaño de la copia","Taille de la sauvegarde","Sicherungsgröße","备份大小"]
  ,"Keep current Wi-Fi settings":["Zachowaj bieżące ustawienia Wi-Fi","Conservar el Wi-Fi actual","Conserver les réglages Wi-Fi actuels","Aktuelle WLAN-Einstellungen behalten","保留当前 Wi-Fi 设置"]
  ,"Recommended when restoring over your normal Wi-Fi connection so this page can reconnect after restart.":["Zalecane przy przywracaniu przez zwykłe połączenie Wi-Fi, aby ta strona mogła połączyć się ponownie po restarcie.","Recomendado al restaurar mediante la conexión Wi-Fi habitual para que esta página pueda volver a conectarse tras el reinicio.","Recommandé lors d’une restauration via votre connexion Wi-Fi habituelle afin que cette page puisse se reconnecter après le redémarrage.","Empfohlen bei der Wiederherstellung über die normale WLAN-Verbindung, damit sich diese Seite nach dem Neustart erneut verbinden kann.","通过常用 Wi-Fi 连接恢复时建议保留，以便此页面在重启后重新连接。"]
  ,"Restore and restart PrintDeck":["Przywróć i uruchom PrintDeck ponownie","Restaurar y reiniciar PrintDeck","Restaurer et redémarrer PrintDeck","PrintDeck wiederherstellen und neu starten","恢复并重启 PrintDeck"]
  ,"This browser cannot create secure random values.":["Ta przeglądarka nie potrafi utworzyć bezpiecznych wartości losowych.","Este navegador no puede crear valores aleatorios seguros.","Ce navigateur ne peut pas créer de valeurs aléatoires sûres.","Dieser Browser kann keine sicheren Zufallswerte erzeugen.","此浏览器无法生成安全的随机值。"]
  ,"The backup file is damaged.":["Plik kopii jest uszkodzony.","El archivo de copia está dañado.","Le fichier de sauvegarde est endommagé.","Die Sicherungsdatei ist beschädigt.","备份文件已损坏。"]
  ,"Use a password with at least 12 characters.":["Użyj hasła składającego się z co najmniej 12 znaków.","Usa una contraseña de al menos 12 caracteres.","Utilisez un mot de passe d’au moins 12 caractères.","Verwende ein Passwort mit mindestens 12 Zeichen.","请使用至少 12 个字符的密码。"]
  ,"Wait for the current reaction change to finish.":["Poczekaj na zakończenie bieżącej zmiany reakcji.","Espera a que termine el cambio de reacción actual.","Attendez la fin de la modification de réaction en cours.","Warte, bis die aktuelle Reaktionsänderung abgeschlossen ist.","请等待当前反应更改完成。"]
  ,"Encrypting custom animations…":["Szyfrowanie własnych animacji…","Cifrando animaciones personalizadas…","Chiffrement des animations personnalisées…","Eigene Animationen werden verschlüsselt…","正在加密自定义动画…"]
  ,"A custom animation exceeds the device limit.":["Jedna z własnych animacji przekracza limit urządzenia.","Una animación personalizada supera el límite del dispositivo.","Une animation personnalisée dépasse la limite de l’appareil.","Eine eigene Animation überschreitet das Gerätelimit.","某个自定义动画超过设备限制。"]
  ,"The custom animations exceed the device limit.":["Własne animacje przekraczają łączny limit urządzenia.","Las animaciones personalizadas superan el límite total del dispositivo.","Les animations personnalisées dépassent la limite totale de l’appareil.","Die eigenen Animationen überschreiten das Gesamtlimit des Geräts.","自定义动画超过设备总限制。"]
  ,"Encrypted backup saved. Store its password somewhere safe.":["Zaszyfrowana kopia została zapisana. Zachowaj jej hasło w bezpiecznym miejscu.","Copia cifrada guardada. Conserva su contraseña en un lugar seguro.","Sauvegarde chiffrée enregistrée. Conservez son mot de passe en lieu sûr.","Verschlüsselte Sicherung gespeichert. Bewahre ihr Passwort sicher auf.","加密备份已保存。请将密码保存在安全位置。"]
  ,"The backup passwords do not match.":["Hasła kopii nie są takie same.","Las contraseñas de la copia no coinciden.","Les mots de passe de la sauvegarde ne correspondent pas.","Die Sicherungspasswörter stimmen nicht überein.","两次输入的备份密码不一致。"]
  ,"Preparing encrypted configuration…":["Przygotowywanie zaszyfrowanej konfiguracji…","Preparando la configuración cifrada…","Préparation de la configuration chiffrée…","Verschlüsselte Konfiguration wird vorbereitet…","正在准备加密配置…"]
  ,"PrintDeck returned an invalid encrypted configuration.":["PrintDeck zwrócił nieprawidłową zaszyfrowaną konfigurację.","PrintDeck devolvió una configuración cifrada no válida.","PrintDeck a renvoyé une configuration chiffrée non valide.","PrintDeck hat eine ungültige verschlüsselte Konfiguration zurückgegeben.","PrintDeck 返回了无效的加密配置。"]
  ,"The reaction set in this backup is not available on this PrintDeck.":["Zestaw reakcji z tej kopii nie jest dostępny na tym PrintDeck.","El conjunto de reacciones de esta copia no está disponible en este PrintDeck.","Le jeu de réactions de cette sauvegarde n’est pas disponible sur ce PrintDeck.","Das Reaktionsset dieser Sicherung ist auf diesem PrintDeck nicht verfügbar.","此备份中的反应套装在这台 PrintDeck 上不可用。"]
  ,"Choose a PrintDeck .pdeck file first.":["Najpierw wybierz plik PrintDeck .pdeck.","Elige primero un archivo .pdeck de PrintDeck.","Choisissez d’abord un fichier PrintDeck .pdeck.","Wähle zuerst eine PrintDeck-.pdeck-Datei.","请先选择 PrintDeck .pdeck 文件。"]
  ,"The backup file is too large or empty.":["Plik kopii jest zbyt duży lub pusty.","El archivo de copia es demasiado grande o está vacío.","Le fichier de sauvegarde est trop volumineux ou vide.","Die Sicherungsdatei ist zu groß oder leer.","备份文件过大或为空。"]
  ,"Enter the backup password.":["Wpisz hasło kopii.","Introduce la contraseña de la copia.","Saisissez le mot de passe de la sauvegarde.","Gib das Sicherungspasswort ein.","请输入备份密码。"]
  ,"Checking backup and available space…":["Sprawdzanie kopii i dostępnego miejsca…","Comprobando la copia y el espacio disponible…","Vérification de la sauvegarde et de l’espace disponible…","Sicherung und verfügbarer Speicher werden geprüft…","正在检查备份和可用空间…"]
  ,"This backup format is not supported.":["Ten format kopii nie jest obsługiwany.","Este formato de copia no es compatible.","Ce format de sauvegarde n’est pas pris en charge.","Dieses Sicherungsformat wird nicht unterstützt.","不支持此备份格式。"]
  ,"This backup was created for different PrintDeck hardware.":["Ta kopia została utworzona dla innego sprzętu PrintDeck.","Esta copia se creó para otro hardware PrintDeck.","Cette sauvegarde a été créée pour un autre matériel PrintDeck.","Diese Sicherung wurde für andere PrintDeck-Hardware erstellt.","此备份是为其他 PrintDeck 硬件创建的。"]
  ,"Backup checked. Review the summary before restoring.":["Kopia została sprawdzona. Przed przywróceniem przejrzyj podsumowanie.","Copia comprobada. Revisa el resumen antes de restaurar.","Sauvegarde vérifiée. Consultez le résumé avant la restauration.","Sicherung geprüft. Prüfe vor der Wiederherstellung die Zusammenfassung.","备份检查完成。恢复前请查看摘要。"]
  ,"Restoring reaction set…":["Przywracanie zestawu reakcji…","Restaurando el conjunto de reacciones…","Restauration du jeu de réactions…","Reaktionsset wird wiederhergestellt…","正在恢复反应套装…"]
  ,"The reaction set could not be restored.":["Nie udało się przywrócić zestawu reakcji.","No se pudo restaurar el conjunto de reacciones.","Le jeu de réactions n’a pas pu être restauré.","Das Reaktionsset konnte nicht wiederhergestellt werden.","无法恢复反应套装。"]
  ,"The reaction set restore timed out.":["Przekroczono czas przywracania zestawu reakcji.","Se agotó el tiempo para restaurar el conjunto de reacciones.","Le délai de restauration du jeu de réactions a expiré.","Zeitüberschreitung bei der Wiederherstellung des Reaktionssets.","恢复反应套装超时。"]
  ,"Removing animations that are not in the backup…":["Usuwanie animacji, których nie ma w kopii…","Eliminando animaciones que no están en la copia…","Suppression des animations absentes de la sauvegarde…","Animationen, die nicht in der Sicherung enthalten sind, werden entfernt…","正在移除备份中不存在的动画…"]
  ,"Restoring custom animations…":["Przywracanie własnych animacji…","Restaurando animaciones personalizadas…","Restauration des animations personnalisées…","Eigene Animationen werden wiederhergestellt…","正在恢复自定义动画…"]
  ,"Starting reaction set restore…":["Rozpoczynanie przywracania zestawu reakcji…","Iniciando la restauración del conjunto de reacciones…","Démarrage de la restauration du jeu de réactions…","Wiederherstellung des Reaktionssets wird gestartet…","正在开始恢复反应套装…"]
  ,"Creating a temporary rollback point…":["Tworzenie tymczasowego punktu wycofania…","Creando un punto de reversión temporal…","Création d’un point de retour temporaire…","Temporärer Rücksetzpunkt wird erstellt…","正在创建临时回退点…"]
  ,"Saving restored settings…":["Zapisywanie przywróconych ustawień…","Guardando los ajustes restaurados…","Enregistrement des réglages restaurés…","Wiederhergestellte Einstellungen werden gespeichert…","正在保存恢复的设置…"]
  ,"Restore complete. PrintDeck is restarting…":["Przywracanie zakończone. PrintDeck uruchamia się ponownie…","Restauración completada. PrintDeck se está reiniciando…","Restauration terminée. PrintDeck redémarre…","Wiederherstellung abgeschlossen. PrintDeck wird neu gestartet…","恢复完成。PrintDeck 正在重启…"]
  ,"Restore failed. Returning reactions to their previous state…":["Przywracanie nie powiodło się. Przywracanie poprzedniego stanu reakcji…","La restauración falló. Recuperando el estado anterior de las reacciones…","La restauration a échoué. Retour des réactions à leur état précédent…","Wiederherstellung fehlgeschlagen. Reaktionen werden auf den vorherigen Stand zurückgesetzt…","恢复失败。正在将反应恢复到先前状态…"]
  ,"Restore stopped and the previous reactions could not be fully restored. Review Reactions before trying again.":["Przywracanie zatrzymano, a poprzedniego stanu reakcji nie udało się w pełni odtworzyć. Przed kolejną próbą sprawdź sekcję Reakcje.","La restauración se detuvo y no fue posible recuperar por completo las reacciones anteriores. Revisa Reacciones antes de volver a intentarlo.","La restauration s’est arrêtée et les réactions précédentes n’ont pas pu être entièrement rétablies. Vérifiez Réactions avant de réessayer.","Die Wiederherstellung wurde gestoppt und die vorherigen Reaktionen konnten nicht vollständig zurückgesetzt werden. Prüfe vor einem neuen Versuch den Bereich Reaktionen.","恢复已停止，先前的反应未能完全恢复。再次尝试前请检查“反应”部分。"]
  ,"PrintDeck could not prepare the encrypted backup.":["PrintDeck nie mógł przygotować zaszyfrowanej kopii.","PrintDeck no pudo preparar la copia cifrada.","PrintDeck n’a pas pu préparer la sauvegarde chiffrée.","PrintDeck konnte die verschlüsselte Sicherung nicht vorbereiten.","PrintDeck 无法准备加密备份。"]
  ,"PrintDeck could not derive the backup key.":["PrintDeck nie mógł utworzyć klucza kopii.","PrintDeck no pudo generar la clave de la copia.","PrintDeck n’a pas pu générer la clé de sauvegarde.","PrintDeck konnte den Sicherungsschlüssel nicht ableiten.","PrintDeck 无法生成备份密钥。"]
  ,"There is not enough memory to create the backup.":["Brakuje pamięci do utworzenia kopii.","No hay memoria suficiente para crear la copia.","La mémoire est insuffisante pour créer la sauvegarde.","Zum Erstellen der Sicherung ist nicht genügend Speicher verfügbar.","内存不足，无法创建备份。"]
  ,"PrintDeck could not encrypt the backup.":["PrintDeck nie mógł zaszyfrować kopii.","PrintDeck no pudo cifrar la copia.","PrintDeck n’a pas pu chiffrer la sauvegarde.","PrintDeck konnte die Sicherung nicht verschlüsseln.","PrintDeck 无法加密备份。"]
  ,"The backup configuration is too large or incomplete.":["Konfiguracja w kopii jest zbyt duża lub niekompletna.","La configuración de la copia es demasiado grande o está incompleta.","La configuration de la sauvegarde est trop volumineuse ou incomplète.","Die Sicherungskonfiguration ist zu groß oder unvollständig.","备份配置过大或不完整。"]
  ,"The backup password is incorrect or the file is damaged.":["Hasło kopii jest nieprawidłowe albo plik jest uszkodzony.","La contraseña de la copia es incorrecta o el archivo está dañado.","Le mot de passe est incorrect ou le fichier est endommagé.","Das Sicherungspasswort ist falsch oder die Datei ist beschädigt.","备份密码错误或文件已损坏。"]
  ,"This backup needs a newer PrintDeck version.":["Ta kopia wymaga nowszej wersji PrintDeck.","Esta copia necesita una versión más reciente de PrintDeck.","Cette sauvegarde nécessite une version plus récente de PrintDeck.","Diese Sicherung benötigt eine neuere PrintDeck-Version.","此备份需要更新版本的 PrintDeck。"]
  ,"The backup configuration did not pass validation.":["Konfiguracja z kopii nie przeszła weryfikacji.","La configuración de la copia no superó la validación.","La configuration de la sauvegarde n’a pas réussi la validation.","Die Sicherungskonfiguration hat die Prüfung nicht bestanden.","备份配置未通过验证。"]
  ,"The restored settings did not pass validation.":["Przywrócone ustawienia nie przeszły weryfikacji.","Los ajustes restaurados no superaron la validación.","Les réglages restaurés n’ont pas réussi la validation.","Die wiederhergestellten Einstellungen haben die Prüfung nicht bestanden.","恢复的设置未通过验证。"]
  ,"PrintDeck could not save the restored settings.":["PrintDeck nie mógł zapisać przywróconych ustawień.","PrintDeck no pudo guardar los ajustes restaurados.","PrintDeck n’a pas pu enregistrer les réglages restaurés.","PrintDeck konnte die wiederhergestellten Einstellungen nicht speichern.","PrintDeck 无法保存恢复的设置。"]
  ,"No custom animation is available for this reaction.":["Dla tej reakcji nie ma własnej animacji.","No hay una animación personalizada para esta reacción.","Aucune animation personnalisée n’est disponible pour cette réaction.","Für diese Reaktion ist keine eigene Animation verfügbar.","此反应没有可用的自定义动画。"]
  ,"PrintDeck could not prepare this encrypted animation.":["PrintDeck nie mógł przygotować tej zaszyfrowanej animacji.","PrintDeck no pudo preparar esta animación cifrada.","PrintDeck n’a pas pu préparer cette animation chiffrée.","PrintDeck konnte diese verschlüsselte Animation nicht vorbereiten.","PrintDeck 无法准备此加密动画。"]
  ,"The custom animation exceeds the device limit.":["Własna animacja przekracza limit urządzenia.","La animación personalizada supera el límite del dispositivo.","L’animation personnalisée dépasse la limite de l’appareil.","Die eigene Animation überschreitet das Gerätelimit.","自定义动画超过设备限制。"]
  ,"PrintDeck could not encrypt this animation.":["PrintDeck nie mógł zaszyfrować tej animacji.","PrintDeck no pudo cifrar esta animación.","PrintDeck n’a pas pu chiffrer cette animation.","PrintDeck konnte diese Animation nicht verschlüsseln.","PrintDeck 无法加密此动画。"]
  ,"The encrypted animation is too large or incomplete.":["Zaszyfrowana animacja jest zbyt duża lub niekompletna.","La animación cifrada es demasiado grande o está incompleta.","L’animation chiffrée est trop volumineuse ou incomplète.","Die verschlüsselte Animation ist zu groß oder unvollständig.","加密动画过大或不完整。"]
  ,"The backup password is incorrect or the animation is damaged.":["Hasło kopii jest nieprawidłowe albo animacja jest uszkodzona.","La contraseña de la copia es incorrecta o la animación está dañada.","Le mot de passe est incorrect ou l’animation est endommagée.","Das Sicherungspasswort ist falsch oder die Animation ist beschädigt.","备份密码错误或动画已损坏。"]
  ,"The restored animation did not pass device validation.":["Przywracana animacja nie przeszła weryfikacji urządzenia.","La animación restaurada no superó la validación del dispositivo.","L’animation restaurée n’a pas réussi la validation de l’appareil.","Die wiederhergestellte Animation hat die Geräteprüfung nicht bestanden.","恢复的动画未通过设备验证。"]
  ,"Unified Printer API":["Ujednolicone API drukarek","API unificada de impresoras","API unifiée des imprimantes","Einheitliche Drucker-API","统一打印机 API"]
  ,"Use one read-only JSON format for every printer connected to this PrintDeck.":["Korzystaj z jednego formatu JSON tylko do odczytu dla każdej drukarki połączonej z tym PrintDeckiem.","Usa un único formato JSON de solo lectura para cada impresora conectada a este PrintDeck.","Utilisez un seul format JSON en lecture seule pour chaque imprimante connectée à ce PrintDeck.","Nutze ein einziges schreibgeschütztes JSON-Format für jeden mit diesem PrintDeck verbundenen Drucker.","为连接到此 PrintDeck 的每台打印机使用统一的只读 JSON 格式。"]
  ,"Local developer access":["Lokalny dostęp dla deweloperów","Acceso local para desarrolladores","Accès local pour les développeurs","Lokaler Entwicklerzugriff","本地开发者访问"]
  ,"Your software talks to PrintDeck instead of handling Moonraker and Bambu Lab formats separately.":["Twój program komunikuje się z PrintDeckiem zamiast osobno obsługiwać formaty Moonraker i Bambu Lab.","Tu software se comunica con PrintDeck en vez de gestionar por separado los formatos de Moonraker y Bambu Lab.","Votre logiciel communique avec PrintDeck au lieu de gérer séparément les formats Moonraker et Bambu Lab.","Deine Software spricht mit PrintDeck, statt Moonraker- und Bambu-Lab-Formate getrennt zu verarbeiten.","你的软件只需连接 PrintDeck，无需分别处理 Moonraker 和 Bambu Lab 格式。"]
  ,"Enabled":["Włączone","Activada","Activée","Aktiviert","已启用"]
  ,"Disabled":["Wyłączone","Desactivada","Désactivée","Deaktiviert","已禁用"]
  ,"Enable API":["Włącz API","Activar API","Activer l’API","API aktivieren","启用 API"]
  ,"Disable API":["Wyłącz API","Desactivar API","Désactiver l’API","API deaktivieren","禁用 API"]
  ,"API token":["Token API","Token de API","Jeton d’API","API-Token","API 令牌"]
  ,"Send this token as an Authorization: Bearer header. It is different from a printer LAN access code.":["Wysyłaj ten token w nagłówku Authorization: Bearer. To nie jest kod dostępu LAN drukarki.","Envía este token en la cabecera Authorization: Bearer. Es distinto del código de acceso LAN de una impresora.","Envoyez ce jeton dans l’en-tête Authorization: Bearer. Il est différent du code d’accès LAN d’une imprimante.","Sende dieses Token im Header Authorization: Bearer. Es unterscheidet sich vom LAN-Zugriffscode eines Druckers.","请在 Authorization: Bearer 请求头中发送此令牌。它不同于打印机的局域网访问码。"]
  ,"Unified Printer API token":["Token Ujednoliconego API drukarek","Token de la API unificada de impresoras","Jeton de l’API unifiée des imprimantes","Token der einheitlichen Drucker-API","统一打印机 API 令牌"]
  ,"Show token":["Pokaż token","Mostrar token","Afficher le jeton","Token anzeigen","显示令牌"]
  ,"Hide token":["Ukryj token","Ocultar token","Masquer le jeton","Token ausblenden","隐藏令牌"]
  ,"Copy token":["Kopiuj token","Copiar token","Copier le jeton","Token kopieren","复制令牌"]
  ,"Generate new token":["Wygeneruj nowy token","Generar un token nuevo","Générer un nouveau jeton","Neues Token erzeugen","生成新令牌"]
  ,"Base URL":["Bazowy adres URL","URL base","URL de base","Basis-URL","基础 URL"]
  ,"Keep PrintDeck on a trusted local network. The API is read-only, but anyone with this token can read printer names, addresses and status data.":["Trzymaj PrintDeck w zaufanej sieci lokalnej. API służy tylko do odczytu, ale każda osoba z tym tokenem może odczytać nazwy, adresy i stany drukarek.","Mantén PrintDeck en una red local de confianza. La API es de solo lectura, pero cualquiera con este token puede leer nombres, direcciones y estados de las impresoras.","Gardez PrintDeck sur un réseau local de confiance. L’API est en lecture seule, mais toute personne possédant ce jeton peut lire les noms, adresses et états des imprimantes.","Betreibe PrintDeck in einem vertrauenswürdigen lokalen Netzwerk. Die API ist schreibgeschützt, doch jeder mit diesem Token kann Druckernamen, Adressen und Statusdaten lesen.","请将 PrintDeck 置于可信的本地网络中。API 为只读，但持有此令牌的人可以读取打印机名称、地址和状态数据。"]
  ,"Request throttling enabled: 1 request per second.":["Ograniczanie zapytań jest włączone: 1 zapytanie na sekundę.","Limitación de solicitudes activada: 1 solicitud por segundo.","Limitation des requêtes activée : 1 requête par seconde.","Anfragedrosselung aktiviert: 1 Anfrage pro Sekunde.","已启用请求限流：每秒 1 个请求。"]
  ,"Faster requests return HTTP 429 Too Many Requests.":["Częstsze zapytania zwracają HTTP 429 Too Many Requests.","Las solicitudes más rápidas devuelven HTTP 429 Too Many Requests.","Les requêtes plus fréquentes renvoient HTTP 429 Too Many Requests.","Häufigere Anfragen erhalten HTTP 429 Too Many Requests.","更频繁的请求会返回 HTTP 429 Too Many Requests。"]
  ,"PrintDeck, firmware and network details without passwords.":["Informacje o PrintDeckzie, firmware i sieci bez haseł.","Datos de PrintDeck, firmware y red sin contraseñas.","Informations sur PrintDeck, le micrologiciel et le réseau, sans mots de passe.","PrintDeck-, Firmware- und Netzwerkdaten ohne Passwörter.","不含密码的 PrintDeck、固件和网络信息。"]
  ,"Saved printers in one safe, normalized format.":["Zapisane drukarki w jednym bezpiecznym, ujednoliconym formacie.","Impresoras guardadas en un formato seguro y normalizado.","Imprimantes enregistrées dans un format sûr et normalisé.","Gespeicherte Drucker in einem sicheren, einheitlichen Format.","以安全、统一的格式返回已保存的打印机。"]
  ,"Compact status for every saved printer.":["Skrócony stan każdej zapisanej drukarki.","Estado resumido de cada impresora guardada.","État synthétique de chaque imprimante enregistrée.","Kompakter Status für jeden gespeicherten Drucker.","每台已保存打印机的精简状态。"]
  ,"Identity, address and supported data groups.":["Tożsamość, adres i obsługiwane grupy danych.","Identidad, dirección y grupos de datos compatibles.","Identité, adresse et groupes de données pris en charge.","Identität, Adresse und unterstützte Datengruppen.","身份、地址和支持的数据组。"]
  ,"Job state, progress, time and available temperatures.":["Stan zadania, postęp, czas i dostępne temperatury.","Estado del trabajo, progreso, tiempo y temperaturas disponibles.","État de la tâche, progression, temps et températures disponibles.","Auftragsstatus, Fortschritt, Zeit und verfügbare Temperaturen.","任务状态、进度、时间和可用温度。"]
  ,"Tools, materials and current or target temperatures.":["Narzędzia, materiały oraz temperatury bieżące i docelowe.","Herramientas, materiales y temperaturas actuales u objetivo.","Outils, matériaux et températures actuelles ou cibles.","Werkzeuge, Materialien sowie Ist- und Zieltemperaturen.","工具、材料以及当前或目标温度。"]
  ,"AMS, AMS Lite and external spool data when available.":["Dane AMS, AMS Lite i zewnętrznych szpul, gdy są dostępne.","Datos de AMS, AMS Lite y bobinas externas cuando estén disponibles.","Données AMS, AMS Lite et bobines externes lorsqu’elles sont disponibles.","AMS-, AMS-Lite- und externe Spulendaten, sofern verfügbar.","在可用时返回 AMS、AMS Lite 和外置料盘数据。"]
  ,"No controls, webhooks or cloud account.":["Bez sterowania, webhooków i konta w chmurze.","Sin controles, webhooks ni cuenta en la nube.","Sans commandes, webhooks ni compte cloud.","Keine Steuerung, Webhooks oder Cloud-Konten.","无控制操作、Webhook 或云账户。"]
  ,"Open the complete API guide (PDF)":["Otwórz pełny przewodnik po API (PDF)","Abrir la guía completa de la API (PDF)","Ouvrir le guide complet de l’API (PDF)","Vollständigen API-Leitfaden öffnen (PDF)","打开完整 API 指南 (PDF)"]
  ,"Saving API settings…":["Zapisywanie ustawień API…","Guardando los ajustes de la API…","Enregistrement des paramètres de l’API…","API-Einstellungen werden gespeichert…","正在保存 API 设置…"]
  ,"New API token generated.":["Wygenerowano nowy token API.","Se ha generado un nuevo token de API.","Un nouveau jeton d’API a été généré.","Neues API-Token wurde erzeugt.","已生成新的 API 令牌。"]
  ,"API settings saved.":["Zapisano ustawienia API.","Ajustes de la API guardados.","Paramètres de l’API enregistrés.","API-Einstellungen gespeichert.","API 设置已保存。"]
  ,"Generate a new API token? Software using the current token will stop working.":["Wygenerować nowy token API? Programy używające obecnego tokenu przestaną działać.","¿Generar un nuevo token de API? El software que use el token actual dejará de funcionar.","Générer un nouveau jeton d’API ? Les logiciels utilisant le jeton actuel cesseront de fonctionner.","Neues API-Token erzeugen? Software mit dem aktuellen Token funktioniert danach nicht mehr.","要生成新的 API 令牌吗？使用当前令牌的软件将停止工作。"]
  ,"API token copied.":["Skopiowano token API.","Token de API copiado.","Jeton d’API copié.","API-Token kopiert.","API 令牌已复制。"]
  ,"The API token could not be copied.":["Nie udało się skopiować tokenu API.","No se pudo copiar el token de API.","Le jeton d’API n’a pas pu être copié.","Das API-Token konnte nicht kopiert werden.","无法复制 API 令牌。"]
  ,"Use cases":["Zastosowania","Casos de uso","Cas d’usage","Anwendungsfälle","使用场景"]
  ,"Use cases:":["Zastosowania:","Casos de uso:","Cas d’usage :","Anwendungsfälle:","使用场景："]
  ,"Home Assistant":["Home Assistant","Home Assistant","Home Assistant","Home Assistant","Home Assistant"]
  ,"Open the Home Assistant use case":["Otwórz zastosowanie Home Assistant","Abrir el caso de uso de Home Assistant","Ouvrir le cas d’usage Home Assistant","Home-Assistant-Anwendungsfall öffnen","打开 Home Assistant 使用场景"]
  ,"More integrations soon":["Wkrótce kolejne integracje","Próximamente, más integraciones","D’autres intégrations prochainement","Weitere Integrationen folgen","更多集成即将推出"]
  ,"More →":["Więcej →","Más →","Plus →","Mehr →","更多 →"]
  ,"Explore all API use cases":["Zobacz wszystkie zastosowania API","Explorar todos los casos de uso de la API","Explorer tous les cas d’usage de l’API","Alle API-Anwendungsfälle ansehen","浏览所有 API 使用场景"]
  ,"Found in this scan":["Znalezione w tym skanowaniu","Encontradas en este escaneo","Trouvées pendant cette recherche","Bei dieser Suche gefunden","本次扫描发现"]
  ,"Recently found":["Ostatnio znalezione","Encontradas recientemente","Trouvées récemment","Kürzlich gefunden","最近发现"]
  ,"Check & add":["Sprawdź i dodaj","Comprobar y añadir","Vérifier et ajouter","Prüfen und hinzufügen","检查并添加"]
  ,"Checking printer connection…":["Sprawdzanie połączenia z drukarką…","Comprobando la conexión con la impresora…","Vérification de la connexion à l’imprimante…","Druckerverbindung wird geprüft…","正在检查打印机连接…"]
  ,"Printer connection verified.":["Połączenie z drukarką zostało sprawdzone.","Conexión con la impresora verificada.","Connexion à l’imprimante vérifiée.","Druckerverbindung bestätigt.","打印机连接已验证。"]
  ,"Preparing the connection test…":["Przygotowywanie testu połączenia…","Preparando la prueba de conexión…","Préparation du test de connexion…","Verbindungstest wird vorbereitet…","正在准备连接测试…"]
  ,"Enter the LAN access code, then choose Check & add.":["Wprowadź kod dostępu LAN, a następnie wybierz Sprawdź i dodaj.","Introduce el código de acceso LAN y elige Comprobar y añadir.","Saisissez le code d’accès LAN, puis choisissez Vérifier et ajouter.","LAN-Zugangscode eingeben und dann Prüfen und hinzufügen wählen.","输入 LAN 访问码，然后选择“检查并添加”。"]
  ,"The printer is connected. Enter its manufacturer before adding it.":["Połączono z drukarką. Przed dodaniem wpisz jej producenta.","La impresora está conectada. Introduce el fabricante antes de añadirla.","L’imprimante est connectée. Saisissez son fabricant avant de l’ajouter.","Der Drucker ist verbunden. Vor dem Hinzufügen den Hersteller eingeben.","打印机已连接。添加前请输入制造商。"]
  ,"Added. You can add another printer.":["Dodano. Możesz dodać kolejną drukarkę.","Añadida. Puedes añadir otra impresora.","Ajoutée. Vous pouvez ajouter une autre imprimante.","Hinzugefügt. Du kannst einen weiteren Drucker hinzufügen.","已添加。你可以继续添加其他打印机。"]
  ,"Found moments ago":["Znaleziono przed chwilą","Encontrada hace unos instantes","Trouvée à l’instant","Gerade eben gefunden","刚刚发现"]
  ,"Found {minutes} min ago":["Znaleziono {minutes} min temu","Encontrada hace {minutes} min","Trouvée il y a {minutes} min","Vor {minutes} Min. gefunden","{minutes} 分钟前发现"]
  ,"Added":["Dodano","Añadida","Ajoutée","Hinzugefügt","已添加"]
  ,"Add":["Dodaj","Añadir","Ajouter","Hinzufügen","添加"]
  ,"Looking for supported printers…":["Wyszukiwanie obsługiwanych drukarek…","Buscando impresoras compatibles…","Recherche d’imprimantes compatibles…","Suche nach unterstützten Druckern…","正在查找支持的打印机…"]
  ,"One printer found in this scan.":["W tym skanowaniu znaleziono jedną drukarkę.","Se encontró una impresora en este escaneo.","Une imprimante a été trouvée pendant cette recherche.","Bei dieser Suche wurde ein Drucker gefunden.","本次扫描发现一台打印机。"]
  ,"{count} printers found in this scan.":["Drukarki znalezione w tym skanowaniu: {count}.","Se encontraron {count} impresoras en este escaneo.","{count} imprimantes ont été trouvées pendant cette recherche.","Bei dieser Suche wurden {count} Drucker gefunden.","本次扫描发现 {count} 台打印机。"]
  ,"No new printers were found. Recent results are shown below.":["Nie znaleziono nowych drukarek. Poniżej pokazano ostatnie wyniki.","No se encontraron impresoras nuevas. Los resultados recientes se muestran abajo.","Aucune nouvelle imprimante n’a été trouvée. Les résultats récents sont affichés ci-dessous.","Keine neuen Drucker gefunden. Kürzliche Ergebnisse werden unten angezeigt.","未发现新打印机。最近的结果显示在下方。"]
  ,"Preparing the Bambu Lab connection test":["Przygotowywanie testu połączenia z Bambu Lab","Preparando la prueba de conexión con Bambu Lab","Préparation du test de connexion Bambu Lab","Bambu-Lab-Verbindungstest wird vorbereitet","正在准备 Bambu Lab 连接测试"]
  ,"Bambu Lab connection verified.":["Połączenie z Bambu Lab zostało sprawdzone.","Conexión con Bambu Lab verificada.","Connexion Bambu Lab vérifiée.","Bambu-Lab-Verbindung bestätigt.","Bambu Lab 连接已验证。"]
  ,"The printer answered, but it did not accept these connection details.":["Drukarka odpowiedziała, ale nie zaakceptowała tych danych połączenia.","La impresora respondió, pero no aceptó estos datos de conexión.","L’imprimante a répondu, mais n’a pas accepté ces informations de connexion.","Der Drucker hat geantwortet, diese Verbindungsdaten jedoch nicht akzeptiert.","打印机已响应，但未接受这些连接信息。"]
  ,"PrintDeck could not reach this Bambu Lab printer. Check the address, LAN access code and Wi-Fi network.":["PrintDeck nie mógł połączyć się z tą drukarką Bambu Lab. Sprawdź adres, kod dostępu LAN i sieć Wi‑Fi.","PrintDeck no pudo acceder a esta impresora Bambu Lab. Comprueba la dirección, el código de acceso LAN y la red Wi‑Fi.","PrintDeck n’a pas pu joindre cette imprimante Bambu Lab. Vérifiez l’adresse, le code d’accès LAN et le réseau Wi-Fi.","PrintDeck konnte diesen Bambu-Lab-Drucker nicht erreichen. Adresse, LAN-Zugangscode und WLAN prüfen.","PrintDeck 无法连接此 Bambu Lab 打印机。请检查地址、LAN 访问码和 Wi-Fi 网络。"]
  ,"Unknown":["Nieznane","Desconocido","Inconnu","Unbekannt","未知"]
  ,"Display options":["Opcje wyświetlania","Opciones de visualización","Options d’affichage","Anzeigeoptionen","显示选项"]
  ,"Reaction set":["Zestaw reakcji","Conjunto de reacciones","Ensemble de réactions","Reaktionsset","反应集"]
  ,"Preview":["Podgląd","Vista previa","Aperçu","Vorschau","预览"]
  ,"Choose {set}":["Wybierz {set}","Elegir {set}","Choisir {set}","{set} auswählen","选择{set}"]
  ,"{count} color variants":["{count} wersji kolorystycznych","{count} variantes de color","{count} variantes de couleur","{count} Farbvarianten","{count} 种颜色变体"]
  ,"Choose a color":["Wybierz kolor","Elige un color","Choisissez une couleur","Farbe wählen","选择颜色"]
  ,"Installed on PrintDeck:":["Zainstalowany na PrintDeck:","Instalado en PrintDeck:","Installé sur PrintDeck :","Auf PrintDeck installiert:","PrintDeck 上已安装："]
  ,"Installed set:":["Zainstalowany zestaw:","Conjunto instalado:","Ensemble installé :","Installiertes Set:","已安装的反应集："]
  ,"Install {set}":["Zainstaluj: {set}","Instalar {set}","Installer {set}","{set} installieren","安装{set}"]
  ,"This set is installed on PrintDeck.":["Ten zestaw jest zainstalowany na PrintDeck.","Este conjunto está instalado en PrintDeck.","Cet ensemble est installé sur PrintDeck.","Dieses Set ist auf PrintDeck installiert.","此反应集已安装在 PrintDeck 上。"]
  ,"Installing replaces the set defaults.":["Instalacja zmienia domyślne animacje.","La instalación cambia las animaciones predeterminadas.","L’installation remplace les animations par défaut.","Die Installation ersetzt die Standardanimationen.","安装会替换默认动画。"]
  ,"Custom images are kept.":["Własne obrazy zostają.","Tus imágenes personalizadas se conservan.","Vos images personnalisées sont conservées.","Eigene Bilder bleiben erhalten.","自定义图像会保留。"]
  ,"Customize individual events in your installed set.":["Dostosuj poszczególne zdarzenia w zainstalowanym zestawie.","Personaliza cada evento del conjunto instalado.","Personnalisez les événements de l’ensemble installé.","Passe einzelne Ereignisse im installierten Set an.","自定义已安装反应集中的各个事件。"]
  ,"No reaction sets are available.":["Brak dostępnych zestawów reakcji.","No hay conjuntos de reacciones disponibles.","Aucun ensemble de réactions n’est disponible.","Keine Reaktionssets verfügbar.","暂无可用的反应集。"]
  ,"Reaction set installation progress":["Postęp instalacji zestawu reakcji","Progreso de instalación del conjunto","Progression de l’installation de l’ensemble","Fortschritt der Reaktionsset-Installation","反应集安装进度"]
  ,"Live View":["Podgląd na żywo","Vista en directo","Vue en direct","Live-Ansicht","实时画面"]
  ,"See and control the PrintDeck screen from this browser.":["Wyświetlaj i obsługuj ekran PrintDeck w tej przeglądarce.","Consulta y controla la pantalla de PrintDeck desde este navegador.","Affichez et contrôlez l’écran PrintDeck depuis ce navigateur.","PrintDeck-Display in diesem Browser anzeigen und bedienen.","在此浏览器中查看并控制 PrintDeck 屏幕。"]
  ,"Refresh rate":["Częstotliwość odświeżania","Frecuencia de actualización","Fréquence d’actualisation","Aktualisierungsrate","刷新频率"]
  ,"Every 1 second":["Co 1 sekundę","Cada segundo","Toutes les secondes","Jede Sekunde","每 1 秒"]
  ,"Every 2 seconds":["Co 2 sekundy","Cada 2 segundos","Toutes les 2 secondes","Alle 2 Sekunden","每 2 秒"]
  ,"Every 3 seconds":["Co 3 sekundy","Cada 3 segundos","Toutes les 3 secondes","Alle 3 Sekunden","每 3 秒"]
  ,"Every 4 seconds":["Co 4 sekundy","Cada 4 segundos","Toutes les 4 secondes","Alle 4 Sekunden","每 4 秒"]
  ,"Every 5 seconds":["Co 5 sekund","Cada 5 segundos","Toutes les 5 secondes","Alle 5 Sekunden","每 5 秒"]
  ,"Live View navigation controls":["Przyciski nawigacji podglądu na żywo","Controles de navegación de la vista en directo","Commandes de navigation de la vue en direct","Navigation der Live-Ansicht","实时画面导航控件"]
  ,"Navigate up":["Przejdź w górę","Ir arriba","Aller vers le haut","Nach oben","向上导航"]
  ,"Navigate left":["Przejdź w lewo","Ir a la izquierda","Aller à gauche","Nach links","向左导航"]
  ,"Navigate right":["Przejdź w prawo","Ir a la derecha","Aller à droite","Nach rechts","向右导航"]
  ,"Navigate down":["Przejdź w dół","Ir abajo","Aller vers le bas","Nach unten","向下导航"]
  ,"Interactive PrintDeck screen":["Interaktywny ekran PrintDeck","Pantalla interactiva de PrintDeck","Écran PrintDeck interactif","Interaktives PrintDeck-Display","PrintDeck 交互屏幕"]
  ,"Waiting for the first screen image…":["Oczekiwanie na pierwszy obraz ekranu…","Esperando la primera imagen de la pantalla…","En attente de la première image de l’écran…","Warten auf das erste Bildschirmbild…","正在等待首个屏幕画面…"]
  ,"Use it like the display":["Obsługuj jak ekran urządzenia","Úsala como la pantalla","Utilisez-la comme l’écran","Wie das Display bedienen","像设备屏幕一样操作"]
  ,"Tap controls directly, hold to open the Quick Menu, or swipe across the screen. The four arrows move to the neighboring view.":["Dotykaj elementów bezpośrednio, przytrzymaj, aby otworzyć Szybkie menu, albo przeciągnij po ekranie. Cztery strzałki przechodzą do sąsiedniego widoku.","Toca los controles directamente, mantén pulsado para abrir el Menú rápido o desliza sobre la pantalla. Las cuatro flechas llevan a la vista contigua.","Touchez directement les commandes, maintenez pour ouvrir le Menu rapide ou balayez l’écran. Les quatre flèches ouvrent la vue voisine.","Bediene Elemente direkt, halte zum Öffnen des Schnellmenüs gedrückt oder wische über das Display. Die vier Pfeile wechseln zur benachbarten Ansicht.","直接点按控件，长按可打开快捷菜单，也可在屏幕上滑动。四个箭头用于切换到相邻画面。"]
  ,"Tap":["Dotknięcie","Toque","Appui","Tippen","点按"]
  ,"Choose a control on the screen.":["Wybierz element sterujący na ekranie.","Selecciona un control en la pantalla.","Choisissez une commande à l’écran.","Ein Bedienelement auf dem Display auswählen.","选择屏幕上的控件。"]
  ,"Long press":["Przytrzymanie","Pulsación larga","Appui long","Gedrückt halten","长按"]
  ,"Click":["Kliknięcie","Clic","Clic","Klick","点击"]
  ,"Swipe left":["Przeciągnięcie w lewo","Deslizamiento a la izquierda","Balayage vers la gauche","Nach links wischen","向左滑动"]
  ,"Swipe right":["Przeciągnięcie w prawo","Deslizamiento a la derecha","Balayage vers la droite","Nach rechts wischen","向右滑动"]
  ,"Swipe up":["Przeciągnięcie w górę","Deslizamiento hacia arriba","Balayage vers le haut","Nach oben wischen","向上滑动"]
  ,"Swipe down":["Przeciągnięcie w dół","Deslizamiento hacia abajo","Balayage vers le bas","Nach unten wischen","向下滑动"]
  ,"Hold for a moment without moving.":["Przytrzymaj chwilę bez poruszania.","Mantén pulsado un momento sin mover.","Maintenez un instant sans bouger.","Kurz gedrückt halten, ohne zu bewegen.","按住片刻且不要移动。"]
  ,"Swipe":["Przeciągnięcie","Deslizamiento","Balayage","Wischen","滑动"]
  ,"Drag in any direction to navigate.":["Przeciągnij w dowolnym kierunku, aby nawigować.","Arrastra en cualquier dirección para navegar.","Faites glisser dans une direction pour naviguer.","Zum Navigieren in eine beliebige Richtung wischen.","向任意方向拖动以导航。"]
  ,"Connecting to Live View…":["Łączenie z podglądem na żywo…","Conectando con la vista en directo…","Connexion à la vue en direct…","Live-Ansicht wird verbunden…","正在连接实时画面…"]
  ,"Refreshing Live View…":["Odświeżanie podglądu na żywo…","Actualizando la vista en directo…","Actualisation de la vue en direct…","Live-Ansicht wird aktualisiert…","正在刷新实时画面…"]
  ,"Live View updated":["Podgląd na żywo odświeżony","Vista en directo actualizada","Vue en direct actualisée","Live-Ansicht aktualisiert","实时画面已更新"]
  ,"Sending input…":["Wysyłanie sterowania…","Enviando control…","Envoi de la commande…","Eingabe wird gesendet…","正在发送操作…"]
  ,"Input sent.":["Sterowanie wysłane.","Control enviado.","Commande envoyée.","Eingabe gesendet.","操作已发送。"]
  ,"Live View is temporarily unavailable.":["Podgląd na żywo jest chwilowo niedostępny.","La vista en directo no está disponible temporalmente.","La vue en direct est temporairement indisponible.","Die Live-Ansicht ist vorübergehend nicht verfügbar.","实时画面暂时不可用。"]
  ,"The previous Live View frame is still being prepared.":["Poprzedni obraz podglądu na żywo jest nadal przygotowywany.","La imagen anterior de la vista en directo aún se está preparando.","L’image précédente de la vue en direct est toujours en préparation.","Das vorherige Bild der Live-Ansicht wird noch vorbereitet.","上一帧实时画面仍在生成中。"]
  ,"Wait a moment before refreshing Live View again.":["Odczekaj chwilę przed ponownym odświeżeniem podglądu na żywo.","Espera un momento antes de volver a actualizar la vista en directo.","Patientez un instant avant d’actualiser à nouveau la vue en direct.","Bitte kurz warten, bevor die Live-Ansicht erneut aktualisiert wird.","请稍候再刷新实时画面。"]
  ,"The PrintDeck screen could not be captured.":["Nie udało się pobrać obrazu ekranu PrintDeck.","No se pudo capturar la pantalla de PrintDeck.","La capture de l’écran PrintDeck a échoué.","Das PrintDeck-Display konnte nicht erfasst werden.","无法捕获 PrintDeck 屏幕。"]
  ,"Live View controls are temporarily unavailable.":["Sterowanie podglądem na żywo jest chwilowo niedostępne.","Los controles de la vista en directo no están disponibles temporalmente.","Les commandes de la vue en direct sont temporairement indisponibles.","Die Bedienung der Live-Ansicht ist vorübergehend nicht verfügbar.","实时画面控制暂时不可用。"]
  ,"Live View input is invalid.":["Dane sterowania podglądem na żywo są nieprawidłowe.","El control de la vista en directo no es válido.","La commande de la vue en direct n’est pas valide.","Die Eingabe für die Live-Ansicht ist ungültig.","实时画面操作无效。"]
  ,"Live View swipe coordinates are invalid.":["Współrzędne przeciągnięcia w podglądzie na żywo są nieprawidłowe.","Las coordenadas del deslizamiento no son válidas.","Les coordonnées du balayage ne sont pas valides.","Die Wischkoordinaten sind ungültig.","实时画面滑动坐标无效。"]
  ,"Live View input action is invalid.":["Rodzaj sterowania podglądem na żywo jest nieprawidłowy.","La acción de control de la vista en directo no es válida.","L’action de commande de la vue en direct n’est pas valide.","Die Eingabeaktion für die Live-Ansicht ist ungültig.","实时画面操作类型无效。"]
  ,"Live View coordinates are outside the display.":["Współrzędne podglądu na żywo znajdują się poza ekranem.","Las coordenadas están fuera de la pantalla.","Les coordonnées se trouvent hors de l’écran.","Die Koordinaten liegen außerhalb des Displays.","实时画面坐标超出屏幕范围。"]
  ,"Wait for the current Live View gesture to finish.":["Poczekaj na zakończenie bieżącego gestu podglądu na żywo.","Espera a que termine el gesto actual de la vista en directo.","Attendez la fin du geste en cours dans la vue en direct.","Warte, bis die aktuelle Geste in der Live-Ansicht beendet ist.","请等待当前实时画面手势完成。"]
  ,"Live View input could not be sent.":["Nie udało się wysłać sterowania podglądem na żywo.","No se pudo enviar el control a la vista en directo.","La commande n’a pas pu être envoyée à la vue en direct.","Die Eingabe für die Live-Ansicht konnte nicht gesendet werden.","无法发送实时画面操作。"]
  ,"The Live View frame is invalid.":["Obraz podglądu na żywo jest nieprawidłowy.","La imagen de la vista en directo no es válida.","L’image de la vue en direct n’est pas valide.","Das Bild der Live-Ansicht ist ungültig.","实时画面帧无效。"]
  ,"Useful GIF resources":["Przydatne źródła GIF-ów","Recursos útiles de GIF","Ressources GIF utiles","Nützliche GIF-Quellen","实用 GIF 资源"]
  ,"Open GIPHY":["Otwórz GIPHY","Abrir GIPHY","Ouvrir GIPHY","GIPHY öffnen","打开 GIPHY"]
  ,"Open Tenor":["Otwórz Tenor","Abrir Tenor","Ouvrir Tenor","Tenor öffnen","打开 Tenor"]
  ,"Check reuse rights for each GIF.":["Sprawdź prawa do użycia każdego GIF-a.","Comprueba los derechos de uso de cada GIF.","Vérifiez les droits de réutilisation de chaque GIF.","Nutzungsrechte für jedes GIF prüfen.","请核实每个 GIF 的再使用权。"]
  ,"Device name":["Nazwa urządzenia","Nombre del dispositivo","Nom de l’appareil","Gerätename","设备名称"]
  ,"Give this PrintDeck a name you will recognize. Its permanent address stays available.":["Nadaj temu PrintDeckowi łatwą do rozpoznania nazwę. Jego stały adres pozostanie dostępny.","Da a este PrintDeck un nombre fácil de reconocer. Su dirección permanente seguirá disponible.","Donnez à ce PrintDeck un nom facile à reconnaître. Son adresse permanente reste disponible.","Gib diesem PrintDeck einen leicht erkennbaren Namen. Seine dauerhafte Adresse bleibt verfügbar.","为这台 PrintDeck 设置一个便于识别的名称。其永久地址仍可使用。"]
  ,"Name":["Nazwa","Nombre","Nom","Name","名称"]
  ,"e.g. Workshop":["np. Warsztat","p. ej., Taller","par ex. Atelier","z. B. Werkstatt","例如：工作室"]
  ,"Save name":["Zapisz nazwę","Guardar nombre","Enregistrer le nom","Namen speichern","保存名称"]
  ,"Local address:":["Adres lokalny:","Dirección local:","Adresse locale :","Lokale Adresse:","本地地址："]
  ,"IP address:":["Adres IP:","Dirección IP:","Adresse IP :","IP-Adresse:","IP 地址："]
  ,"Saving device name…":["Zapisywanie nazwy urządzenia…","Guardando el nombre del dispositivo…","Enregistrement du nom de l’appareil…","Gerätename wird gespeichert…","正在保存设备名称…"]
  ,"Device name saved.":["Nazwa urządzenia została zapisana.","Nombre del dispositivo guardado.","Nom de l’appareil enregistré.","Gerätename gespeichert.","设备名称已保存。"]
  ,"The device name is too long.":["Nazwa urządzenia jest za długa.","El nombre del dispositivo es demasiado largo.","Le nom de l’appareil est trop long.","Der Gerätename ist zu lang.","设备名称过长。"]
  ,"Device name saved. Use the local address shown above when it becomes available.":["Nazwa urządzenia została zapisana. Gdy nowy adres będzie dostępny, użyj adresu lokalnego widocznego powyżej.","Nombre del dispositivo guardado. Cuando esté disponible, usa la dirección local que aparece arriba.","Nom de l’appareil enregistré. Lorsqu’elle sera disponible, utilisez l’adresse locale affichée ci-dessus.","Gerätename gespeichert. Verwende die oben angezeigte lokale Adresse, sobald sie verfügbar ist.","设备名称已保存。本地地址可用后，请使用上方显示的地址。"]
  ,"Factory reset":["Przywracanie ustawień fabrycznych","Restablecimiento de fábrica","Réinitialisation d’usine","Werkseinstellungen","恢复出厂设置"]
  ,"Erase saved Wi-Fi, printer profiles, device settings and custom reaction images. PrintDeck will restart in first-time setup with the current firmware and the system versions of reaction images.":["Usuń zapisane dane Wi-Fi, profile drukarek, ustawienia urządzenia i własne obrazy reakcji. PrintDeck uruchomi się ponownie w trybie pierwszej konfiguracji z bieżącym oprogramowaniem i systemowymi wersjami obrazów reakcji.","Borra los datos Wi-Fi guardados, los perfiles de impresora, los ajustes del dispositivo y las imágenes de reacción personalizadas. PrintDeck se reiniciará en la configuración inicial con el firmware actual y las versiones del sistema de las imágenes de reacción.","Effacez les données Wi-Fi enregistrées, les profils d’imprimante, les réglages de l’appareil et les images de réaction personnalisées. PrintDeck redémarrera en configuration initiale avec le micrologiciel actuel et les versions système des images de réaction.","Gespeicherte WLAN-Daten, Druckerprofile, Geräteeinstellungen und eigene Reaktionsbilder werden gelöscht. PrintDeck startet mit der aktuellen Firmware und den Systemversionen der Reaktionsbilder in die Ersteinrichtung.","清除已保存的 Wi-Fi、打印机配置、设备设置和自定义反应图片。PrintDeck 将保留当前固件和系统反应图片，并重启进入首次设置。"]
  ,"Reset to factory settings":["Przywróć ustawienia fabryczne","Restablecer ajustes de fábrica","Rétablir les réglages d’usine","Auf Werkseinstellungen zurücksetzen","恢复出厂设置"]
  ,"Reset PrintDeck to factory settings?":["Przywrócić ustawienia fabryczne PrintDeck?","¿Restablecer PrintDeck a los ajustes de fábrica?","Rétablir les réglages d’usine de PrintDeck ?","PrintDeck auf Werkseinstellungen zurücksetzen?","将 PrintDeck 恢复出厂设置？"]
  ,"This erases saved Wi-Fi, printer profiles, device settings and custom reaction images. PrintDeck will restart in first-time setup. The installed firmware will stay the same.":["Spowoduje to usunięcie zapisanych danych Wi-Fi, profili drukarek, ustawień urządzenia i własnych obrazów reakcji. PrintDeck uruchomi się ponownie w trybie pierwszej konfiguracji. Zainstalowane oprogramowanie pozostanie bez zmian.","Esto borra los datos Wi-Fi guardados, los perfiles de impresora, los ajustes del dispositivo y las imágenes de reacción personalizadas. PrintDeck se reiniciará en la configuración inicial. El firmware instalado no cambiará.","Cette opération efface les données Wi-Fi enregistrées, les profils d’imprimante, les réglages de l’appareil et les images de réaction personnalisées. PrintDeck redémarrera en configuration initiale. Le micrologiciel installé ne changera pas.","Dadurch werden gespeicherte WLAN-Daten, Druckerprofile, Geräteeinstellungen und eigene Reaktionsbilder gelöscht. PrintDeck startet anschließend in die Ersteinrichtung. Die installierte Firmware bleibt unverändert.","这将清除已保存的 Wi-Fi、打印机配置、设备设置和自定义反应图片。PrintDeck 将重启进入首次设置。已安装的固件不会改变。"]
  ,"Confirm":["Potwierdź","Confirmar","Confirmer","Bestätigen","确认"]
  ,"Type reset to continue":["Wpisz reset, aby kontynuować","Escribe reset para continuar","Saisissez reset pour continuer","Zum Fortfahren reset eingeben","输入 reset 以继续"]
  ,"Enter {reset} below to confirm this cannot be undone.":["Wpisz poniżej {reset}, aby potwierdzić tę nieodwracalną operację.","Escribe {reset} a continuación para confirmar esta acción irreversible.","Saisissez {reset} ci-dessous pour confirmer cette opération irréversible.","Gib unten {reset} ein, um diesen unwiderruflichen Vorgang zu bestätigen.","在下方输入 {reset}，确认执行无法撤销的操作。"]
  ,"Confirmation word":["Słowo potwierdzające","Palabra de confirmación","Mot de confirmation","Bestätigungswort","确认词"]
  ,"Reset PrintDeck":["Wyzeruj PrintDeck","Restablecer PrintDeck","Réinitialiser PrintDeck","PrintDeck zurücksetzen","重置 PrintDeck"]
  ,"Resetting PrintDeck…":["Przywracanie ustawień PrintDeck…","Restableciendo PrintDeck…","Réinitialisation de PrintDeck…","PrintDeck wird zurückgesetzt…","正在重置 PrintDeck…"]
  ,"Factory reset started. PrintDeck is restarting…":["Rozpoczęto przywracanie ustawień fabrycznych. PrintDeck uruchamia się ponownie…","Se inició el restablecimiento de fábrica. PrintDeck se está reiniciando…","La réinitialisation d’usine a commencé. PrintDeck redémarre…","Das Zurücksetzen auf Werkseinstellungen wurde gestartet. PrintDeck startet neu…","已开始恢复出厂设置。PrintDeck 正在重启…"]
  ,"PrintDeck was reset to factory settings":["Przywrócono ustawienia fabryczne PrintDeck","PrintDeck se restableció a los ajustes de fábrica","Les réglages d’usine de PrintDeck ont été rétablis","PrintDeck wurde auf Werkseinstellungen zurückgesetzt","已将 PrintDeck 恢复为出厂设置"]
  ,"Saved Wi-Fi, printers, settings and custom reaction images were removed. The installed firmware remains unchanged.":["Usunięto zapisane dane Wi‑Fi, drukarki, ustawienia i własne obrazy reakcji. Zainstalowane oprogramowanie pozostało bez zmian.","Se eliminaron los datos Wi‑Fi, las impresoras, los ajustes y las imágenes de reacción personalizadas. El firmware instalado no ha cambiado.","Les données Wi‑Fi, les imprimantes, les réglages et les images de réaction personnalisées ont été supprimés. Le micrologiciel installé reste inchangé.","Gespeicherte WLAN-Daten, Drucker, Einstellungen und eigene Reaktionsbilder wurden entfernt. Die installierte Firmware bleibt unverändert.","已删除保存的 Wi-Fi、打印机、设置和自定义反应图片。已安装的固件保持不变。"]
  ,"PrintDeck is restarting in first-time setup…":["PrintDeck uruchamia się ponownie w trybie pierwszej konfiguracji…","PrintDeck se está reiniciando en el modo de configuración inicial…","PrintDeck redémarre en mode de configuration initiale…","PrintDeck startet im Einrichtungsmodus neu…","PrintDeck 正在重启并进入首次设置模式…"]
  ,"When the setup network appears, connect this device to:":["Gdy pojawi się sieć konfiguracji, połącz z nią to urządzenie:","Cuando aparezca la red de configuración, conecta este dispositivo a:","Lorsque le réseau de configuration apparaît, connectez-y cet appareil :","Sobald das Einrichtungsnetzwerk erscheint, verbinde dieses Gerät mit:","设置网络出现后，请将此设备连接到："]
  ,"QR code for the PrintDeck setup Wi-Fi network":["Kod QR sieci Wi‑Fi konfiguracji PrintDeck","Código QR de la red Wi‑Fi de configuración de PrintDeck","Code QR du réseau Wi‑Fi de configuration PrintDeck","QR-Code für das PrintDeck-Einrichtungs-WLAN","用于 PrintDeck 设置 Wi-Fi 网络的二维码"]
  ,"Scan this code to connect, then follow the instructions shown on PrintDeck.":["Zeskanuj ten kod, aby się połączyć, a następnie wykonaj instrukcje pokazane na PrintDeck.","Escanea este código para conectarte y sigue las instrucciones que aparecen en PrintDeck.","Scannez ce code pour vous connecter, puis suivez les instructions affichées sur PrintDeck.","Scanne diesen Code zum Verbinden und folge dann den Anweisungen auf PrintDeck.","扫描此二维码进行连接，然后按照 PrintDeck 上显示的说明操作。"]
  ,"After PrintDeck restarts, follow the setup instructions shown on its screen.":["Po ponownym uruchomieniu PrintDeck wykonaj instrukcje konfiguracji pokazane na jego ekranie.","Cuando PrintDeck se reinicie, sigue las instrucciones de configuración que aparecen en su pantalla.","Après le redémarrage de PrintDeck, suivez les instructions de configuration affichées sur son écran.","Folge nach dem Neustart von PrintDeck den Einrichtungsanweisungen auf dem Display.","PrintDeck 重启后，请按照屏幕上显示的设置说明操作。"]
  ,"Type reset to confirm the factory reset.":["Wpisz reset, aby potwierdzić przywrócenie ustawień fabrycznych.","Escribe reset para confirmar el restablecimiento de fábrica.","Saisissez reset pour confirmer la réinitialisation d’usine.","Gib reset ein, um das Zurücksetzen auf Werkseinstellungen zu bestätigen.","输入 reset 以确认恢复出厂设置。"]
  ,"Type reset exactly as shown to continue.":["Aby kontynuować, wpisz reset dokładnie w pokazanej formie.","Para continuar, escribe reset exactamente como se muestra.","Pour continuer, saisissez reset exactement comme indiqué.","Gib zum Fortfahren reset genau wie angezeigt ein.","请准确输入 reset 以继续。"]
  ,"PrintDeck could not remove custom reactions. Nothing else was reset.":["PrintDeck nie mógł usunąć własnych reakcji. Żadne inne dane nie zostały wyzerowane.","PrintDeck no pudo eliminar las reacciones personalizadas. No se restableció ningún otro dato.","PrintDeck n’a pas pu supprimer les réactions personnalisées. Aucune autre donnée n’a été réinitialisée.","PrintDeck konnte die eigenen Reaktionen nicht entfernen. Es wurden keine weiteren Daten zurückgesetzt.","PrintDeck 无法删除自定义反应。其他数据均未重置。"]
  ,"PrintDeck could not erase its saved settings. Please try again.":["PrintDeck nie mógł usunąć zapisanych ustawień. Spróbuj ponownie.","PrintDeck no pudo borrar los ajustes guardados. Inténtalo de nuevo.","PrintDeck n’a pas pu effacer les réglages enregistrés. Réessayez.","PrintDeck konnte die gespeicherten Einstellungen nicht löschen. Bitte erneut versuchen.","PrintDeck 无法清除已保存的设置。请重试。"]
  ,"Factory reset confirmation is missing. Refresh the page and try again.":["Brakuje potwierdzenia przywrócenia ustawień fabrycznych. Odśwież stronę i spróbuj ponownie.","Falta la confirmación del restablecimiento de fábrica. Actualiza la página e inténtalo de nuevo.","La confirmation de la réinitialisation d’usine est absente. Actualisez la page et réessayez.","Die Bestätigung für das Zurücksetzen fehlt. Aktualisiere die Seite und versuche es erneut.","缺少恢复出厂设置确认。请刷新页面后重试。"]
};
Object.assign(PRINTDECK_EXTRA_TRANSLATIONS, {
  "Turn off when no print is running": [
    "Wyłącz ekran bez druku po",
    "Apagar la pantalla sin impresión tras",
    "Éteindre l’écran hors impression après",
    "Display ohne Druck ausschalten nach",
    "未打印时关闭屏幕的等待时间"
  ],
  "Turn off during a print": [
    "Wyłącz ekran podczas druku po",
    "Apagar la pantalla durante la impresión tras",
    "Éteindre l’écran pendant l’impression après",
    "Display beim Drucken ausschalten nach",
    "打印时关闭屏幕的等待时间"
  ],
  "Advanced settings": [
    "Ustawienia zaawansowane",
    "Ajustes avanzados",
    "Paramètres avancés",
    "Erweiterte Einstellungen",
    "高级设置"
  ],
  "Never": [
    "Nigdy",
    "Nunca",
    "Jamais",
    "Nie",
    "永不"
  ]
});
Object.assign(PRINTDECK_EXTRA_TRANSLATIONS, {
  "Keep the screen on?": [
    "Pozostawić ekran włączony?",
    "¿Mantener la pantalla encendida?",
    "Garder l’écran allumé ?",
    "Display eingeschaltet lassen?",
    "保持屏幕开启？"
  ],
  "The screen will not turn off automatically in this print state. Dimming and USB power settings still apply.": [
    "W tym stanie druku ekran nie wyłączy się automatycznie. Ustawienia przyciemniania i zasilania USB nadal obowiązują.",
    "La pantalla no se apagará automáticamente en este estado de impresión. Se mantienen los ajustes de atenuación y alimentación USB.",
    "L’écran ne s’éteindra pas automatiquement dans cet état d’impression. Les réglages d’atténuation et d’alimentation USB restent applicables.",
    "In diesem Druckzustand schaltet sich das Display nicht automatisch aus. Die Einstellungen für Dimmen und USB-Stromversorgung gelten weiterhin.",
    "在此打印状态下，屏幕不会自动关闭。调暗和 USB 供电设置仍然生效。"
  ],
  "Leaving a static image on an AMOLED screen for a long time can cause permanent burn-in. Automatic screen off is recommended.": [
    "Długie wyświetlanie statycznego obrazu na ekranie AMOLED może spowodować trwałe wypalenie. Zalecamy automatyczne wyłączanie ekranu.",
    "Mostrar una imagen estática durante mucho tiempo en una pantalla AMOLED puede causar quemaduras permanentes. Se recomienda el apagado automático.",
    "L’affichage prolongé d’une image fixe sur un écran AMOLED peut provoquer un marquage permanent. L’extinction automatique est recommandée.",
    "Ein lange angezeigtes statisches Bild kann auf einem AMOLED-Display dauerhaft einbrennen. Automatisches Ausschalten wird empfohlen.",
    "在 AMOLED 屏幕上长时间显示静态图像可能导致永久烧屏。建议启用自动关闭屏幕。"
  ],
  "Keep screen on": [
    "Pozostaw ekran włączony",
    "Mantener encendida",
    "Garder l’écran allumé",
    "Eingeschaltet lassen",
    "保持屏幕开启"
  ]
});
Object.assign(PRINTDECK_EXTRA_TRANSLATIONS, {
  "Unified API": [
    "Ujednolicone API",
    "API unificada",
    "API unifiée",
    "Einheitliche API",
    "统一 API"
  ],
  "Unified API token": [
    "Token ujednoliconego API",
    "Token de la API unificada",
    "Jeton de l’API unifiée",
    "Token der einheitlichen API",
    "统一 API 令牌"
  ],
  "Choose a valid Unified API action.": [
    "Wybierz prawidłową czynność ujednoliconego API.",
    "Elige una acción válida para la API unificada.",
    "Choisissez une action valide pour l’API unifiée.",
    "Wähle eine gültige Aktion für die einheitliche API.",
    "请选择有效的统一 API 操作。"
  ],
  "Unified API token is invalid": [
    "Token ujednoliconego API jest nieprawidłowy",
    "El token de la API unificada no es válido",
    "Le jeton de l’API unifiée est invalide",
    "Der Token der einheitlichen API ist ungültig",
    "统一 API 令牌无效"
  ],
  "Ask about your print. Your voice stays on PrintDeck.": [
    "Zapytaj o wydruk. Twój głos pozostaje w PrintDeck.",
    "Pregunta por tu impresión. Tu voz se queda en PrintDeck.",
    "Posez des questions sur votre impression. Votre voix reste sur PrintDeck.",
    "Frage nach deinem Druck. Deine Stimme bleibt auf PrintDeck.",
    "询问打印进度。你的语音只在 PrintDeck 上处理。"
  ],
  "Listen for “Hi ESP!”": [
    "Nasłuchuj „Hi ESP!”",
    "Escuchar «Hi ESP!»",
    "Écouter «Hi ESP!»",
    "Auf „Hi ESP!“ hören",
    "监听“Hi ESP!”"
  ],
  "When enabled, the microphone continuously listens for the wake phrase, even during the screen saver or with the display off.": [
    "Po włączeniu mikrofon stale nasłuchuje frazy wybudzającej, także podczas wygaszacza i przy wyłączonym ekranie.",
    "Al activarlo, el micrófono escucha continuamente la frase de activación, incluso con el protector de pantalla o la pantalla apagada.",
    "Une fois activé, le microphone écoute en continu la phrase d’activation, même avec l’économiseur d’écran ou l’écran éteint.",
    "Wenn aktiviert, hört das Mikrofon ständig auf das Aktivierungswort, auch beim Bildschirmschoner oder ausgeschaltetem Display.",
    "启用后，麦克风会持续监听唤醒词，即使正在显示屏保或屏幕已关闭。"
  ],
  "Enable Hi ESP!": [
    "Włącz Hi ESP!",
    "Activar Hi ESP!",
    "Activer Hi ESP!",
    "Hi ESP! aktivieren",
    "启用 Hi ESP!"
  ],
  "Disable Hi ESP!": [
    "Wyłącz Hi ESP!",
    "Desactivar Hi ESP!",
    "Désactiver Hi ESP!",
    "Hi ESP! deaktivieren",
    "停用 Hi ESP!"
  ],
  "Hi ESP! enabled": [
    "Hi ESP! włączone",
    "Hi ESP! activado",
    "Hi ESP! activé",
    "Hi ESP! aktiviert",
    "Hi ESP! 已启用"
  ],
  "Saving Hi ESP! settings…": [
    "Zapisywanie ustawień Hi ESP!…",
    "Guardando los ajustes de Hi ESP!…",
    "Enregistrement des réglages Hi ESP!…",
    "Hi ESP!-Einstellungen werden gespeichert…",
    "正在保存 Hi ESP! 设置…"
  ],
  "How it works": [
    "Jak to działa",
    "Cómo funciona",
    "Comment ça marche",
    "So funktioniert es",
    "使用方法"
  ],
  "Say “Hi ESP!”": [
    "Powiedz „Hi ESP!”",
    "Di «Hi ESP!»",
    "Dites «Hi ESP!»",
    "Sage „Hi ESP!“",
    "说出“Hi ESP!”"
  ],
  "PrintDeck wakes the display and restarts the screen saver countdown.": [
    "PrintDeck wybudza ekran i zaczyna od nowa odliczanie wygaszacza.",
    "PrintDeck enciende la pantalla y reinicia la cuenta atrás del protector de pantalla.",
    "PrintDeck réveille l’écran et relance le délai de l’économiseur d’écran.",
    "PrintDeck weckt das Display und startet die Wartezeit für den Bildschirmschoner neu.",
    "PrintDeck 会唤醒屏幕，并重新开始屏保倒计时。"
  ],
  "Wait for “Yes”": [
    "Poczekaj na „Yes”",
    "Espera a oír «Yes»",
    "Attendez «Yes»",
    "Warte auf „Yes“",
    "等待听到“Yes”"
  ],
  "Then say a command in English within 7 seconds.": [
    "Następnie wypowiedz komendę po angielsku w ciągu 7 sekund.",
    "Después, di un comando en inglés en un plazo de 7 segundos.",
    "Puis prononcez une commande en anglais dans les 7 secondes.",
    "Sage dann innerhalb von 7 Sekunden einen Befehl auf Englisch.",
    "然后在 7 秒内说出一条英语指令。"
  ],
  "Hear the answer": [
    "Usłysz odpowiedź",
    "Escucha la respuesta",
    "Écoutez la réponse",
    "Höre die Antwort",
    "听取回答"
  ],
  "PrintDeck answers in English, then listens for “Hi ESP!” again. If no command is recognized, simply start again.": [
    "PrintDeck odpowiada po angielsku i ponownie nasłuchuje „Hi ESP!”. Jeśli nie rozpozna komendy, po prostu zacznij od nowa.",
    "PrintDeck responde en inglés y vuelve a escuchar «Hi ESP!». Si no reconoce el comando, vuelve a empezar.",
    "PrintDeck répond en anglais, puis écoute à nouveau «Hi ESP!». Si aucune commande n’est reconnue, recommencez simplement.",
    "PrintDeck antwortet auf Englisch und hört wieder auf „Hi ESP!“. Wird kein Befehl erkannt, beginne einfach erneut.",
    "PrintDeck 用英语回答，然后继续监听“Hi ESP!”。如果没有识别到指令，请重新开始。"
  ],
  "What you can ask": [
    "O co możesz zapytać",
    "Qué puedes preguntar",
    "Ce que vous pouvez demander",
    "Das kannst du fragen",
    "可以询问什么"
  ],
  "Answers use the active/selected printer.": [
    "Odpowiedzi dotyczą aktywnej/wybranej drukarki.",
    "Las respuestas se refieren a la impresora activa o seleccionada.",
    "Les réponses concernent l’imprimante active ou sélectionnée.",
    "Die Antworten beziehen sich auf den aktiven/ausgewählten Drucker.",
    "回答基于当前使用或选中的打印机。"
  ],
  "Reports print progress as a percentage.": [
    "Podaje procentowy postęp wydruku.",
    "Indica el progreso de impresión en porcentaje.",
    "Indique la progression de l’impression en pourcentage.",
    "Nennt den Druckfortschritt in Prozent.",
    "报告打印进度百分比。"
  ],
  "Reports the estimated remaining time.": [
    "Podaje szacowany pozostały czas.",
    "Indica el tiempo restante estimado.",
    "Indique le temps restant estimé.",
    "Nennt die geschätzte verbleibende Zeit.",
    "报告预计剩余时间。"
  ],
  "Reports the estimated finish time in your time zone.": [
    "Podaje przewidywaną godzinę zakończenia w Twojej strefie czasowej.",
    "Indica la hora de finalización estimada en tu zona horaria.",
    "Indique l’heure de fin estimée dans votre fuseau horaire.",
    "Nennt die geschätzte Endzeit in deiner Zeitzone.",
    "报告你所在时区的预计完成时间。"
  ],
  "PrintDeck tells you when the printer is unavailable, no print is active or timing is unavailable.": [
    "PrintDeck poinformuje, gdy drukarka jest niedostępna, nie trwa wydruk lub brakuje danych o czasie.",
    "PrintDeck te avisa si la impresora no está disponible, no hay una impresión activa o faltan datos de tiempo.",
    "PrintDeck vous signale si l’imprimante est indisponible, si aucune impression n’est en cours ou si les durées sont inconnues.",
    "PrintDeck meldet, wenn der Drucker nicht verfügbar ist, kein Druck läuft oder Zeitangaben fehlen.",
    "当打印机不可用、没有正在进行的打印或缺少时间数据时，PrintDeck 会告知你。"
  ],
  "Private by design": [
    "Prywatność od podstaw",
    "Privacidad desde el diseño",
    "La confidentialité avant tout",
    "Privatsphäre von Anfang an",
    "注重隐私的设计"
  ],
  "Speech is processed only on this device. No audio recordings are saved, sent or shared. No cloud service or account is used.": [
    "Mowa jest przetwarzana wyłącznie na tym urządzeniu. Żadne nagrania nie są zapisywane, wysyłane ani udostępniane. Funkcja nie korzysta z chmury ani konta.",
    "La voz se procesa solo en este dispositivo. No se guardan, envían ni comparten grabaciones. No se usa ningún servicio en la nube ni cuenta.",
    "La voix est traitée uniquement sur cet appareil. Aucun enregistrement n’est conservé, envoyé ou partagé. Aucun service cloud ni compte n’est utilisé.",
    "Sprache wird nur auf diesem Gerät verarbeitet. Es werden keine Audioaufnahmen gespeichert, gesendet oder geteilt. Es wird kein Cloud-Dienst oder Konto verwendet.",
    "语音仅在本设备上处理。不会保存、发送或分享录音，也不使用云服务或账号。"
  ],
  "Disabled by default. Turning it off stops microphone listening.": [
    "Domyślnie wyłączone. Wyłączenie zatrzymuje nasłuch mikrofonu.",
    "Desactivado por defecto. Al desactivarlo, se detiene la escucha del micrófono.",
    "Désactivé par défaut. La désactivation arrête l’écoute du microphone.",
    "Standardmäßig deaktiviert. Das Ausschalten beendet das Mithören des Mikrofons.",
    "默认停用。停用后，麦克风停止监听。"
  ],
  "Keep sound enabled and the volume above zero to hear “Yes” and spoken answers.": [
    "Aby usłyszeć „Yes” i odpowiedzi, pozostaw dźwięk włączony i głośność powyżej zera.",
    "Mantén el sonido activado y el volumen por encima de cero para oír «Yes» y las respuestas.",
    "Laissez le son activé avec un volume supérieur à zéro pour entendre «Yes» et les réponses.",
    "Lass den Ton eingeschaltet und die Lautstärke über null, um „Yes“ und die Antworten zu hören.",
    "请开启声音并将音量设为大于零，以听到“Yes”和语音回答。"
  ],
  "Choose a valid Hi ESP! action.": [
    "Wybierz prawidłową czynność Hi ESP!.",
    "Elige una acción válida para Hi ESP!.",
    "Choisissez une action valide pour Hi ESP!.",
    "Wähle eine gültige Hi ESP!-Aktion.",
    "请选择有效的 Hi ESP! 操作。"
  ],
  "Hi ESP! is not available on this device.": [
    "Hi ESP! nie jest dostępne na tym urządzeniu.",
    "Hi ESP! no está disponible en este dispositivo.",
    "Hi ESP! n’est pas disponible sur cet appareil.",
    "Hi ESP! ist auf diesem Gerät nicht verfügbar.",
    "此设备不支持 Hi ESP!。"
  ],
  "PrintDeck could not save the Hi ESP! setting. Please try again.": [
    "PrintDeck nie mógł zapisać ustawienia Hi ESP!. Spróbuj ponownie.",
    "PrintDeck no pudo guardar el ajuste de Hi ESP!. Inténtalo de nuevo.",
    "PrintDeck n’a pas pu enregistrer le réglage Hi ESP!. Réessayez.",
    "PrintDeck konnte die Hi ESP!-Einstellung nicht speichern. Bitte versuche es erneut.",
    "PrintDeck 无法保存 Hi ESP! 设置。请重试。"
  ]
});
for(const [source,values] of Object.entries(PRINTDECK_EXTRA_TRANSLATIONS)){
  PRINTDECK_TRANSLATION_COLUMNS.forEach((language,index)=>window.PRINTDECK_TRANSLATIONS[language][source]=values[index]);
}

// Printer setup copy, in the maintained language order.
const PRINTER_SETUP_TRANSLATIONS={
"A printer search is already in progress. Try again in a moment.":["Trwa już wyszukiwanie drukarki. Spróbuj ponownie za chwilę.","Ya hay una búsqueda de impresoras en curso. Inténtalo de nuevo en un momento.","Une recherche d’imprimante est déjà en cours. Réessayez dans un instant.","Eine Druckersuche läuft bereits. Versuche es gleich erneut.","正在搜索打印机，请稍后重试。"],
"The printer search changed. Please try again.":["Wyszukiwanie drukarki zostało zmienione. Spróbuj ponownie.","La búsqueda de impresoras ha cambiado. Inténtalo de nuevo.","La recherche d’imprimante a changé. Réessayez.","Die Druckersuche hat sich geändert. Versuche es erneut.","打印机搜索已更改，请重试。"],
"The printer did not respond in time. Please try again.":["Drukarka nie odpowiedziała w wyznaczonym czasie. Spróbuj ponownie.","La impresora no respondió a tiempo. Inténtalo de nuevo.","L’imprimante n’a pas répondu à temps. Réessayez.","Der Drucker hat nicht rechtzeitig geantwortet. Versuche es erneut.","打印机未及时响应，请重试。"],
"automatic":["automatycznie","automático","automatique","automatisch","自动"],
"Clear port":["Wyczyść port","Borrar puerto","Effacer le port","Port löschen","清除端口"],
"… and much more …":["… i wiele więcej …","… y mucho más …","… et bien plus encore …","… und vieles mehr …","… 还有更多 …"],
"Auto detect":["Wykryj automatycznie","Detectar automáticamente","Détection automatique","Automatisch erkennen","自动检测"],
"The printer uses a different connection. Choose Auto detect or check the address.":["Drukarka używa innego połączenia. Wybierz wykrywanie automatyczne lub sprawdź adres.","La impresora usa otra conexión. Elige la detección automática o comprueba la dirección.","L’imprimante utilise une autre connexion. Choisissez la détection automatique ou vérifiez l’adresse.","Der Drucker verwendet eine andere Verbindung. Wähle die automatische Erkennung oder prüfe die Adresse.","打印机使用其他连接类型。请选择自动检测或检查地址。"],
"Other printers":["Inne drukarki","Otras impresoras","Autres imprimantes","Andere Drucker","其他打印机"],
"Connect with your printer address and LAN access code.":["Połącz się, podając adres drukarki i kod dostępu LAN.","Conecta con la dirección de la impresora y el código de acceso LAN.","Connectez-vous avec l’adresse de l’imprimante et son code d’accès LAN.","Verbinde dich mit der Druckeradresse und dem LAN-Zugangscode.","使用打印机地址和局域网访问码连接。"],
"Enter the address. PrintDeck will recognize your printer and guide you through setup.":["Podaj adres. PrintDeck rozpozna drukarkę i przeprowadzi Cię przez konfigurację.","Introduce la dirección. PrintDeck reconocerá tu impresora y te guiará en la configuración.","Saisissez l’adresse. PrintDeck reconnaîtra votre imprimante et vous guidera dans la configuration.","Gib die Adresse ein. PrintDeck erkennt deinen Drucker und führt dich durch die Einrichtung.","输入地址。PrintDeck 将识别打印机并引导你完成设置。"],
"Local connection":["Połączenie lokalne","Conexión local","Connexion locale","Lokale Verbindung","本地连接"],
"Printer setup":["Konfiguracja drukarki","Configuración de impresora","Configuration de l’imprimante","Druckereinrichtung","打印机设置"],
"Printer address":["Adres drukarki","Dirección de la impresora","Adresse de l’imprimante","Druckeradresse","打印机地址"],
"Connection":["Połączenie","Conexión","Connexion","Verbindung","连接"],
"PrintDeck will identify the connection, brand and model before asking for access details.":["PrintDeck rozpozna rodzaj połączenia, markę i model, zanim poprosi o dane dostępu.","PrintDeck identificará la conexión, la marca y el modelo antes de pedir los datos de acceso.","PrintDeck identifiera la connexion, la marque et le modèle avant de demander les identifiants.","PrintDeck erkennt Verbindung, Marke und Modell, bevor es nach Zugangsdaten fragt.","PrintDeck 会先识别连接类型、品牌和型号，再询问访问凭据。"],
"Connection type":["Rodzaj połączenia","Tipo de conexión","Type de connexion","Verbindungstyp","连接类型"],
"Printer brands and models":["Marki i modele drukarek","Marcas y modelos de impresoras","Marques et modèles d’imprimantes","Druckermarken und Modelle","打印机品牌和型号"],
"Connection recognized":["Rozpoznano połączenie","Conexión reconocida","Connexion reconnue","Verbindung erkannt","已识别连接"],
"Connection selected":["Wybrano połączenie","Conexión seleccionada","Connexion sélectionnée","Verbindung ausgewählt","已选择连接"],
"Change address":["Zmień adres","Cambiar dirección","Modifier l’adresse","Adresse ändern","更改地址"],
"Printer details":["Dane drukarki","Datos de la impresora","Informations de l’imprimante","Druckerdetails","打印机信息"],
"Enter a valid IP address or hostname.":["Podaj prawidłowy adres IP lub nazwę hosta.","Introduce una dirección IP o un nombre de host válido.","Saisissez une adresse IP ou un nom d’hôte valide.","Gib eine gültige IP-Adresse oder einen Hostnamen ein.","请输入有效的 IP 地址或主机名。"],
"Enter a port from 1 to 65535.":["Podaj port od 1 do 65535.","Introduce un puerto entre 1 y 65535.","Saisissez un port compris entre 1 et 65535.","Gib einen Port zwischen 1 und 65535 ein.","请输入 1 到 65535 之间的端口。"],
"Recognizing your printer…":["Rozpoznawanie drukarki…","Reconociendo tu impresora…","Reconnaissance de l’imprimante…","Drucker wird erkannt…","正在识别打印机…"],
"We couldn’t recognize this printer. Check the address and port, or choose the connection manually.":["Nie udało się rozpoznać drukarki. Sprawdź adres i port lub wybierz połączenie ręcznie.","No pudimos reconocer esta impresora. Comprueba la dirección y el puerto o elige la conexión manualmente.","Impossible de reconnaître cette imprimante. Vérifiez l’adresse et le port ou choisissez la connexion manuellement.","Der Drucker konnte nicht erkannt werden. Prüfe Adresse und Port oder wähle die Verbindung manuell.","无法识别此打印机。请检查地址和端口，或手动选择连接。"],
"Enter your API key to finish identifying the printer.":["Podaj klucz API, aby dokończyć rozpoznawanie drukarki.","Introduce tu clave API para terminar de identificar la impresora.","Saisissez votre clé API pour terminer l’identification de l’imprimante.","Gib deinen API-Schlüssel ein, um die Druckererkennung abzuschließen.","请输入 API 密钥以完成打印机识别。"],
"Review the details, then check the connection to add your printer.":["Sprawdź dane, a następnie przetestuj połączenie i dodaj drukarkę.","Revisa los datos y comprueba la conexión para añadir tu impresora.","Vérifiez les informations, puis testez la connexion pour ajouter l’imprimante.","Prüfe die Angaben und teste dann die Verbindung, um deinen Drucker hinzuzufügen.","确认信息后，检查连接以添加打印机。"]
};
for(const [source,values] of Object.entries(PRINTER_SETUP_TRANSLATIONS)){
  PRINTDECK_TRANSLATION_COLUMNS.forEach((language,index)=>window.PRINTDECK_TRANSLATIONS[language][source]=values[index]);
}
